#include <iostream>
#include <algorithm>
#include <climits>
#include <string>
#include <vector>
#include "Tree.h"
using namespace std;

#ifndef MWIS_H_
#define MWIS_H_

class MWIS: public Tree {

public:

	int *computedSum;
	bool *isIncludedSumLarger;
	bool *isInSet;

	MWIS(const string &filePath) :
			Tree(filePath) {

		computedSum = new int[numNodes];
		isIncludedSumLarger = new bool[numNodes];
		isInSet = new bool[numNodes];
		for (int i = 0; i < numNodes; i++) {
			computedSum[i] = INT_MAX;
			isIncludedSumLarger[i] = false;
			isInSet[i] = false;
		}
	}

	int computeSum(int node) { // get the value of a node and its children + grandchildren

		if (computedSum[node] != INT_MAX) { return computedSum[node]; } // return the node if it has a value

		// else go through each node
		int excl = 0; 
		int incl = weights[node];

		vector<int> &Children = adjList[node]; // grab the first level of the tree (one down from the top)
		// now go through each child 
		for (int Child : Children) { // go through each child
			excl += computeSum(Child); // increment the excl for the child
			vector<int> &grandChildren = adjList[Child]; // grandChildren of the specific node assigned
			for (int grandChild : grandChildren) {
				incl += computeSum(grandChild);
			}
		}

		if (incl > excl) { // check incl and excl for the node
			computedSum[node] = incl; // use the incl value
			isIncludedSumLarger[node] = true; // incl is larger, so mark it
		}
		else { computedSum[node] = excl; } // otherwise use excl

		return computedSum[node]; // return the nodes computedSum
	}

	void computeSet(int root) { // idenifying function of nodes to be included
		// if incl is larger than excl, use it for the root
		if (isIncludedSumLarger[root] == true) { // if INCL > EXCL
			isInSet[root] = true;
		}

		// now look through each child
		vector<int> &listOfRoots = adjList[root]; // look through the roots
		for (int Child : listOfRoots) { // search through each child for the root
			computeSetHelper(Child,root); // call computeSetHelper for children of intial node selected
			// go through all nodes in the set
		}
	}

private:

	void computeSetHelper(int node, int parent) { // process each child node

		if (isIncludedSumLarger[node] == true && isInSet[parent] == false) { 
			// the parent cannot be included + must have INCL > EXCL , to include this child (two conditions)
			isInSet[node] = true;
		}
		vector<int> &listOfChildren = adjList[node]; // look through the children of the children
		for (int grandChildren : listOfChildren) { // children of children set
			computeSetHelper(grandChildren,node); // recall until finished
		}

	}
};

#endif /* MWIS_H_ */
