#include <iostream>
#include <vector>
#include <string>
using namespace std;

#ifndef STRINGHEAP_H_
#define STRINGHEAP_H_

class StringHeap {

public:

	vector<string> heapArray;

public:

	string top() {
		return heapArray.at(0);
	}

private:

	void swap(int index1, int index2) { // ***
		string temp = heapArray[index1];
		heapArray[index1] = heapArray[index2];
		heapArray[index2] = temp;
	}

public:

	void insert(string& value) { // ***
		int Index = heapArray.size();
		int parentIndex = (Index - 1) / 2;
		heapArray.push_back(value);
		while (Index != 0 && heapArray[parentIndex].compare(heapArray[Index]) > 0)
		{
			swap(Index, parentIndex);
			Index = parentIndex;
			parentIndex = (Index - 1) / 2;
		}
	}

	 void extract() { // ***
		swap(0, heapArray.size() - 1);
		int currentIndex = 0;
		int leftIndex = 1;
		int rightIndex = 2;
		heapArray.pop_back();
		while (leftIndex < heapArray.size())
		{
			int minIndex = leftIndex;
			string minKey = heapArray.at(minIndex);
			if (rightIndex < heapArray.size()) {
				string rightKey = heapArray.at(rightIndex);
				if (rightKey.compare(minKey) <= 0) {
					minIndex = rightIndex;
					minKey = rightKey;
				}
			}
			if (minKey.compare(heapArray.at(currentIndex)) <= 0) {
				swap(minIndex, currentIndex);
				currentIndex = minIndex;
			}
			else
			{
				break;
			}
			leftIndex = (currentIndex * 2) + 1;
			rightIndex = leftIndex + 1;
		}
	}

	static void heapSort(string* array, int arrayLen) { // ***
		StringHeap obj;
		for (int i = 0; i < arrayLen; i++)
		{
			obj.insert(array[i]);
		}
		for (int i = 0; i < arrayLen; i++)
		{
			array[i] = obj.top();
			obj.extract();
		}
	}

	int size() {
		return heapArray.size();
	}
};

#endif /* STRINGHEAP_H_ */
