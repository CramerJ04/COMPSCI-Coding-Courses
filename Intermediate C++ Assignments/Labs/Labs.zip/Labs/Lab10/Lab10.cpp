#include <string>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

class Employee {

public:

	string employeeID;
	string name;
	string dateOfBirth;
	double salary;

	Employee(string employeeID, string name, string dateOfBirth,
			double salary) {
		this->employeeID = employeeID;
		this->name = name;
		this->dateOfBirth = dateOfBirth;
		this->salary = salary;
	}

	string toString() {
		return employeeID + ", " + name + ", " + dateOfBirth + ", "
				+ to_string(salary);
	}
};

class Bonus {

public:

	Employee *employee;
	double bonus;

	Bonus(Employee *employee, double bonus) {
		this->employee = employee;
		this->bonus = bonus;
	}
};

class BonusCalculator {

private:

	static vector<string> split(string &str, string delimeter) { // complete this function
		vector<string> tokens;
		string token; // individual tokens 
		// we want to extract strings before each "," and push it back into the array 
		int startIndex = 0;
		int endIndex = str.find(delimeter); // ","
		while (endIndex >= 0 && endIndex < str.length()) {
			token = str.substr(startIndex, endIndex - startIndex); // where do we start, how long 
			tokens.push_back(token);
			startIndex = endIndex + 1; // new starting position, next character after endIndex 
			endIndex = str.find(delimeter, startIndex); // what are we looking for, where do we start 
		}
		token = str.substr(startIndex);
		tokens.push_back(token);
		return tokens;
	}

public:

	static vector<Bonus> computeBonus(string inputFilePath,
			string errorFilePath) { // complete this function

		vector<Bonus> arg;
		ofstream myfile;
		myfile.open("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Lab10\\Lab10\\error.csv");
		myfile << "ID, Name, Date of Birth, Salary" << endl;
	
		ifstream reader("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Lab10\\Lab10\\employee.csv", ios::in);
		string line;
		while (getline(reader, line)) { // get line returns true or false 
			vector<string> info = split(line, ", ");
			if (info.at(0).size() != 11 || info.at(0).at(3) != '-' || info.at(0).at(6) != '-') {
				Employee* E = new Employee(info.at(0), info.at(1), info.at(2), stoi(info.at(3)));
				ifstream writer("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Lab10\\Lab10\\error.csv", ios::out);
				myfile << E->toString() << endl;
			}
			else {
				Employee* E = new Employee(info.at(0), info.at(1), info.at(2), stoi(info.at(3)));
				double bonus;
				if (stoi(info.at(2).substr(info.at(2).size() - 4)) >= 1990) {
					bonus = E->salary * 0.04;
					arg.push_back(Bonus(E, bonus));
				}
				else if (stoi(info.at(2).substr(info.at(2).size() - 4)) >= 1980 && stoi(info.at(2).substr(info.at(2).size() - 4)) < 1990) {
					bonus = E->salary * 0.06;
					arg.push_back(Bonus(E, bonus));
				}
				else if (stoi(info.at(2).substr(info.at(2).size() - 4)) >= 1970 && stoi(info.at(2).substr(info.at(2).size() - 4)) < 1980) {
					bonus = E->salary * 0.08;
					arg.push_back(Bonus(E, bonus));
				}
				else {
					bonus = E->salary * 0.10;
					arg.push_back(Bonus(E, bonus));
				}
			}
		}
		reader.close();
		myfile.close();
		return arg;
	}
};

int main() {
	vector<Bonus> bonuses = BonusCalculator::computeBonus("employee.csv",
			"error.csv");
	for (int i = 0; i < bonuses.size(); i++)
		cout << bonuses[i].employee->toString() << ", " << bonuses[i].bonus
				<< endl;
}

