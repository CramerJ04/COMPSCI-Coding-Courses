#pragma once
#ifndef HASHINGWITHPROBING_H_
#define HASHINGWITHPROBING_H_

class HashingWithProbing {

public:

	int* hashTable;
	int TABLE_SIZE;
	int size;
	int garbage;

	static const int EMPTY = -1;
	static const int TOMBSTONE = -9;

	HashingWithProbing(int tableSize) {
		TABLE_SIZE = tableSize;
		size = 0;
		garbage = 0;
		hashTable = new int[TABLE_SIZE];
		for (int i = 0; i < TABLE_SIZE; i++)
			hashTable[i] = EMPTY;
	}

private:

	int getHashValue(int val) {
		return (37 * val + 61) % TABLE_SIZE;
	}

	void resize(int newTableSize) { // complete this method
		int keyCounter = 0;
		int* keys = new int[size]; // dynamic array, size represents the number of values that are present in the hash table
		// size represents the value of values in the current table
		for (int i = 0; i < TABLE_SIZE; i++) {
			int temp = hashTable[i];
			if (temp >= 0) { // the values in the current table aren't tombstones 
				keys[keyCounter] = temp; // size of keys is determined. Put the values in if they are >= 0 
				keyCounter++;
				// key array will be full after this operation
			}
		}

		TABLE_SIZE = newTableSize; // the new table size will be the resized table. Either double or half 
		hashTable = new int[TABLE_SIZE]; // allocating TABLE_SIZE many cells for hashTable
		for (int i = 0; i < TABLE_SIZE; i++) {
			hashTable[i] = EMPTY; // fills the new table with empty cells 
		} // table is now resized 

		int oldSize = size; 
		size = 0; 
		garbage = 0; // number of tombstones in the table, resizing ignores tombstones

		for (int i = 0; i < oldSize; i++) {
			insert(keys[i]);
		}
		// size will be restored to its initial value 
		
	}

public:

	int search(int key) { // searches for a key within the table 
		int temp = getHashValue(key); // obtains the value for the key 
		for (int i = 0; i < TABLE_SIZE; i++) {
			if (hashTable[temp] == key) { // key has been found at the index
				return temp; // so return the index 
			}
			if (hashTable[temp] == EMPTY) { // the location is empty - thus the key cannot be found past this  
				return -1; 
			}
			temp++; // moving to the next slot after both checks have been done 
			if (temp == TABLE_SIZE) { // if the end of the table is reached, reset temp to complete the process from the beginning 
				temp = 0;
			}
		}
		return -1; // if the entire table is travered without finding key 
	}

	int insert(int val) { // works in a similar way to search 
		if (size + garbage == TABLE_SIZE) { // the table is full, unable to insert 
			resize(2*size); // double the size of the table 
		}
		int temp = getHashValue(val);
		for (int i = 0; i < TABLE_SIZE; i++) {
			if (hashTable[temp] == val) { // val has been found at the index temp
				return -1; // insertion isn't needed 
			}
			if (hashTable[temp] == EMPTY) { // empty slot reached, break away from the loop (to insert)
				break;
			}
			temp++;
			if (temp == TABLE_SIZE) {
				temp = 0; 
			}
		}
		hashTable[temp] = val; // insert the value in the table, at temp 
		size++; // size is incremented, representing the number of elements 
		return temp; // return the index at which the insert operation was done 
	}

	int remove(int val) { // complete this method
		int index = search(val); // should give an index, or not 
		if (index < 0) { // value isn't found in the table
			return -1; // nothing to remove 
		}
		else { // if the number is to be removed
			hashTable[index] = TOMBSTONE; // put a tombstone in
			garbage++; // number of tombstones increases
			size--; // size of filled slots increases 
		}
		return index; // return the index at which the deletion was carried out 
	}
};

#endif /* HASHINGWITHPROBING_H_ */