#include "PS1.h";
#include <iostream>
using namespace std;

int main()
{
	Point2d A(5,7,'A'); // objects 
	Point2d B(13,19,'B');
	Point2d C(21,17,'C');
	Point2d D(9,13,'D');
	
	Point2d midPointAB = A.midpoint(B); 
	cout << "Midpoint A and B is: ";
	midPointAB.print();
	cout << endl;
	Point2d midPointBC = B.midpoint(C);
	cout << "Midpoint B and C is: ";
	midPointBC.print();
	cout << endl;
	Point2d midPointCD = C.midpoint(D);
	cout << "Midpoint C and D is: ";
	midPointCD.print();
	cout << endl;
	Point2d midPointAC = A.midpoint(C);
	cout << "Midpoint A and C is: ";
	midPointAC.print();
	cout << endl;

	cout << "Area of A, B, and C is " << A.area(&B, &C);

	cout << "Number of points created = " << Point2d::numberOfPoints() << endl; // static so you don't need an object 
	// static with (.) are deleted right away 
	// no need for the delete function

	return 0;
}

int Point2d::numInstancesCreated = 0;