#include <iostream>
#include <climits>
#include <string>
using namespace std;

#ifndef ODDEVENSTACK_H_
#define ODDEVENSTACK_H_

class OddEvenStack {

private:

	int maxStackSize, oddTos, evenTos;
	int* stack;
	int counter = 0;

public:

	OddEvenStack(int maxStackSize) { // complete the constructor
		this->maxStackSize = maxStackSize;
		int value = maxStackSize;
		cout << maxStackSize << endl;
		stack = new int[value];
		for (int i = 0; i <= maxStackSize; i++) {
			stack[i] = 0;
			cout << stack[i] << endl;
		}
		this->oddTos = -1;
		this->evenTos = maxStackSize;
	}

	void push(int val) {
		if (counter == maxStackSize) {
			cout << "Odd even stack is full." << endl;
		}
		else {
			counter++;
			if (val % 2 == 0) { // number is even 
				evenTos--;
				//counter++;
				stack[evenTos] = val; // values are incremented and val is stored accordingly 
			}
			else { // number is odd
				oddTos++;
				//counter++;
				stack[oddTos] = val;
			}

		}
	}

	int popOdd() { 
		if (oddTos == -1) {
			cout << "There is no odd number to return in OddEvenStack." << endl;
			return -999;
		}
		else {
			counter--;
			int y = stack[oddTos];
			oddTos--;
			return y;
		}
	}

	int popEven() { 
		if (evenTos == maxStackSize) {
			cout << "There is no even number to return in OddEvenStack." << endl;
			return -999;
		}
		else {
			counter--;
			int j = stack[evenTos];
			evenTos++;
			return j;
		}
	}

	int size() { // calculation of size 
		//int e = maxStackSize;
		//int o = -1;
		int x = (maxStackSize - evenTos) + (oddTos + 1);
		cout << "Size of OddEvenStack is: "; 
		return x;
	}

	string toString() {
		string out = "[";
		for (int i = 0; i < maxStackSize - 1; i++) {
			out += to_string(stack[i]) + ", ";
		}
		out += to_string(stack[maxStackSize - 1]) + "]";
		return out;
	}
};

#endif /* ODDEVENSTACK_H_ */
