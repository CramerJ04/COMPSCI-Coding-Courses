#include <iostream>
using namespace std;


class Point2d
{
private: 
	double x;
	double y;
	char name;
	static int numInstancesCreated; // private static variable

public: 
	void print()
	{
		cout << "(" << x << "," << y << "," << name << ")";
	};

	Point2d(double a, double b, char c) // how many times has this been called?
	{
		x = a;
		y = b;
		name = c;
		numInstancesCreated++;
	};

	Point2d midpoint(Point2d& arg)
	{
		double xMid = (x + arg.x / 2); // arg. x is the x of the argument 
		double yMid = (y + arg.y / 2);
		cout << x << endl;
		cout << y << endl;
		cout << arg.x << endl;
		cout << arg.y << endl; // A.midpoint(B)

		Point2d mid(xMid, yMid, 'M');
		return mid;

	};

	// static variables must be returned statically 
	static int numberOfPoints()
	{
		return numInstancesCreated;
	};

	double area(Point2d* p, Point2d* q) // same thing but with three points 
	{
		double a = x * (p->y - p->y) + p->x * (q->y - y) + q->x * (y - p->y);
		a = a / 2;
		a = abs(a);
		return a;
	}

};