#include <string>
#include <iostream>

using namespace std;

int main()
{
	// explicit constructor calls 
	string str0 = "apple"; // opperator overloading 
	string str1("banana");

	string str2 = " "; // empty initialization good practice, not str2;

	cout << str0 << endl;

	// accessing a particular character 
	cout << str0.at(3) << endl; // displays L, is an array so count like it 
	cout << str0[3] << endl; // same output array style 

	// length command 
	cout << str1.length(); // displays 6, length of the string 

	// out of bounds access 
	// cout << str1.at(str1.length()) << endl; // trying to access an access that isn't defined 
	// cout << str1.[str1.length()] << endl; // gives junk output - don't do this 
	// use functions of the string classes, use at more often to pinpoint issues 

	string str3 = "banana_apple";
	string str4 = "_orange";
	str3.append(str4); // append 
	str3 += str4;
	cout << str3 << endl; // displays banana apple orange orange 

	// eracing part of a string 
	str3.erase(6); // erase everything starting from index 6
	cout << str3 << endl;

	str3.erase(6,5); // erase 5 characters starting from index 6
	cout << str3 << endl;
	// displays banana orange orange 

	str3.insert(6, "$wxyz#"); // starting at index 6, insert this 
	cout << str3 << endl;

	str3.replace(6, 5, "$exyz#"); // starting at index 6, replace the next 5 characters 
	cout << str3 << endl;


	return 1;
}