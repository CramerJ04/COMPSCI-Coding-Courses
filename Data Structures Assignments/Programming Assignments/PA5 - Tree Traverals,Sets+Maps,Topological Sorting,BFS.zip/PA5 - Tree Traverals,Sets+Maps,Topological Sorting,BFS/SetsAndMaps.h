#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
using namespace std;

#ifndef SETSANDMAPS_H_
#define SETSANDMAPS_H_

class SetsAndMaps {

public:

		//unordered_set<int> mySet; // creation of unordered set 
		//mySet.size(); // grabs size of the set 
		//mySet.insert(x) // inserts x if it's not present - else there isn't a change
		//if (mySet.find(x) != mySet.end()) // checks if x is already in the set 
		/*set<int>::iterator it = mySet.begin();
		while (it != mySet.end()) {
			cout << *it << " ";
			++it;
			*/
		// prints all of the values present in the set 
		// unordered set<int>::iterator it for an unordered set 

		//////////////////////

		// map<int, char> myMap // creation of an ordered map 
		// unordered_map<int, char> myMap // creation of unordered map
		// myMap.size() // gets size of map 
		// myMap[key] = value // inserts an integer keyvalue pair. this will add the pair if it is not
			// present, else it will update the existing value of key with the �new� value.
		// if(myMap.find(key) != myMap.end()) // checks if the map already contains a particular key - true if found 
		// int value = myMap[key] // gets the value on a particular key 
			// check if the map contains a key before getting a value

		/*map<int, char>::iterator it = myMap.begin();
		while (it != myMap.end()) { // as long as there is an entry
			int key = it->first; // obtain the key from the iterator
			char value = myMap[key]; // get the value corresponding to the key
			// can also use: char value = it -> second;

			++it; // move the iterator to the next entry (if exists)
			cout << key << ": " << value << endl;
			*/
		// printing all the keys and values 
		// unordered map<int, char>::iterator it for an unordered set 



	static vector<char> sortedAlphabet(char* arr, int len) { 
		set<char> mySet; // creation of a ordered set 
		//char* mySetArray = new char[];  
		vector<char> mySetVector;
		for (int i = 0; i < len; i++) {
			mySet.insert(arr[i]); // inserts all characters from the array into the set 
		}
		// duplicates are removed at this point, sets only keep unique numbers 
		set<char>::iterator it = mySet.begin();
		while (it != mySet.end()) { // go through the set 
			char x = *it; // take a part of the set 
			mySetVector.push_back(x); // put it in the array 
			it++; // increment 
		}
		return mySetVector;

	}

	static void bstSort(char* arr, int len) { 
		map<char, int> myMap; // creation of an ordered map
		for (int i = 0; i < len; i++) {
			char x = arr[i];
			if (myMap.find(x) == myMap.end()) { // search through the map to see if x is not present 
			myMap[x] = 1;
			}
			else {
				int value = myMap[x]; // returns how many times x has been seen 
				myMap[x] = value + 1; // controls how many times x has been seen 
			}
		}
		map<char, int>::iterator it = myMap.begin();
		int counter = 0;
		while (it != myMap.end()) { // as long as there is an entry
			char key = it->first; // obtain the key from the iterator
			int value = myMap[key]; // get the value corresponding to the key
			// can also use: char value = it -> second;
			for (int i = 0; i < value; i++) {
				arr[counter] = key; // actual character;
				counter++;
			}
			++it; // move the iterator to the next entry (if exists)
			cout << key << ": " << value << endl;
		}
	}

	static bool zeroSumSubArray(int* arr, int len) { // looks through an array to find sub arrays that add to zero, from a specific point 
		unordered_set<int> mySet; // creation of unordered set 
		int prefixSum = 0;
		for (int i = 0; i < len; i++) {
			prefixSum += arr[i];
			if (prefixSum == 0) { // one number zeroSumArray, or adding numbers simply gave a zerosum
				return true;
			}
			if (mySet.find(prefixSum) != mySet.end()) {// checks if prefixSum is already in the set
				// would indicate that a zero sum array is present
				return true;
			}
			mySet.insert(prefixSum); // put the number into the set 
		}
		return false; // sub array was never found 
	}
	

	static vector<int> kHeavyHitters(int* arr, int len, int k) { // 
		map<int, int> myMap;
		vector<int> HeavyHitterVector;
		for (int i = 0; i < len; i++) {
			char x = arr[i];
			if (myMap.find(x) == myMap.end()) { // search through the map to see if x is not present 
				myMap[x] = 1; // if not, add one to the map (x,y)
			}
			else {
				int value = myMap[x]; // returns how many times x has been seen 
				myMap[x] = value + 1; // controls how many times x has been seen 
			}
		}
		map<int, int>::iterator it = myMap.begin(); // key, value 
		while (it != myMap.end()) { // as long as there is an entry
			int key = it->first; // obtain the key from the iterator
			int value = myMap[key]; // get the value corresponding to the key
			// can also use: char value = it -> second;

			if (value > (len / k)) { // if the value of a number is larger than the designated len/k
				HeavyHitterVector.push_back(key);
			}
			++it; // move the iterator to the next entry (if exists)
			//cout << key << ": " << value << endl;
		}
		return HeavyHitterVector;
	}
	
};

#endif /* SETSANDMAPS_H_ */
