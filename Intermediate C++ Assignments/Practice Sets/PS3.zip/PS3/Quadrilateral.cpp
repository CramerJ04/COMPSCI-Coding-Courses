#include <iostream>
using namespace std;

class Point
{
public: 

	double x, y;
	Point(double x, double y)
	{
		this->x = x;
		this->y = y;
	}

	~Point()
	{
		cout << "(" << x << "," << "y" << y << ") destroyed." << endl;
 	}

	double distance(Point* arg)
	{
		double xDiff = x - arg->x; 
		double yDiff = y - arg->y;
		return sqrt(xDiff * xDiff + yDiff * yDiff);
	}

	double area(Point* arg1, Point* arg2)
	{
		return abs(
			x * (arg1->y - arg2->y) + arg1->x * (arg2->y - y) + arg2->x * (y - arg1->y)) / 2.0;
	}
};

class Quadrilateral {
public:

	Point** corners;

	/*Quadrilateral(double* xS, double* yS, int N)
	{
		corners = new Point * [N]; // allocation 
		corners[0] = new Point(xS[0], yS[0]);
		corners[1] = new Point(xS[1], yS[1]);
		corners[2] = new Point(xS[2], yS[2]);
		corners[3] = new Point(xS[3], yS[3]);
	}*/

	// OR 

	Quadrilateral(double* xS, double* yS)
	{
		corners = new Point * [4];
		for (int i = 0; i < 4; i++) // loop used here, good practice 
		{
			corners[i] = new Point(xS[i], yS[i]);
		}
	}

	double perimeter() // same thing here with the for loop 
	{
		return corners[0]->distance(corners[1])
			+ corners[1]->distance(corners[2])
			+ corners[2]->distance(corners[3])
			+ corners[3]->distance(corners[0]);
	}

	double area()
	{
		return corners[0]->area(corners[1], corners[2]) + corners[2]->area(corners[3], corners[0]);
	}
};

int main()
{
	double xS[] = {0,10,13,5};
	double yS[] = {0,0,21,12};
	Quadrilateral Quad(xS, yS);
	cout << Quad.perimeter() << endl; // these functions rely on the shape !!! 
	cout << Quad.area() << endl;
	return 1;
}