#include <cmath>
#include <iostream>
using namespace std;

class Point
{
public:
	double x, y;
	Point(double x, double y) // captures points and makes then into arguments 
	{
		this->x = x;
		this->y = y;
	}

	double distance(Point* arg) // computes distance between points 
	{
		double xdiff = x - arg->x;
		double ydiff = y - arg->y;
		return sqrt(xdiff * xdiff + ydiff * ydiff);
	}
	double area(Point* arg1, Point* arg2)
	{
		return abs(x * (arg1->y - arg2->y) + arg1->x * (arg2->y - y) + arg2->x * (y - arg1->y)) / 2.0;
	}

	//Point() // basic constructor 
		// constructor overloading meaning two constructors within the same class 
	//{
		//x = 0;
		//y = 0;
	//}
};

class Triangle
{
	Point** corners;// pointer to an array of point type pointers 

public:

	Triangle(double *xS, double *yS, int n) // arrays for the points, and a value for the length of user input 
	{
		corners = new Point * [n]; // creating cells based on user input 
		corners[0] = new Point(xS[0], yS[0]); // type of type point 
		corners[1] = new Point(xS[1], yS[1]);
		corners[2] = new Point(xS[2], yS[2]);
	}

	double perimeter()
	{
		double a = corners[0]->distance(corners[1]); // cell 1 
		double b = corners[1]->distance(corners[2]); // cell 2
		double c = corners[2]->distance(corners[0]); // cell 3

		return a + b + c;

	}

	double area()
	{
		return corners[0]->area(corners[1], corners[2]); // method is already made 
	}
};

int main()
{
	double xS[] = { 5,13,19 };
	double yS[] = { 7,14,26 };
	Triangle t(xS, yS, 3); // constructor changes due to parameters 
	cout << t.perimeter() << endl;
	cout << t.area();
	return 1;
}