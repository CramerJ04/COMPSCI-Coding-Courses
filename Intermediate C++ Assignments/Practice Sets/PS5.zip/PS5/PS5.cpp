#include <iostream>
using namespace std;

class PS5
{
public: 

	static void create2dArray()
	{
		int numR, numC;
		cout << "Enter the number of rows: ";
		cin >> numR;
		cout << "Enter the number of columns: ";
		cin >> numC;
		cout << endl;

		int** arr = new int* [numR]; // creates array of pointers (pointers only)
		// now must allocate memory. Pointers are pointing to nothing 
		for (int r = 0; r < numR; r++)
		{
			arr[r] = new int[numC]; // creates columns for each pointer 
			// allocating numC cells for row r 
			// now we want to fill the rows 
			for (int c = 0; c < numC; c++)
			{
				cout << "Enter a value for the row " << r << " and comumn " << c << ": ";
				cin >> arr[r][c];
			}
			cout << endl;
		}
		cout << endl;
		for (int r = 0; r < numR; r++) // display 
		{
			for (int c = 0; c < numC; c++)
			{
				cout << arr[r][c];
			}
			cout << endl;
		}
	}

	static void createJaggedArray()
	{
		int numR;
		cout << "Enter the number of rows: ";
		cin >> numR;
		cout << endl;

		int** arr = new int* [numR]; // creates array of pointers (pointers only)
		// now must allocate memory. Pointers are pointing to nothing 

		int* numC = new int[numR]; // makes array of length 4 
		for (int r = 0; r < numR; r++)
		{
			cout << "Enter the number of columns for row " << r << ": "; // ask here 
			cin >> numC[r];
			arr[r] = new int[numC[r]]; // creates columns for specific pointer 
			for (int c = 0; c < numC[r]; c++)
			{
				cout << "Enter a value for the row " << r << " and column " << c << ": ";
				cin >> arr[r][c];
			}
			cout << endl;
		}
		cout << endl;
		for (int r = 0; r < numR; r++) // display 
		{
			for (int c = 0; c < numC[r]; c++) // must fix numC, rows have different values 
			{
				cout << arr[r][c];
			}
			cout << endl;
		}

		for (int r = 0; r < numR; r++) // deallocating 
		{
			delete[]arr[r]; // deletes the array at row r (entire rows)
			delete[]arr; // deletes pointers 
		}


	}

	static void shiftRowsDown()
	{
		int arr[3][4] = { {0,1,2,3}, {4,5,6,7}, {8,9,10,11} };
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 4; j++)
			{
				cout << arr[i][j] << " "; 
			}
			cout << endl; 
		}

		for (int i = 2; i > 0; i--)
		{
			for (int j = 0; j < 4; j++)
			{
				swap(arr[i][j], arr[i - 1][j]); // idea is to go over the array, and swap the last element with the one before it 
			}
			cout << endl;
		}

		for (int i = 0; i < 3; i++) 
		{
			for (int j = 0; j < 4; j++)
			{
				cout << arr[i][j] << " ";
			}
			cout << endl;
		}
	}

	static void transpose()
	{
		int A[4][4] = { {1,2,3,4}, {5,6,7,8}, {9,10,11,12}, {13,14,15,16} };
		for (int i = 0; i < 4; i++)
		{
			for (int j = i + 1; j < 4; j++)
			{
				swap(A[i][j], A[j][i]);
			}
		}
		for (int i = 0; i < 4; i++) // display 
		{
			for (int j = 0; j < 4; j++)
			{
				cout << A[i][j] << " ";
			}
		}

	}

	static void anotherShiftTechnique()
	{
		int A[4][4] = { {1,2,3,4}, {5,6,7,8}, {9,10,11,12}, {13,14,15,16} };
		for (int i = 0; i < 3; i++)
		{
			swap(A[i], A[i + 1]);
		}
		for (int i = 0; i < 4; i++) // display 
		{
			for (int j = 0; j < 4; j++)
			{
				cout << A[i][j] << " ";
			}
		}
	}
};

int main()
{
	//PS5::shiftRowsDown();
	//PS5::create2dArray();
	PS5::createJaggedArray();
	PS5::transpose();
	PS5::anotherShiftTechnique();
	return 1;
}