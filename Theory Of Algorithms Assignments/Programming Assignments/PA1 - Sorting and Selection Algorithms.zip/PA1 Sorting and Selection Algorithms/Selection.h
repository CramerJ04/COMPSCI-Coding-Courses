#ifndef SELECTION_H_
#define SELECTION_H_

#include "Partition.h"

class Selection {

public:

	static int select(int *array, int n, int k) {
		return quickSelect(array, 0, n - 1, k);
	}

private:

    static int quickSelect(int *array, int left, int right, int k) { // XXXXXXXXXXXXXXXXXXXX
	if (left == right){
		return left;
	}

	int pivotIndex = Partition::generateRandomPivot(array, left, right);
	int* partitionIndexes = Partition::onePassTwoIndexPartition(array, left, right, pivotIndex);

	if (k >= partitionIndexes[0] + 1 && k <= partitionIndexes[1] + 1){	// 
		return partitionIndexes[0];
	}
	else if (k < partitionIndexes[0] + 1){
		return quickSelect(array, left, partitionIndexes[0] - 1, k); // 
	}
	else {	
		return quickSelect(array, partitionIndexes[1] + 1, right, k); // 
	}

};
};

#endif /* SELECTION_H_ */
