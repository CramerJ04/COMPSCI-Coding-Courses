#include <iostream>
using namespace std;

class Minimum
{
private:

public:

    static int minimumIndex(int* arr, int len, int left, int right)
    {
        if (left < 0 || left > right || right >= len) // checks bounds 
        {
            return -1;
        }
        int minIndex = left; // sets minimum to left side 
        for (int i = left + 1; i <= right; i++)
        {
            if (arr[i] < arr[minIndex]) // goes through each INDEX, and sets the minimum to the value in the array that is minimum 
            // Minimum must have a initial value 
            minIndex = i; // is it smaller? If so update 
        }
        return minIndex; // returns INDEX after the whole array has been processed 

    };

    static int minimumIndex(int* arr, int len)
    {
        return minimumIndex(arr, len, 0, len - 1);
    }

};

class Prime
{
private: 
public: 

    static bool isPrime(int A)
    {
        if (A <= 1) // number cannot be prime 
        return false;
        if (2 == A || 3 == A) // number will always be prime 
        return true;
        if (A % 2 == 0)
        return false;

        for (int i = 3; i <= A / 2; i++) // i <= sqrt(A) will also work, in fact preferable 
        {
            if (A % i == 0)
            return false;
        }

        /*if (((A / A) == 1) || (A / 1 == A)) // prime number checking 
        {
        return true;
        }
        else 
        return false;*/
    }

    static int countPrime(int* arr, int len, int left, int right)
    {
        if (left < 0 || left > right || right >= len) // checks bounds 
        {
            return -1; // invalid arguments 
        }
        int counter = 0;
        for (int i = left; i <= right; i++)
        {
            if (isPrime(arr[i])) // calls isPrime with selected element in the array 
            {
                counter++;
            }
            return counter;
        }
    }
    static int countPrime(int* arr, int len)
    {
        int x = countPrime(arr, len, 0, len - 1); 
        return x; 
    }

    static int countPrime(int arr, int len, int left, int right) // take prime numbers - length of array 
    // right - left + 1, right - left leaves out the left element 
    {
        int x = countPrime(arr, len, left, right);
        if (x < 0)
        return x; // invalid arguments 

        return (right - left + 1) - x; // length of the array - number of primes 

    }

    static int countNonPrime(int* arr, int len)
    {
        int x = countPrime(arr, len, 0, len - 1); // primes deleting FROM x 
        return len - x;
    }

    static int countNonPrime(int arr, int len, int left, int right) // take prime numbers - length of array 
    // right - left + 1, right - left leaves out the left element 
    {
        int x = countPrime(arr, len, left, right);
        if (x < 0)
        return x; // invalid arguments 

        return (right - left + 1) - x; // length of the array - number of primes 

    }

};


int main()
{
    int arr[] = { 47, -7, 21, 1, 11, -13, 1, 17 };
    int len = sizeof(arr) / sizeof(int); // not hardcosing the length. If the array was changed, this would work no matter what 
    cout << Minimum::minimumIndex(arr, len) << endl;
    cout << Minimum::minimumIndex(arr, len, -5, 4) << endl;
    cout << Minimum::minimumIndex(arr, len, 0, len) << endl;
    cout << Minimum::minimumIndex(arr, len, 4, 3) << endl;
    cout << Minimum::minimumIndex(arr, len, 0, 4) << endl;
    cout << Minimum::minimumIndex(arr, len, 0, 5) << endl;
    cout << Minimum::minimumIndex(arr, len, 2, 4) << endl;

}
