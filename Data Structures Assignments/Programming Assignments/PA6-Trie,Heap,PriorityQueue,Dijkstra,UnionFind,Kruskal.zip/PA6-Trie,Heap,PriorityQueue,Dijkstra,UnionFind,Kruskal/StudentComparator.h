#include "Student.h"

#ifndef STUDENTCOMPARATOR_H_
#define STUDENTCOMPARATOR_H_

class StudentComparator { // ***
public:
    bool operator()(Student& arg1, Student& arg2)
    {
        if (arg1.grade != arg2.grade )
        {
            return (arg1.grade > arg2.grade);
        }
        else
        {
            return (arg1.name > arg2.name);
        }
    }
};

#endif /* STUDENTCOMPARATOR_H_ */
