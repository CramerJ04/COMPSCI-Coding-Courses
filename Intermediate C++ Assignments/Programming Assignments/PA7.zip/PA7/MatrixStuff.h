#include <iostream>
using namespace std;

class MatrixStuff {
    
private:

    static int **multiplySquare(int **A, int **B, int n) {
        int **M = new int *[n];
        for (int r = 0; r < n; r++) {
        	M[r] = new int[n];
	        for (int c = 0; c < n; c++) {
	            M[r][c] = 0;
	            for (int k = 0; k < n; k++)
	                M[r][c] += A[r][k] * B[k][c];
	        }
        }
        return M;
    }
    
public:
    
    static bool isOrthogonal(int **matrix, int n) {
        int count = 0;
        int** B = matrix;

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                B[j][i] = matrix[i][j]; // writing the transpose of A, rows become columns 
            }
        }
        int** M = multiplySquare(matrix, B, n);
        int val = 0;
        int temp = 0;
            for (int i = 0; i < n; i++) {
                if (M[i][i] = 1) {
                    val++;
                    cout << val;
                }
            }
            if (val = n) {
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < n; j++) {
                        temp += M[i][j];
                    }
                }
                if (temp != n)
                    return false;
                else
                    return true;
            }
            if (val != n) {
                return false;
            }
    } 
 
    static int determinant(int** matrix, int n) { // complete this function

        int det = 0;
        int** cofactor;
        cofactor = new int* [n - 1];
        for (int i = 0; i < n - 1; i++) {
            cofactor[i] = new int[n - 1];
        }

        if (n == 1) {
            return matrix[0][0];
        }
        if (n == 2) {
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        }

        for (int c = 0; c < n; c++) {
            int row = 0;
            for (int i = 1; i < n; i++) {
                int column = 0;
                for (int j = 0; j < n; j++) {
                    if (j == c) { // if c = c, skip it 
                        continue;
                    }
                    cofactor[row][column] = matrix[i][j];
                    column++;
                }
                row++;
            }
            if (c % 2 == 0) { // even number 
                int m = determinant(cofactor, n - 1);
                det += (m * matrix[0][c]);
            }
            else { // odd number 
                int d = determinant(cofactor, n - 1);
                det -= (d * matrix[0][c]);
            }
        }
        return det;
    }
        
};
