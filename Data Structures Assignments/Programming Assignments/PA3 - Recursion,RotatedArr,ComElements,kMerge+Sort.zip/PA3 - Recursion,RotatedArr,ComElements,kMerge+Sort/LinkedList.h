#include "ListNode.h"

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

class LinkedList {

private:

	ListNode* head, * tail;
	int size;
	int* mergedArray;

public:

	LinkedList() {
		head = tail = NULL;
		size = 0;
		mergedArray = NULL;
	}

	void mergesort() {
		mergedArray = new int[size];
		mergesort(0, size - 1, head, tail);
		delete[] mergedArray;
	}

private:

	void mergesort(int left, int right, ListNode* leftNode,
		ListNode* rightNode) { // cannot access a index directly - traversing is neccessary 
		//cout << "llllllll" << endl;
		if (left >= right) {
			return;
		}
		else {
			int mid = (left + right) / 2;
			ListNode* midNode = leftNode;
			for (int i = left; i < mid; i++) {
				midNode = midNode->next; // finds mid
			}
			mergesort(left, mid, leftNode, midNode);
			mergesort(mid + 1, right, midNode->next, rightNode); // both sides come out sorted
			int k = left; 
			ListNode* temp1 = leftNode;
			ListNode* temp2 = midNode->next;
			//cout << "cccccccc" << endl;
			while (temp1 != midNode->next && temp2 != rightNode->next) { // boundaries
				if (temp1->value < temp2->value) {
					mergedArray[k++] = temp1->value;
					temp1 = temp1->next;
				}
				else {
					mergedArray[k++] = temp2->value;
					temp2 = temp2->next;
				}
			} // array sorted 
			//cout << "sssssssss" << endl;
			while (temp1 != midNode->next) { // left over of first reaches mid
				mergedArray[k++] = temp1->value;
				temp1 = temp1->next;
			}
			//cout << "uuuuuu" << endl;
			while (temp2 != rightNode->next) { // left over reaches out of bounds 
				mergedArray[k++] = temp2->value;
				temp2 = temp2->next;
			} // now that the array is sorted, move the elements back into a list 
			k = left; 
			ListNode* temp = leftNode;
			//cout << "QQQQQQ" << endl;
			while (temp != rightNode->next) {
				temp->value = mergedArray[k++];
				temp = temp->next;
			}
		}
	}

public:

	ListNode* insertAtFront(int value) {
		ListNode* newNode = new ListNode(value);
		if (size == 0) {
			head = tail = newNode;
		}
		else {
			newNode->next = head;
			head = newNode;
		}
		size++;
		return newNode;
	}

	ListNode* insertAtEnd(int value) {
		ListNode* newNode = new ListNode(value);
		if (size == 0) {
			head = tail = newNode;
		}
		else {
			tail->next = newNode;
			tail = newNode;
		}
		size++;
		return newNode;
	}

	void printList() {
		if (size == 0)
			cout << "[]" << endl;
		else {
			ListNode* tmp = head;
			cout << "[";
			for (int i = 0; i < size - 1; i++) {
				cout << tmp->value << " -> ";
				tmp = tmp->next;
			}
			cout << tail->value << "]" << endl;
		}
	}

	int getSize() {
		return size;
	}
};

#endif /* LINKEDLIST_H_ */
