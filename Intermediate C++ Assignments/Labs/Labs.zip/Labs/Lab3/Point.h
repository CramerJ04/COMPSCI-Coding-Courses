#include <iostream>
#include <cmath>
#include <limits>
using namespace std;

#ifndef POINT_H_
#define POINT_H_

class Point {

public:

	double x, y;

	Point(double x, double y) {
		this->x = x;
		this->y = y;
	}

	~Point() {
		cout << "(" << x << "," << "y" << y << ") destroyed" << endl;
	}

	double distance(Point *arg) {
		double xDiff = x - arg->x;
		double yDiff = y - arg->y;
		return sqrt(xDiff * xDiff + yDiff * yDiff);
	}
};

class Segment
{
public: 
	Point *start, *end;
	char name;

	Segment(char name, Point *start, Point *end)
	{
		this->start = start;
		this->end = end;
		this->name = name;
	}
	~Segment()
	{
		cout << "Point (" << start->x << "," << end->x << ") deleted." << endl;
		cout << "Point (" << start->y << "," << end->y << ") deleted." << endl;
	}
	double length()
	{
		return start->distance(end);
	};

	double slope()
	{
		if (start->x == end->x)
		{
			return numeric_limits<double>::infinity();
		}
		else
		return (start->y - end->y) / (start->x - end->x);
	};

	void check(Segment* arg)
	{
		if (this->slope() == arg->slope())
		{
			cout << "Parallel!" << endl;
		}
		if (this->slope() != arg->slope())
		{
			cout << "Not parallel!" << endl;
		}
	}


};
#endif /* POINT_H_ */
