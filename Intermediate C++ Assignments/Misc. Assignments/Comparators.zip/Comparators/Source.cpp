#include <string>
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;

class Student {
public: 
	string name;
	int grade;

	Student(string name, int grade) {
		this->name = name;
		this->grade = grade;
	}

	Student() {
		name = "";
		grade = 0;
	}

	string toString() {
		return "(" + name + "," + to_string(grade) + ")";
	}
};

static vector<Student> readStudents(string filePath) {
	vector<Student> students;
	ifstream inputF;
	inputF.open(filePath);
	string name;
	int grade;

	while (!inputF.eof()) { // while file hasn't read to the end of the file 
		// loop runs around over and over until the end of the file 
		// we could use delimiters, but this is another method 
		inputF >> name;
		inputF >> grade;
		Student s(name, grade);
		students.push_back(s);
	}
	inputF.close();
	return students;
}

class StringComparator {
public:

	bool operator()(const string& arg1, const string& arg2) const { // const means the string isn't going to change within the function
		return arg1 <= arg2;
	}
};

class StudentGradeComparator {
public:

	bool operator()(const Student& arg1, const Student& arg2) const { // const means the string isn't going to change within the function
		return arg1.grade <= arg2.grade;
	}
};

class StudentNameComparator {
public:

	bool operator()(const Student& arg1, const Student& arg2) const { // const means the string isn't going to change within the function
		return arg1.name <= arg2.name;
	}
};

template<typename T, typename F> // two templates, what kind of vector, and what kind of comparator
static T findMinimum(vector<T>& contents, F comparator) {
	int minIndex = 0;
	for (int i = 1; i < contents.size(); i++) {
		if (comparator(contents.at(i), contents.at(minIndex))) { // contents[i] < contents[minIndex] || usually you would do this, but you cannot in this instance 
			minIndex = i;
			// comparator returns true of first instance is smaller than the other being compared, and sets the index 
			// arg1 becomes contents.at(i), arg2 becomes contents.at(minIndex)
		}
	}
	return contents.at(minIndex);
};

template<typename T, typename F>
static void selectionSort(vector<T>& contents, F comparator) { // void because of no return, swapping within the vector directly 
	for (int j = 0; j < contents.size() - 1; j++) {
		int minIndex = 0;
		for (int i = j + 1; i < contents.size(); i++) {
			if (comparator(contents.at(i), contents.at(minIndex))) {
				minIndex = i;
			}
		}
		if (minIndex != j)
			swap(contents.at(minIndex), contents.at(j));
	}
}
void stringMinimum() {
	cout << "*** String Minimum ***" << endl;
	string arr[] = { "abc", "def", "abcd", "bce", "abx", "acfe", "bfr", "aab", "abcd" };
	vector<string> strings(arr, arr + sizeof(arr) / sizeof(string));
	string minimum = findMinimum(strings, StringComparator());
	cout << "Minimum is: " << minimum << endl;
};

void minimumStudentBasedOnGrade() {
	string filePath = "C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Comparators\\Comparators\\Students.txt";
	vector<Student> students = readStudents(filePath);
	cout << "Students: ";
	for (Student& arg : students) // "for each student in the vector"
		cout << arg.toString() << " ";
	cout << endl;
	Student min = findMinimum(students, StudentGradeComparator());
	cout << "Minimum student based on grade is: " << min.toString() << endl;
}

void minimumStudentBasedOnName() {
	string filePath = "C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Comparators\\Comparators\\Students.txt";
	vector<Student> students = readStudents(filePath);
	cout << "Students: ";
	for (Student& arg : students) // "for each student in the vector"
		cout << arg.toString() << " ";
	cout << endl;
	Student min = findMinimum(students, StudentNameComparator());
	cout << "Minimum student based on name is: " << min.toString() << endl;
}

int main() {
	/*string filePath = "C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Comparators\\Comparators\\Students.txt";
	vector<Student> students = readStudents(filePath);
	cout << "Students: ";

	for (Student& arg : students) // "for each student in the vector"
		cout << arg.toString() << " ";
	return 1;*/
	stringMinimum();
	minimumStudentBasedOnGrade();
	minimumStudentBasedOnName();

	string arr[] = { "abc", "def", "abcd", "bce", "abx", "acfe", "bfr", "aab", "abcd" };
	vector<string> strings(arr, arr + sizeof(arr) / sizeof(string));
	for (string& arg : strings) // original 
		cout << arg << " ";
	cout << endl;
	selectionSort(strings, StringComparator());
	for (string& arg : strings)
		cout << arg << " ";
}
