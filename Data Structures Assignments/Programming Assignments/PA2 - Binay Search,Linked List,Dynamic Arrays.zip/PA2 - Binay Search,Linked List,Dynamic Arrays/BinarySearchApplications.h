#pragma once
#include <iostream>
using namespace std;

class BinarySearchApplications {

public:

	int minIndexBinarySearch(int array[], int arrayLength, int key) { // complete this method
		int left = 0, right = arrayLength - 1;
		int minIndex = -1;
		while (left <= right) {
			int mid = (left + right) / 2;
			if (array[mid] == key) {
				//return mid;
				minIndex = mid;
				right = mid - 1;
			}
			else if (array[mid] > key)
				right = mid - 1;
			else
				left = mid + 1;
		}
		cout << "Min index is: " << minIndex << endl;
		return minIndex;
	}

	int maxIndexBinarySearch(int array[], int arrayLength, int key) { // complete this method
		int left = 0, right = arrayLength - 1;
		int maxIndex = -1;
		while (left <= right) {
			int mid = (left + right) / 2;
			if (array[mid] == key) {
				//return mid;
				maxIndex = mid;
				left = mid + 1;
			}
			else if (array[mid] > key)
				right = mid - 1;
			else
				left = mid + 1;
		}
		cout << "Max index is: " << maxIndex << endl;
		return maxIndex;
	}

	int countNumberOfKeys(int array[], int arrayLength, int key) { // complete this method
		int minvalue = minIndexBinarySearch(array, arrayLength, key);
		int maxvalue = maxIndexBinarySearch(array, arrayLength, key);
		//cout << minvalue;
		//cout << maxvalue;
		int temp = maxvalue - minvalue;
		if (minvalue = -1 && maxvalue == -1) {
			return 0;
		}
		else return temp + 1;
	}

	int predecessor(int array[], int arrayLen, int key) { // complete this method
		int left = 0, right = arrayLen - 1;
		int predIndex = -1;
		while (left <= right) {
			int mid = (left + right) / 2;
			//cout << endl << key << endl;
			cout << endl << "M: " << mid << endl;
			cout << "L: " << left;
			cout << "   R: " << right << endl;
			cout << "predIndex: " << predIndex << endl;
			if (array[mid] < key) {
				predIndex = mid;
				left = mid + 1;
			}
			if (array[mid] == key)
				return mid;
			else if (array[mid] > key)
				right = mid - 1;
			else
				left = mid + 1;
		}
		return predIndex;
	}

	int findPeak(int twoToneArray[], int arrayLen) { // complete this method
		// method is a complex way of finding the max value in an array, compared to scanning through thr array one value at a time 
		int left = 0, right = arrayLen - 1;
		int maxIndex = -1;
		while (left <= right) {
			if (left == right) {
				return left;
			}
			if (right == left + 1) {
				if (twoToneArray[right] > twoToneArray[left]) {
					return right;
				}
				else
					return left;
			}
			int mid = (left + right) / 2;
			cout << endl << "mid = " << mid;
			cout << "   left = " << left;
			cout << "   right = " << right << endl;
			if (twoToneArray[mid] < twoToneArray[mid + 1]) {
				left = mid + 1;
			}
			else if (twoToneArray[mid] < twoToneArray[mid - 1]) {
				right = mid - 1;
			}
			else
				return mid;
		}
		return -1;
	}
};
