#include <iostream>
// #include "TestStack.cpp"
using namespace std;



class Stack
{
	private:

	int topOfStack = -1; 
	int maxStackSize = 4; 
	char *stackArray = new char[maxStackSize];

	public:

		Stack(int maxStackSize)
		{
			this->topOfStack = topOfStack;
			stackArray = new char[maxStackSize];
		};

		void push(char val)
		{
			if (topOfStack == maxStackSize - 1)
			{
				cout << "Cannot push, stack is full!" << endl;
			}
			else
			{
				topOfStack++;
				stackArray[topOfStack] = val;
			}
		};
		char pop()
		{
			if (topOfStack == -1)
			{
				cout << "Cannot pop, stack is empty!" << endl;
				return '\0';
			}
			else
			{
				char temp = stackArray[topOfStack];
				topOfStack--;
				return temp;
			}

		};
		char peek()
		{
			if (topOfStack == -1)
			{
				cout << "Cannot peek, stack is empty!" << endl;
				return '\0';
			}
			else
			{
				return stackArray[topOfStack];
			}
		};
		int size()
		{
			//topOfStack++;
			return topOfStack + 1; // +1
			//topOfStack++;
		};
		void print()
		{
			if (topOfStack == -1)
			{
				cout << "[]";
			}
			else if (topOfStack == 0)
			{
				cout << "[";
				for (int i = 0; i <= topOfStack; i++)
				{
					cout << stackArray[i];
					cout << "]";
				}
			}
			else if (topOfStack != -1 || 0)
			{
				cout << "[";
				for (int i = 0; i <= topOfStack; i++)
				{
					cout << stackArray[i];
					if (topOfStack != i)
					{
						cout << ", ";
					}
				}
				cout << "]";
			};
		};
};
