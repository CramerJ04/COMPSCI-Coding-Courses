#include "Shape.h"
#include <vector>
#include <algorithm>

#ifndef SHAPESORTER_H_
#define SHAPESORTER_H_


class groupByArea {

public: 
	bool operator()(Shape* arg1, Shape* arg2) {
		return arg1->area() <= arg2->area(); 
	}
};

class groupByTypeThenVolume {
public: 
	bool operator()(Shape* arg1, Shape* arg2) {
		if (arg1->type() != arg2->type()){
			return arg1->type() <= arg2->type();
		}
		else 
			return arg1->volume() <= arg2->volume();
	}
};

class ShapeSorter {

public:

	// The functions sortByArea and sortByTypeThenVolume go in this class. The corresponding comparators also go here.

	static void sortByArea(vector<Shape*>& arg) {
		sort(arg.begin(), arg.end(), groupByArea());
	}
	static void sortByTypeThenVolume(vector<Shape*>& arg) {
		sort(arg.begin(), arg.end(), groupByTypeThenVolume());
	}

};

#endif /* SHAPESORTER_H_ */
