#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

enum ErrorCode {

	NEGATIVE_NUMBER = 0,
	NOT_A_NUMBER_X = 1,
	NOT_A_NUMBER_Y = 2
};

class Point {
public:

	double x, y;
	char name;

	Point(double x, double y, char name) {

		if (x < 0 || y < 0)
			throw(ErrorCode::NEGATIVE_NUMBER);
		this->x = x;
		this->y = y;
		this->name = name;
	}

	string toString() {
		return "(" + to_string(x) + ", " + to_string(y) + ", " + name + ")";
	}

};

class fileReader {

	static vector<string> split(string& str, string delimeter) {
		vector<string> tokens;
		string token;
		int startIndex = 0;
		int endIndex = str.find(delimeter);
		while (endIndex >= 0 && endIndex < str.length()) {
			token = str.substr(startIndex, endIndex - startIndex);
			tokens.push_back(token);
			startIndex = endIndex + delimeter.length();
			endIndex = str.find(delimeter, startIndex);
		}
		token = str.substr(startIndex);
		tokens.push_back(token);
		return tokens;
	};

	static bool isNumber(string str) {

		int countDots = 0;
		int countNeg = 0;
		string digits = "0123456789"; // could also use ASCII

		for (int i = 0; i < str.length(); i++) {
			char c = str.at(i);
			if (c == '.') {
				countDots++;
			}
			else if (c == '-') {
				countNeg++;
			}
			else {
				int index = digits.find(c); // is c within the index?
				// returns -1 if not found 
				if (index < 0 || index >= digits.length()) {
					return false;
				}
			}
			if (countNeg > 0) {
				return false;
			}
			if (countNeg == 1 && str.at(0) != '-') {
				return false;
			}
		}
		return countDots <= 1;
	}

public: 

	static void parseFile() {
		ifstream reader("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\ExceptionHandling\\ExceptionHandling\\points.txt", ios::in);
		ofstream errorWriter("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\ExceptionHandling\\ExceptionHandling\\errorPoints.txt", ios::out); // these two make documents 
		ofstream validWriter("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\ExceptionHandling\\ExceptionHandling\\validPoints.txt", ios::out);
		
		string line;
		while (getline(reader, line)) {
			vector<string> tokens = split(line, " "); // splits lines into tokens 
			cout << tokens[0] << " " << tokens[1] << " " << tokens[2] << endl;
			try {
				char name = tokens.at(0).at(0); // first entry within the tokens vector, at the first line
				if (!isNumber(tokens.at(1)) || !isNumber(tokens.at(2)))
					throw (ErrorCode::NOT_A_NUMBER_X); // here we throw 1, it becomes a function call to catching something 
				if (!isNumber(tokens.at(2)))
					throw (ErrorCode::NOT_A_NUMBER_Y); // smae thing here 
				double x = stod(tokens.at(1));
				double y = stod(tokens.at(2));

				Point p(x, y, name);
				validWriter << p.toString() << endl;
			}
			catch (ErrorCode arg) {

				if (arg == ErrorCode::NEGATIVE_NUMBER) {
					errorWriter << "Negative number exception: " << endl;
				}
				else if (arg == ErrorCode::NOT_A_NUMBER_X) {
					errorWriter << "X is not a number: " << endl;
				}
				else 
					errorWriter << "Y is not a number: " << endl;
				errorWriter << tokens.at(0) << " " << tokens.at(1) << " " << tokens.at(2) << endl;
			}
		}
		reader.close();
		errorWriter.close();
		validWriter.close();
	}
};

int main() {

	fileReader::parseFile();

	return 1; 
}