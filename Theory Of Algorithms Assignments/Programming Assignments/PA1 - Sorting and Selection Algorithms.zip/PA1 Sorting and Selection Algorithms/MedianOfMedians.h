#include "Partition.h"
#include <cmath>

#ifndef MedianOfMedians_h
#define MedianOfMedians_h

class MedianOfMedians {
    
private:
    
    static void insertionSort(int *arr, int left, int right) {
        for (int i = left + 1; i <= right; i++) {
            int j = i, temp = arr[j];
            while (j > left && temp < arr[j - 1]) {
                arr[j] = arr[j - 1];
                j--;
            }
            arr[j] = temp;
        }
    }
    
public:
    
    static int select(int *array, int n, int k) {
        return MoM(array, 0, n - 1, k);
    }
    
private:
    
    static int MoM(int *array, int left, int right, int k) { // 

    if (right - left + 1 <= 5) {// brute force option
    insertionSort(array, left, right);
    return k - 1;
    }

    int n = (right - left + 1);
    int* Medians = new int[static_cast<int>(n/5.0)]; // medians array of size n/5.0 
    // will contain all middle (median) elements of groups in A, from left to right

    int r = 0;
    for (int i = left; i <= right; i += i + 5){
        int j = min(i + 4, right); // set the smaller value 
        insertionSort(array, i, j); // insertion sort the array (small chunk)
        Medians[r] = array[(i + j)/2]; // add the median value to the medians array 
        r++;
    }
    int mom = Medians[MoM(Medians, 0, ceil(n/5.0)-1, ceil(n/5.0)/2)];
    int momIndex = 0;
    for (int i = left; i <= right; i += i + 5){ // Finding the median of medians in original array
        int j = min(i + 4, right); //
        momIndex = (i + j)/2; //

        if (array[momIndex] == mom){ //
            break;
        }
    }
    int pivotIndex = Partition::generateRandomPivot(array, left, right); // copied from selection file
    int* partitionIndexes = Partition::onePassTwoIndexPartition(array, left, right, pivotIndex); // slight change of variables 

	if (k >= partitionIndexes[0] + 1 && k <= partitionIndexes[1] + 1){	// 
		return partitionIndexes[0];
	}
	else if (k < partitionIndexes[0] + 1){
		return MoM(array, left, partitionIndexes[0] - 1, k); // 
	}
	else {	
		return MoM(array, partitionIndexes[1] + 1, right, k); // 
	}
    }
};

#endif /* MedianOfMedians_h */
