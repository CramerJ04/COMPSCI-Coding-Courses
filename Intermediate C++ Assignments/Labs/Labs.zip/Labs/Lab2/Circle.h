#include <iostream>
using namespace std;
#include <math.h>

class Circle
{
private:
	double x;
	double y;
	double radius;
	char name;
	static int numInstancesCreated;

public:

	double print()
	{
		cout << x << y << radius << name;
	}

	Circle(double x, double y, double radius, char name)
	{
		this->x = x;
		this->y = y;
		this->radius = radius;
		this->name = name;
		numInstancesCreated++;
		cout << "Circle (" << x << ", " << y << ", " << radius << ", " << name << ")" << " created." << endl;
	}

	~Circle()
	{
		cout << "Circle (" << x << ", " << y << ", " << radius << ", " << name << ")" << " destroyed." << endl;
	}

	void compare(Circle* arg) // use this for pointer 
	{
		if (radius > this->radius) // this is A, arg is B
		{
			cout << "Circle with the larger area is " << name << endl;
		}
		if (radius < this->radius) // this is A, arg is B
		{
			cout << "Circle with the larger area is " << this->name << endl;
		}
	}

	bool intersects(Circle &arg) // this is A, arg is B // use arg for reference pass
	{
		double num1;
		num1 = sqrt(((x - arg.x) * (x - arg.x)) + ((y - arg.y) * (y - arg.y)));
		if ((num1) < (radius + arg.radius))
		{
			return true;
		}
		else if ((num1) > (radius + arg.radius))
		{
			return false;
		}
	}

	static int Creations()
	{
		return numInstancesCreated;
	}

};
		
