#include <iostream>
using namespace std;

class Person {

protected:

	string name;
	string university; 

public: // this will change eventually 

	Person(string nameArg, string univArg) {
		name = nameArg;
		university = univArg;
	}

	string getName() {
		return name;
	}

	string getUniversity() {
		return university;
	}
};

class Student : public Person { // Student extends person by public inheritance 

protected:

	string major;

public: 

	Student(string nameArg, string univArg, string majorArg) : Person(nameArg, univArg) {
		//name = nameArg; 
		//university = univArg;
		major = majorArg;
	}

	string getMajor() {
		return major;
	}

};

class Employee : public Person {

protected: 

	string department;

	Employee(string nameArg, string univArg, string deptArg) : Person(nameArg, univArg) {

		department = deptArg;
	}

public:

	string getDepartment() {
		return department;
	}

	double getSalary() {
		return 1500;
	}

};

class Faculty : public Employee {

protected: 

	int numSummerCources;

public:

	Faculty(string nameArg, string univArg, string deptArg, int summerCourcesArg) : Employee(nameArg, univArg, deptArg) {
		
		numSummerCources = summerCourcesArg;
	}

	int getSummerCources() {
		return numSummerCources;
	}

	double getSalary() {
		return Employee::getSalary() + 100 * numSummerCources;
	}

};

class Staff : public Employee {

protected:

	int isPartTime;

public:

	Staff(string nameArg, string univArg, string deptArg, bool partTimeArg) : Employee(nameArg, univArg, deptArg) {

		isPartTime = partTimeArg;
	}

	bool isPartTimeCheck() {
		return isPartTime;
	}

	double getBaseSalary() {
		return isPartTime ? 0.5*Employee::getSalary() : Employee::getSalary();
	}

};

class PrettyPrinter {

public:

	static void printPerson(Person* p) {
		cout << p->getName() << endl;
		cout << p->getUniversity() << endl;
	}

	static void print(Student* s) {
		// print(s) - this is a recusive error (resulting in infinite recursion)
		printPerson(s);
		cout << s->getMajor() << endl;
	}

	static void print(Faculty* f) {
		printPerson(f);
		cout << f->getDepartment() << endl;
		cout << f->getSummerCources() << endl;
	}
};

int main() {

	//Person s1("name1", "univ1");
	//p1.name;

	//Faculty f1("Faculty 1", "UWW", "CompSci", 2);
	//cout << f1.getName() << endl;
	//cout << f1.getSalary() << endl;

	Student* s1 = new Student("Student 1", "UWW", "English"); // dynamically created 
	PrettyPrinter::print(s1);

	Faculty* f1 = new Faculty("Faculty 1", "UWW", "Compsci", 2); // dynamically created 
	PrettyPrinter::print(f1);

	Employee e("xyz", "univ", "dept"); 

	delete s1;
	delete f1;
	return 1; 
}