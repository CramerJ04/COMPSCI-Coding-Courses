#include <iostream>
using namespace std;

class TwoDimArray
{
public:

	static void sum()
	{
		int A[4][3] = { { 3,7,1 }, { 9,-5,6 }, { 0,4,1 }, { 2,8,9 } };
		int sum = 0;
		for (int i = 0; i < 4; i++) // goes over rows 
		{
			for (int j = 0; j < 3; j++) // goes over columns 
			{
				sum += A[i][j];
				cout << A[i][j] << " "; // print the cell A[i][j]
			}
			cout << endl;
		}
		cout << "Sum is " << sum << endl;
	}

	static void swap(int& x, int& y)
	{
		int temp = x;
		x = y;
		y = temp;
	}

	static void shiftRowsUp()
	{
		int A[4][3] = { { 3,7,1 }, { 9,-5,6 }, { 0,4,1 }, { 2,8,9 } };
		int sum = 0;
		for (int i = 0; i < 4; i++) // goes over rows 
		{
			for (int j = 0; j < 3; j++) // goes over columns 
			{
				cout << A[i][j] << " "; // print the cell A[i][j]
			}
			cout << endl;
		}
		for (int i = 0; i < 3; i++) // goes over rows, make sure bounds are correct here 
		{
			for (int j = 0; j < 3; j++) // goes over columns 
			{
				swap(A[i][j], A[i + 1][j]);
			}
			cout << endl;
		}
	}

	static void sumPrincipalMajorDiagonal()
	{
		int A[4][4] = { { 3,7,1,0 }, { 9,-5,6,12 }, { 0,4,1,5 }, { 2,8,9,1 } };
		int sum = 0;
		for (int i = 0; i < 4; i++)
		{
			sum = sum + A[i][i]; // row and column are the same 
		}
		cout << "Sum is " << sum << endl;

	}

	static void sumPrincipalMinorDiagonal()
	{
		int A[4][4] = { { 3,7,1,0 }, { 9,-5,6,12 }, { 0,4,1,5 }, { 2,8,9,1 } };
		int sum = 0;
		for (int i = 0; i < 4; i++)
		{
			sum = sum + A[3 - i][i]; // can change either i depending on direction 
		}
		cout << "Sum is " << sum << endl;

	}

	static void sumUpperTriangular()
	{
		int A[4][4] = { { 3,7,1,0 }, { 9,-5,6,12 }, { 0,4,1,5 }, { 2,8,9,1 } };
		int sum = 0;
		for (int i = 0; i < 4; i++)
		{
			for (int j = i; j < 4; j++) // set them equal 
			{
				sum = sum + A[i][j];
			}
		}
		cout << "Sum is " << sum << endl;

	}

	static void sumLowerTriangular()
	{
		int A[4][4] = { { 3,7,1,0 }, { 9,-5,6,12 }, { 0,4,1,5 }, { 2,8,9,1 } };
		int sum = 0;
		for (int i = 0; i < 4; i++)
		{
			for (int j = 1; j < 4; j++) // goes to indec and counts down
			{
				sum = sum + A[i][j];
			}
		}
		/*for (int i = 3; i >= 0; i--) // OR 
		{
			for (int j = 1; j >= o; j--)
			{
				sum = sum + A[i][j];
			}
		}*/
		/*for (int i = 0; i < 4; i++) // OR
		{
			for (int i = j; j < 4; j++)
			{
				sum = sum + A[i][j];
			}
		}*/
		cout << "Sum is " << sum << endl;

	}
};



int main()
{
	TwoDimArray::sum();
	TwoDimArray::shiftRowsUp();
	TwoDimArray::sumPrincipalMajorDiagonal();
	TwoDimArray::sumPrincipalMinorDiagonal();
	TwoDimArray::sumUpperTriangular();
	TwoDimArray::sumLowerTriangular();
	return 1;
}