#include <iostream>
using namespace std; 
// #include "Stack.h"
#include "Balance.h"


void testStacks()
{
	Stack stack(4);
    for (int i = 1; i <= 1; i++) {
        cout << "Stack before push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        char m = 'A' + i * 7;
        cout << endl << "Push " << m << endl;
        stack.push(m);
        cout << "Stack after push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        cout << endl << "*******" << endl; 
    }
    for (int i = 1; i <= 1; i++) {
        cout << "Stack before push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        char m = 'B' + i * 7;
        cout << endl << "Push " << m << endl;
        stack.push(m);
        cout << "Stack after push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        cout << endl << "*******" << endl;
    }
    for (int i = 1; i <= 2; i++)
    {
        cout << "Stack before pop: ";
        stack.print();
        cout << ". Size = " << stack.size();
        cout << endl << "Popped " << stack.pop() << endl;
        cout << "Stack after pop: ";
        stack.print();
        cout << ". Size = " << stack.size();
        cout << endl << "*******" << endl;
    }
    for (int i = 1; i <= 1; i++) {
        cout << "Stack before push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        char m = 'C' + i * 7;
        cout << endl << "Push " << m << endl;
        stack.push(m);
        cout << "Stack after push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        cout << endl << "*******" << endl;
    }
    for (int i = 1; i <= 1; i++) {
        cout << "Stack before push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        char m = 'D' + i * 7;
        cout << endl << "Push " << m << endl;
        stack.push(m);
        cout << "Stack after push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        cout << endl << "*******" << endl;
    }
    for (int i = 1; i <= 1; i++) {
        cout << "Stack before push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        char m = 'E' + i * 7;
        cout << endl << "Push " << m << endl;
        stack.push(m);
        cout << "Stack after push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        cout << endl << "*******" << endl;
    }
    for (int i = 1; i <= 1; i++) {
        cout << "Stack before push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        char m = 'F' + i * 7;
        cout << endl << "Push " << m << endl;
        stack.push(m);
        cout << "Stack after push: ";
        stack.print();
        cout << ". Size = " << stack.size();
        cout << endl << "*******" << endl;
    }
    cout << "Stack before peek: ";
    stack.print();
    cout << ". Size = " << stack.size();
    cout << endl << "Peeked " << stack.peek() << endl;
    cout << "Stack after peek: ";
    stack.print();
    cout << ". Size = " << stack.size();
    cout << endl << "*******" << endl;
    stack.push(67);
    cout << endl << "*******" << endl;
    for (int i = 1; i <= 4; i++)
    cout << "Popped " << stack.pop() << endl;
    cout << "*******" << endl;
    stack.pop();
    cout << endl;
    // Stack stack2(25);
}
void testBalancedHelper(char* str, int len)
{
    BalancedParenthesis bp(str, len);
    if (bp.isBalanced())
        cout << " is balanced."; 
    else
        cout << " is not balanced.";
    cout << endl;
}
void testBalance() {
    char str0[] = { '(', ')', '{', '}' };
    testBalancedHelper(str0, sizeof(str0) / sizeof(char));
    char str1[] = { '(', '(', '{', '}', ')', ')' };
    testBalancedHelper(str1, sizeof(str1) / sizeof(char));
    char str2[] = { '{', '{', ')', '}' };
    testBalancedHelper(str2, sizeof(str2) / sizeof(char));
    char str3[] = { '{', '{', '}', '}', '(', ')', '(' };
    testBalancedHelper(str3, sizeof(str3) / sizeof(char));
    char str4[] = { '{', '}', '(', ')', '(', '}' };
    testBalancedHelper(str4, sizeof(str4) / sizeof(char));
    char str5[] = { '}', '}', '{', '{' };
    testBalancedHelper(str5, sizeof(str5) / sizeof(char));
}
int main()
{
    testStacks();
    cout << "-------------------------" << endl;
    testBalance();

    return 0;
}
