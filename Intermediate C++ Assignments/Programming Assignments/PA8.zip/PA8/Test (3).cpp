#include <iostream>
#include "MyString.h"
using namespace std;

void testString() {
	MyString mystring1("reverse_me");
	cout << "Original String: " << mystring1 << endl;
	mystring1.reverse();
	cout << "Reversed String: " << mystring1 << endl << endl;

	MyString mystring2("reverse");
	cout << "Original String: " << mystring2 << endl;
	mystring2.reverse();
	cout << "Reversed String: " << mystring2 << endl << endl;

	MyString mystring3("coNvert_me_to_uPPer: a_Through_z_but_NO_$0-9#%&^");
	cout << "Original String: " << mystring3 << endl;
	string upper = mystring3.toUpperCase();
	cout << "Upper-case String: " << upper << endl << endl;

	string str1[] = { "abbcaxx", "abb", "abB", "abby", "abbcdd" };
	string str2[] = { "abbCaXx", "abbz", "abbx", "abBz", "abBcDD" };
	int num = 5;
	for (int i = 0; i < num; i++) {
		MyString myStr1(str1[i]), myStr2(str2[i]);
		int compare = myStr1.compare(myStr2);
		if (compare < 0)
			cout << str1[i] << " is smaller than " << str2[i] << endl;
		else if (compare == 0)
			cout << str1[i] << " equals " << str2[i] << endl;
		else
			cout << str1[i] << " is larger than " << str2[i] << endl;

		int compareIgnore = myStr1.compareIgnoreCase(myStr2);
		if (compareIgnore < 0)
			cout << "Ignoring Case " << str1[i] << " is smaller than "
					<< str2[i] << endl;
		else if (compareIgnore == 0)
			cout << "Ignoring Case " << str1[i] << " equals " << str2[i]
					<< endl;
		else
			cout << "Ignoring Case " << str1[i] << " is larger than " << str2[i]
					<< endl;
		cout << endl;
	}

	MyString text1("hello_anotherhello_onemorehello_yetanotherhello_lasthello");
	MyString key1("hello");
	MyString replace1("#JUNK$");
	cout << "Original Text: " << text1 << endl;
	cout << "Replace " << key1 << " with " << replace1 << endl;
	text1.replaceAll(key1, replace1);
	cout << "Replaced Text: " << text1 << endl << endl;

	MyString text2("aaba_abaaba_aaba");
	MyString key2("aba");
	MyString replace2("#abaaba$");
	cout << "Original Text: " << text2 << endl;
	cout << "Replace " << key2 << " with " << replace2 << endl;
	text2.replaceAll(key2, replace2);
	cout << "Replaced Text: " << text2 << endl;
}

int main() 
{
	testString();
	return 1;
}
