#ifndef RADIXSORT_H_
#define RADIXSORT_H_

#include <iostream>
using namespace std;

class RadixSort {
    
private:
    
    static void countSortOnDigits(int *A, int n, int *digits) { // 
    int* C = new int[n]; // dynamic allocation of space for C 
    for (int i = 0; i < n; i++){ // cells now become zero 
        C[i] = 0;
    }
    int* T = new int[n]; // array T created with length n 

    for (int i = 0; i <= n-1; i++){
        //int temp = digits[i]; //grab the number within digit[i]
        C[digits[i]]++; // incrementing the C array, copying digits[i] to C
    }

    // checking C array
    /*cout << "C array: ";
    for (int i = 0; i < n-1; i++){
        cout << "[" << C[i] << "]"; 
    }
    cout << endl;
    */
    

    for (int i = 1; i <= n-1; i++){
        C[i] = C[i-1] + C[i]; // adds the value from the previous cell of C 
        // to the current cell to make cumulative array 
    }

    for (int i = n-1; i >=0; i--){
        C[digits[i]]--;
        T[C[digits[i]]] = A[i]; // takes the last value in digits 
        // and assigns it to the end of T
    }
    // checking T array 
    /*cout << "T array: ";
    for (int i = 0; i < n-1; i++){
        cout << "[" << T[i] << "]";
    }
    cout << endl;
    */

    for (int i = 0; i <=n; i++){ // copying T into A 
        A[i] = T[i];
    }
    }
    
    static void radixSortNonNeg(int A[], int n) { 
    int temp = 0; 
    for (int i = 0; i < n; i++){ // finds maximum value in A
        if (temp < A[i]){
            temp = A[i]; // maximum value within A[] assigned to M 
        }
    } 
    int M = temp;
    //cout << "Max value: " << M;
    int* digits = new int[n]; // array digits created of length n 
    int e = 1;
    while (M/e > 0){ // while the max is positive
        for (int i = 0; i <= n-1; i++){
            digits[i] = (A[i]/e)%n;
        }
        /*cout << "Digits array: ";
        for (int i = 0; i < n-1; i++){
            cout << "[" << digits[i] << "]";
        }
        cout << endl;
        */
        countSortOnDigits(A, n, digits); // calls countSortOnDigits by digit position. Last, second last, etc. 
        e = e * n;
        }   
    }
    
public:
    // approach 2 of radix sort. Negative and positive arrays are created
    static void radixSort(int array[], int n) { // n indicates size 
    int x = 0; 
    int y = 0;
    int temp = 0;
    for (int i = 0; i < n; i++){
        if (array[i] < 0){ // negative number 
            //cout << array[i] << " is a negative number!" << endl;
            x++;
        }
        else{
            y++;
        }
    }

    //cout << "negative numbers: " << x << " positive numbers: " << y << endl;
    int* NEGATIVE = new int[x]; // x = negative size 
    int* NONNEGATIVE = new int[y]; // y = positive size

    // scan again, and copy now that we know neg and non-neg sizes 
    int posCounter = 0;
    int negCounter = 0;
    for (int i = 0; i < n; i++){
        if (array[i] < 0){ // negative number 
            //cout << array[i] << " is a negative number! Added to the NEGATIVE array" << endl;
            NEGATIVE[negCounter] = array[i];
            negCounter++; // incremented only after adding 
        }
        else{ // positive number
            //cout << array[i] << " is a positive number! Added to the NON-NEGATIVE array" << endl;
            NONNEGATIVE[posCounter] = array[i];
            posCounter++;
        }
    }
    
    // nonNegative check
    /*
    cout << "NonNegative Array: ";
    for (int i = 0; i < y; i++){
        cout << "[" << NONNEGATIVE[i] << "]";
    }
    cout << endl;
    */
    

    radixSortNonNeg(NONNEGATIVE, y); // simply sorting the array for non-negative numbers

    for (int i = 0; i < x; i++){ // making negative numbers positive for NEGATIVE
        NEGATIVE[i] = NEGATIVE[i]/-1;
    }
    
    /*
    cout << "Negative array check after making positive: ";
    for (int i = 0; i < x; i++){
        cout << NEGATIVE[i] << " "; 
    }
    cout << endl;
    */

    radixSortNonNeg(NEGATIVE, x); // sorts the "positive" numbers
    for (int i = 0; i < x; i++){ // making negative numbers negative again
        NEGATIVE[i] = NEGATIVE[i]/-1;
    }

    /*
    cout << "Negative array check after negative again: ";
    for (int i = 0; i < x; i++){
        cout << NEGATIVE[i] << " "; 
    }
    cout << endl;
    */

    // at this point, the array is split into two arrays 

    for (int i = 0; i <= x; i++){ // sort the negative numbers from largest to smallest (right to left)
    // into the original array (left to right)
    array[i] = NEGATIVE[x-i-1]; // last value in NEGATIVE = first in array[]
    }

    /*cout << "final array: ";
    for (int i = 0; i < n; i++){
        cout << "[" << array[i] << "]";
    }
    cout << endl;
    */

    for (int i = x; i < n; i++){ // input the non-negative values after the negative ones
    array[i] = NONNEGATIVE[temp]; // array[i] after the negative numbers = non-negative[i]
    temp++;
    }
    }
};

#endif /* RADIXSORT_H_ */
