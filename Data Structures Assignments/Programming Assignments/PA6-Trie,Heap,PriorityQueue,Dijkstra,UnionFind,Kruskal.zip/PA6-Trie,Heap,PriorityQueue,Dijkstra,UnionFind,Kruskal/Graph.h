#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "Edge.h"
using namespace std;

#ifndef GRAPH_H_
#define GRAPH_H_

class Graph {

public:

	int numVertices;
	vector<vector<Edge> > adjList;

	Graph() {
		numVertices = 0;
	}

	~Graph() {
	}
};

#endif /* GRAPH_H_ */
