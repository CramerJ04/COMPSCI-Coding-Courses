#ifndef PARTITION_H_
#define PARTITION_H_

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <math.h>
using namespace std;

class Partition {

public:

	static void swap(int array[], int x, int y) {
		int temp = array[x];
		array[x] = array[y];
		array[y] = temp;
	}

	static int generateRandomPivot(int array[], int left, int right) {
		return left + rand() % (right - left + 1);
	}

	static int generateMedianOf3Pivot(int array[], int left, int right) {
		int mid = (left + right) / 2;

		if (array[left] > array[mid])
			swap(array, left, mid);

		if (array[left] > array[right])
			swap(array, left, right);

		if (array[mid] > array[right])
			swap(array, mid, right);

		return mid;
	}

    static int* onePassTwoIndexPartition(int array[], int left, int right, int pivotIndex) { // function is linear time, 
	// in place, is one-pass, and returns two indexes lowerPartitionIndex and upperPartitionIndex
	int I = left;
	int lowerPartitionIndex = left;
	int upperPartitionIndex = right;
	int Pivot = array[pivotIndex];
	//cout << "Pivot is: " << Pivot;
	while (I <= upperPartitionIndex) { // we want this, as <pivot, =pivot, and >pivot are set 
		if (array[I] < Pivot) {// regions move. If less, lower grows by 1 
		//cout << "array[i] is: " << array[I] << " Pivot is: " << Pivot << endl;
		//cout << array[I] << " is smaller than " << Pivot << endl;
		swap(array, lowerPartitionIndex, I);
		//cout << "After swap: " << endl;
		//cout << "array[i] is: " << array[I] << " Pivot is: " << Pivot << endl;
		I++;
		lowerPartitionIndex++;
	}
		else if (array[I] > Pivot) { // regions also move 
		//cout << "array[i] is: " << array[I] << " Pivot is: " << Pivot << endl;
		//cout << array[I] << " is larger than " << Pivot << endl;
		swap(array, upperPartitionIndex, I);
		//cout << "After swap: " << endl;
		//cout << "array[i] is: " << array[I] << " Pivot is: " << Pivot << endl;
		upperPartitionIndex--; 
		// the number should be =pivot. I does not change 
	}
		else {
		I++;
		}
	}
	int* partitionIndexes = new int[2];
	partitionIndexes[0] = lowerPartitionIndex;
	partitionIndexes[1] = upperPartitionIndex;
	return partitionIndexes;


}
};

#endif /* PARTITION_H_ */
