#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

enum Role {
	MANAGER = 0,
	DEVELOPER = 1
};

class Employee {

protected:

	string _name;
	double _salary;
	Role _role;

public:

	Employee(string nameArg, double salaryArg, Role arg) {
		_role = arg;
		_name = nameArg;
		_salary = salaryArg;
	};

	double salary() {
		return _salary;
	}

	string name() {
		return _name;
	}

	Role role() {
		return _role;
	}

	virtual double bonus() = 0;

	string format(double d, int r) { // formats to r decimal places (may have bugs - not tested)
		string str = to_string(d);
		if (r == 0)
			return to_string(stoi(str));
		int indexOfDecimal = str.find(".");
		if (indexOfDecimal == string::npos)
			return str + ".00";
		string out = str.substr(0, indexOfDecimal) + ".";
		int numDigitsAfterDecimal = str.substr(indexOfDecimal + 1).length();
		if (r >= numDigitsAfterDecimal)
			return str;
		out += str.substr(indexOfDecimal + 1, r - 1);
		int x = stoi(str.substr(indexOfDecimal + 1 + r));
		if (x >= 5)
			out += to_string(stoi(str.substr(indexOfDecimal + r, 1)) + 1);
		else
			out += to_string(stoi(str.substr(indexOfDecimal + r, 1)));
		return out;
	}

	string toString() {
		return "(" + name() + "," + format(salary(), 2) + ","
			+ format(bonus(), 2) + ")";
	}

};

class Manager : public Employee {

public:

	Manager(string nameArg, double salaryArg) : Employee(nameArg, salaryArg, Role::MANAGER) {

	}

	double bonus() {
		return 0.05 * salary();
	}
};

class Developer : public Employee {

public:

	Developer(string nameArg, double salaryArg) : Employee(nameArg, salaryArg, Role::DEVELOPER) {

	}

	double bonus() {
		return 0.07 * salary();
	}
};


	string vectorToString(vector<Employee*>& employees) {
		if (employees.size() == 0)
			return "[]";
		string out = "[" + employees.at(0)->toString();
		for (int i = 1; i < employees.size(); i++)
			out += ", " + employees[i]->toString();
		out += "]";
		return out;
	}

	static vector<Employee*> readEmployees(string filepath) {
		vector<Employee*> Employees; // polymorphism here - vector accepts many types of arrays 
		ifstream inputF;
		inputF.open(filepath);
		string name;
		char id;
		double salary;

		while (!inputF.eof()) {
			inputF >> id;
			inputF >> name;
			inputF >> salary;
			if (id == 'D') {
				Developer* D = new Developer(name, salary);
				Employees.push_back(D);
			}
			else {
				Manager* M = new Manager(name, salary);
				Employees.push_back(M);
			}
		}
		inputF.close();
		return Employees;
	}


	class EmployeeSorterBasedOnName {

	public:
		bool operator()(Employee* arg1, Employee* arg2) { // employee* used, must use these arguments 
			return arg1->name() <= arg2->name();
		}
	};

	void sortByName(vector<Employee*>& employees) {
		cout << "Before sorting: " << vectorToString(employees) << endl;
		sort(employees.begin(), employees.end(), EmployeeSorterBasedOnName());
		cout << "After sorting based on names: " << vectorToString(employees) << endl;
	}

	class EmployeeSorterBasedOnBonus {
	public:
		bool operator()(Employee* arg1, Employee* arg2) { // employee* used, must use these arguments 
			return arg1->bonus() <= arg2->bonus(); // sort methods never change!!!
		}
	};

	void sortByBonus(vector<Employee*>& employees) {
		cout << "Before sorting: " << vectorToString(employees) << endl;
		sort(employees.begin(), employees.end(), EmployeeSorterBasedOnBonus());
		cout << "After sorting based on Bonus: " << vectorToString(employees) << endl;
	}

	class GroupByRoleThenBySalary {
	public:
		bool operator()(Employee* arg1, Employee* arg2) { // employee* used, must use these arguments 
			if (arg1->role() != arg2->role()) // sort methods never change!!!
				return arg1->role() <= arg2->role();
			else
				return arg1->salary() <= arg2->salary();
		}
	};

	void sortByRoleThenSalary(vector<Employee*>& employees) {
		cout << "Before sorting: " << vectorToString(employees) << endl;
		sort(employees.begin(), employees.end(), GroupByRoleThenBySalary());
		cout << "After sorting based on role, then salary: " << vectorToString(employees) << endl;
	}

	template<class F>
	void selectionSorting(vector<Employee*>& employees, F comparator) {
		for (int i = 0; i < employees.size() - 1; i++) {
			int minIndex = i;
			for (int j = i + 1; i < employees.size(); j++) {
				if (comparator(employees.at(j), employees.at(minIndex))) { // compare employee at j with the employee at minIndex
					// returns true if j is smaller
					// use comparitor here, pass which ones you want into the function 
					minIndex = j;
				}
			}
			if (minIndex != i)
				swap(employees.at(i), employees.at(minIndex));
		}
	}


int main() {

	string filepath = "C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Practice Sets\\PS10\\EmployeeReader";
	vector<Employee*> Employees = readEmployees(filepath); // vector is created, now must sort 

	cout << "Before sorting: " << vectorToString(Employees) << endl;
	selectionSorting(Employees, EmployeeSorterBasedOnBonus());
	cout << "After sorting based on selection sort: " << vectorToString(Employees) << endl;

	return 1;
}

