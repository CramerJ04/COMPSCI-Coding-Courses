#include <iostream>
#include <fstream>
using namespace std;

class Triangle
{
public: 
	string name;
	double a, b, c;

	Triangle(double a, double b, double c) // sides 
	{
		this->a = a;
		this->b = b;
		this->c = c;
	}

	bool isTrue()
	{
		if ((a + b) <= c)
			return false;
		if ((b + c) <= a)
			return false;
		if ((c + a) <= b)
			return false;
		else
			return true;
	}

	double perimeter()
	{
		return (a + b + c);
	}
};

class Rectangle
{
public: 
	string name;
	double length, width; // two sides (both added)

	Rectangle(string name, double length, double width)
	{
		this->name = name;
		this->length = length;
		this->width = width;
	}

	double perimeter()
	{
		return (length + width);
	}
};

void trianglesandRectangles()
{
	ifstream reader("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Practice Sets\\PS6\PS6\\TrianglesandRectangles.txt", ios::in);
	int numT, numR;
	reader >> numT;
	reader >> numR;

	Triangle** triangles = new Triangle* [numT]; // creates four pointers 
	Rectangle** rectangles = new Rectangle* [numR]; // crates three pointers 
	// putting int for both would make a 2d array of integers - not what you want 
	
	for (int i = 0; i < numT + numR; i++)
	{
		char x;
		reader >> x;
		if (x = 'T')
		{
			string name;
			double a, b, c;

			reader >> name;
			Triangle()
		}
		else
	}
}

int main()
{
	trianglesandRectangles();
	return 0;
}