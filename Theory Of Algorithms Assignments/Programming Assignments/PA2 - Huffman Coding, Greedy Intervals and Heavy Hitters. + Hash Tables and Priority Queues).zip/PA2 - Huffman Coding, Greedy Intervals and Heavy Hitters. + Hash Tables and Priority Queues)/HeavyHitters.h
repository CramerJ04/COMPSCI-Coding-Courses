#include <unordered_map>
#include <map>
#include <vector>
#include <string>
using namespace std;

#ifndef HeavyHitters_h
#define HeavyHitters_h

class HeavyHitters {
    
public:
    
    static vector<char> naive(string &stream, int k) {
        unordered_map<char, int> freqMap;
        for (int i = 0; i < stream.length(); i++) {
            char c = stream.at(i);
            int f = freqMap.find(c) != freqMap.end() ? freqMap[c] : 0;
            freqMap[c] = f + 1;
        }
        return heavyHittersHelper(freqMap, stream.length(), k);
    }
    
private:
    
    static vector<char> heavyHittersHelper(unordered_map<char, int> &freqMap, int n, int k) {
        unordered_map<char, int>::iterator it = freqMap.begin();
        vector<char> heavyHitters;
        while (it != freqMap.end()) {
            char c = it->first;
            int f = freqMap[c];
            if (f > n / k)
                heavyHitters.push_back(c);
            it++;
        }
        return heavyHitters;
    }
    
public:
    
    static vector<char> misraGriesOnePass(string &stream, int k) { // complete this method
    unordered_map<char, int> hashmap; // map created
    for (int i = 0; i < stream.length(); i++){ // scanning through the stream 
        char c = stream[i]; // grab the particular character 
        if (hashmap.find(c) != hashmap.end()){ // check if the hashmap has the value of c
            hashmap[c]++; // increment the value of c (counting)
        }
        else if (hashmap.size() < k-1){ // if c is not seen, it becomes 1 
            hashmap[c] = 1;
        }
        else {
            unordered_map<char, int>::iterator it = hashmap.begin(); // iterating over the map 
            while (it != hashmap.end()) { // as long as there is an entry
            int key = it->first; // obtain the key from the iterator
            hashmap[key]--; // reduce the value by 1 for each instance
            it++;
            }

            it = hashmap.begin(); // reset the iterator 
            while (it != hashmap.end()){ // scan again 
            int key = it -> first; // set the instance 
            if (hashmap[key] == 0) {
                it = hashmap.erase(it); // erase the value if it is zero
            }
                else { it++; }
            }

            }
    }
            vector<char> onepassreturns; 
            unordered_map<char, int>::iterator it = hashmap.begin(); // iterating over the map again
            while (it != hashmap.end()) { 
                int key = it->first; // grab the iteration
                onepassreturns.push_back(key); // push back each key 
                it++;
            }
            return onepassreturns;
    }
    
    static vector<char> misraGriesTwoPass(string &stream, int k) { // complete this method

    vector<char> heavyhittercandidates = misraGriesOnePass(stream, k); // call of onepass, which gets heavy hitters
    unordered_map<char, int> hashmap2; // map created

            for (int i = 0; i < heavyhittercandidates.size(); i++){
                hashmap2[heavyhittercandidates.at(i)] = 0; // insert all candidates with values of zero 
            }

            for (int i = 0; i < stream.length(); i++){ // scanning through the stream
                char c = stream[i]; // grab the character in the stream 
                if (hashmap2.find(c) != hashmap2.end()){ // if the map contains c 
                    hashmap2[c]++; // increment the value by 1 
                }
            }
            return heavyHittersHelper(hashmap2, stream.length(), k); // find the actual heavy hitters 
    }

    /*
    To create a hash table object ht whose keys are of type int and values are of type string, the
    syntax is unordered map<int, string> ht.
    To insert a value v with key k, the syntax is ht[k] = v;
    To check whether or not ht contains a key k, the syntax is: if(ht.find(k) != ht.end()). The
    statement inside the if evaluates to true if ht contains k.
    To retrieve the value v corresponding to a key k, the syntax is: string v = ht[k];
    Print all keys/values:

// create an iterator on the set of keys stored in the map
unordered_map<int, string>::iterator it = myMap.begin();
while (it != myMap.end()) { // as long as there is an entry
int key = it -> first; // obtain the key from the iterator
string value = myMap[key]; // get the value corresponding to the key
// can also use: char value = it -> second;
++it; // move the iterator to the next entry (if exists)
cout << key << ": " << value << endl;
}

dynamic arrays: 
In C++, to create an integer vector use: vector⟨int⟩ name;
The size is given by name.size().
To add a number (say 15) at the end of the vector, the syntax is name.push back(15).
To remove the last number, the syntax is name.pop back().
To access the number at a particular index (say 4), the syntax is name[4].
    */
};

#endif /* HeavyHitters_h */
