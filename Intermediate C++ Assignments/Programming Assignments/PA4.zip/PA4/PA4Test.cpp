#include "StringStuff.h"
#include "Polygon.h"

static void testStringStuff() {

	cout << "*** Palindrome Checker ***" << endl << endl;
	string func1_input[] = { "racecar", "abracadabra", "malaalam" };
	for (int i = 0; i < 3; i++) {
		string &str = func1_input[i];
		if (StringStuff::isPalindrome(str))
			cout << str << " is a palindrome" << endl;
		else
			cout << str << " is not a palindrome" << endl;
	}

	cout << endl << "*** Longest Palindrome Finder ***" << endl << endl;
	string func2_input[] = { "racecar", "abrbaadarbaabraxy", "malayaalam" };
	for (int i = 0; i < 3; i++) {
		string &str = func2_input[i];
		string longestPalindromeWithin = StringStuff::longestPalindromeWithin(
				str);
		cout << "Longest palindrome substring of " << str << " is "
				<< longestPalindromeWithin << endl;
	}

	cout << endl << "*** Run-Length Encoding ***" << endl << endl;
	string func3_input[] =
			{ "AAATCTCCGGGAAAATTT", "AAAAATTTGC", "ACGTCTCCTTAA" };
	for (int i = 0; i < 3; i++) {
		string &str = func3_input[i];
		string rle = StringStuff::runLengthEncode(str);
		cout << "Run-length encoding of " << str << " is " << rle << endl;
	} 

	cout << endl << "*** Digit Existence Checker ***" << endl << endl;
	string func4_input[] = { "11004569283779", "034677891",
			"6010__00ab $ %20445987138575", "010__00ab $ %20445987138575" };
	for (int i = 0; i < 4; i++) {
		string &str = func4_input[i];
		if (StringStuff::containsAllDigits(str))
			cout << str << " contains all the digits from 0-9" << endl;
		else
			cout << str << " does not contain all the digits from 0-9" << endl;
	}

	cout << "\n*** Replace All ***" << endl;
	string func5_input_text[] = {
			"hello_anotherhello_onemorehello_yetanotherhello_lasthello",
			"hello_anotherhello_onemorehello_nothing", "aaba_abaaba_aaba" };
	string func5_input_keys[] = { "hello", "hello", "aba" };
	string func5_input_replace[] = { "#JUNK$", "#WOW$", "#abaaba$" };
	for (int i = 0; i < 3; i++) {
		cout << "\nOriginal String: " << func5_input_text[i] << endl;
		cout << "Key: " << func5_input_keys[i] << endl;
		cout << "Replace Key: " << func5_input_replace[i] << endl;
		StringStuff::replaceAll(func5_input_text[i],
				func5_input_keys[i], func5_input_replace[i]);
		cout << "Replaced Text: " << func5_input_text[i] << endl;
	}
}

static void testPolygon() {

	double quadrilateral_xs[] = { 0, 10, 13, 5 };
	double quadrilateral_ys[] = { 0, 0, 21, 12 };
	Polygon quad(quadrilateral_xs, quadrilateral_ys, 4);
	cout << "Perimeter of quadrilateral is = " << quad.perimeter() << endl;

	double pentagon_xs[] = { 12, 23, 34, 45, 67 };
	double pentagon_ys[] = { 4, 9, 13, 10, 4 };
	Polygon pentagon(pentagon_xs, pentagon_ys, 5);
	cout << "Perimeter of pentagon is = " << pentagon.perimeter() << endl;

	double hexagon_xs[] = { 12, 31, 45, 67, 94, 101 };
	double hexagon_ys[] = { 40, 90, 23, 78, 49, 150 };
	Polygon hexagon(hexagon_xs, hexagon_ys, 6);
	cout << "Perimeter of hexagon is = " << hexagon.perimeter() << endl;

	double decagon_xs[] = { 23.4, 30.1, 35.1, 39.2, 43.6, 61.9, 78.2, 89.3, 101.7, 130.2 };
	double decagon_ys[] = { 10, 20, 50, 70, 60, 40, 30, 20, 40, 0 };
	Polygon decagon(decagon_xs, decagon_ys, 10);
	cout << "Perimeter of decagon is = " << decagon.perimeter() << endl;
}

int main() {
	testPolygon();
	cout << endl;
	testStringStuff();
}
