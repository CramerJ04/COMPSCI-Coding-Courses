#ifndef QUICKSORT_H_
#define QUICKSORT_H_

#include "Partition.h"

class QuickSort {

public:

	static void quicksortMedianOf3(int array[], int n) {
		quicksortMedianOf3(array, 0, n - 1);
	}

    static void quicksortRandom(int array[], int n) {
		quicksortRandom(array, 0, n - 1);
	}

private:

    static void quicksortMedianOf3(int array[], int left, int right) { // quicksorts an array using MedianOf3
        //cout << "left: " << left << " right: " << right << endl;
        if (left < right){ // good 
            int pivotIndex = Partition::generateMedianOf3Pivot(array,left, right);
            //int* partitionIndexes = new int[right-1];
            int* partitionIndexes = Partition::onePassTwoIndexPartition(array, left, right, pivotIndex); // array of partitionIndexes 
            quicksortMedianOf3(array, left, partitionIndexes[0] - 1);
            quicksortMedianOf3(array, partitionIndexes[1] + 1, right);
        }
    }

    static void quicksortRandom(int array[], int left, int right) { //quicksorts an array using random assignment for pivotIndex
    if (left < right){
            int pivotIndex = Partition::generateRandomPivot(array,left, right);
            int* partitionIndexes = Partition::onePassTwoIndexPartition(array, left, right, pivotIndex); // array of partitionIndexes 
            quicksortMedianOf3(array, left, partitionIndexes[0] - 1);
            quicksortMedianOf3(array, partitionIndexes[1] + 1, right);
        }
    }
};

#endif /* QUICKSORT_H_ */
