#include <iostream>
#include <string>
using namespace std;

class Sorting {

public:

	static void selectionSort(string* arr, int n)
	{
		for (int i = 0; i < n - 1; i++) {// goes over the array, except the last index 
			int minIndex = i; // initial guess of minimum
			for (int j = i + 1; j < n; j++) { // finding minimum index (searching through array)
				if (arr[j].compare(arr[minIndex])) // put compare here if it was a string comparison 
				// found a new mimimum index 
				minIndex = j;
			}
			if (minIndex != i) {
				string temp = arr[i]; // this would change to a string too 
				arr[i] = arr[minIndex];
				arr[minIndex] = temp;
			}
			for (int j = 0; j < n; j++)
			cout << arr[j] << " ";
			cout << endl;
		}

	}

	static void insertionSort(string* arr, int n)
	{
		for (int i = 1; i < n; i++)
		{
			string temp = arr[i]; // value of index, not an index (number or string)
			int j = i - 1; // j is the number before 
			while (j >= 0 && temp < arr[j]) // j having space to go back && size of number before temp 
			// if they were swapped, out of bounds would happen because j could be a negative when checked 
			{
				arr[j + 1] = arr[j];
				j--; // one position behind 
			}
			arr[j + 1] = temp; // assigns position of temp (number) after j 
			for (int j = 0; j < n; j++) // display 
			cout << arr[j] << " ";
			cout << endl; 
		}
	}
};

int main() {
	// SELECTION SORT (TWO WAYS)

	// int arr[] = {7,19,3,4,0,-8,16};
	// int n = sizeof(arr) / sizeof(int);
	/*for (int j = 0; j < n; j++)
		cout << arr[j] << " ";
	cout << endl << endl;
	Sorting::selectionSort(arr, n);*/

	/*string arrStr[] = {"abc", "abx", "aanc", "aanc", "aanc", "aaaaa", "abww"};
	int n_str = 7;
	for (int j = 0; j < n_str; j++)
	cout << arrStr[j] << " ";
	cout << endl << endl;
	Sorting::selectionSort(arrStr, n_str);*/
	
	// INSERTION SORT 

	/*int arr[] = {7,19,3,4,0,-8,16};
	int n = sizeof(arr) / sizeof(int);
	for (int j = 0; j < n; j++)
	cout << arr[j] << " ";
	cout << endl << endl;
	Sorting::insertionSort(arr, n);*/

	string arrStr[] = {"abc", "abx", "aanc", "aanc", "aanc", "aaaaa", "abww"};
	int n_str = 7;
	for (int j = 0; j < n_str; j++)
	cout << arrStr[j] << " ";
	cout << endl << endl;
	Sorting::insertionSort(arrStr, n_str);

	return 1;
}