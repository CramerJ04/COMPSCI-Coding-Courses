#include <iostream>
#include <climits>
#include "Stack.h"
using namespace std;

#ifndef QUEUEUSINGSTACK_H_
#define QUEUEUSINGSTACK_H_

class QueueUsingStack {

	Stack* mainStack;
	Stack* tempStack;
	int maxQueueSize;

public:
	QueueUsingStack(int maxQueueSize) {
		this->maxQueueSize = maxQueueSize;
		mainStack = new Stack(maxQueueSize);
	}

	~QueueUsingStack() {
		delete mainStack;
	}

	void enqueue(int val) { 
		if (mainStack->size() == 0) { // don't know if size function is correct here 
			mainStack->push(val); // ?
		}
		else {
			//tempStack = new Stack(maxQueueSize);
			Stack tempStack(maxQueueSize);
			for(int i = mainStack->size(); i > 0; i--)
			{
				int temp = mainStack->pop();
				tempStack.push(temp); // numbers popped from mainstack and put into tempstack 
			}
			mainStack->push(val); // new number pushed onto main 
			for (int i = tempStack.size(); i > 0; i--) {
				int temp2 = tempStack.pop(); // numbers popped from temp stack 
				mainStack->push(temp2); // numbers pushed into main stack 
			}
		}
	}

	int dequeue() { // pop on the main stack 
		int x = mainStack->pop();
		return x;
	}

	int size() { // size of the main stack 
		return mainStack->size();
	}

	void print() {
		if (size() == 0)
			cout << "[]";
		else {
			cout << "[";
			int n = size();
			for (int i = 0; i < n - 1; i++) {
				int x = dequeue();
				cout << x << ", ";
				enqueue(x);
			}
			int x = dequeue();
			cout << x << "]";
			enqueue(x);
		}
	}
};
#endif
