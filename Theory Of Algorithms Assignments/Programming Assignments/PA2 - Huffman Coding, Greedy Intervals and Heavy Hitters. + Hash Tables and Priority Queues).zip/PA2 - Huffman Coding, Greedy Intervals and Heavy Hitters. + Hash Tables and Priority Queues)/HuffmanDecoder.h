#include <unordered_map>
#include <string>
using namespace std;

#ifndef HUFFMANDECODER_H_
#define HUFFMANDECODER_H_

class HuffmanDecoder {

public:

	static string decode(string encodedMsg,
        unordered_map<string, char> encodingToCharMapping) { // complete this method

        string encode, decodedMsg = "";
        int n = encodedMsg.length();

        for (int i = 0; i < n; i++){
            encode = encode + encodedMsg[i];
            if (encodingToCharMapping.find(encode) != encodingToCharMapping.end()) {// if encode is found, it will not equal .end()
            // encodingToCharMapping.count(encode)
            char c = encodingToCharMapping[encode];
            decodedMsg = decodedMsg + c;
            encode = "";
            }
        }
        return decodedMsg;


    }
};

#endif /* HUFFMANDECODER_H_ */
