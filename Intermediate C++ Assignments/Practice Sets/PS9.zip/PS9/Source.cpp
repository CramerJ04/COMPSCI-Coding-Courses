#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

enum ShapeType {
	
	RECTANGLE = 0,
	TRIANGLE = 1
};

enum ErrorCode {

	INVALID_TRIANGLE = 1, 
	INVALID_NUMBER_FORMAT = 2,
	INVALID_LENGTH = 3
};

class Shape {

protected: 
	ShapeType TypeOfShape;
	string name;

public: 

	Shape(ShapeType ShapeArg, string nameArg) {
		ShapeArg = TypeOfShape; 
		nameArg = name;
	}

	double perimeter() {

	}
};

class Triangle : public Shape {

	string name;
	double A, B, C;

public: 

	bool isValid(double A,double B,double C) {
		if ((A + B + C) < 0 && A + B > C && B + C > A && A + C > B) {
			return true;
		}
		else
			return false;
	}

	Triangle(string name, double ARGA, double ARGB, double ARGC) : Shape(ShapeType::TRIANGLE, name){
		if (isValid(ARGA, ARGB, ARGC) == 1) {
			ARGA = A;
			ARGB = B;
			ARGC = C;
		}
		else throw (ErrorCode::INVALID_TRIANGLE);
	}

	double getTPerimeter() {
		return A + B + C;
	}
};

class Rectangle : public Shape{

	string name;
	double length, width;

public: 

	bool isValid(double length, double width) {
		if (length + width >= 0) {
			return true;
		}
		else
			return false;
	}

	Rectangle(string name, double lengthArg, double widthArg) : Shape(ShapeType::RECTANGLE, name) {
		if (isValid(lengthArg, widthArg) == 1) {
			lengthArg = length;
			widthArg = width;
		}
		else throw (ErrorCode::INVALID_LENGTH);
	}

	double getRPerimiter() {
		return (2 * length) + (2 * width);
	}
};

static vector<string> split(string& str, string delimiter) {

	vector<string> tokens;
	string token;
	int startIndex = 0;
	int endIndex = str.find(delimiter);

	while (endIndex >= 0 && endIndex < str.length()) {
		token = str.substr(startIndex, endIndex - startIndex); // where do we start, how long 
		tokens.push_back(token);
		startIndex = endIndex + 1; // new starting position, next character after endIndex 
		endIndex = str.find(delimiter, startIndex); // what are we looking for, where do we start 
	}
	token = str.substr(startIndex);
	tokens.push_back(token);
	return tokens;
}

void readTrianglesAndRectangles() {
	ifstream reader("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Practice Sets\\PS9\\PS9\\TrianglesAndRectangles.csv", ios::in);
	string line;
	while (getline(reader, line)) {
		vector<string> tokens = split(line, ",");

		if (tokens.at(0) == "T") {
			try {
				Triangle(tokens.at(1), stod(tokens.at(2)), stod(tokens.at(3)), stod(tokens.at(4)));
			}
			throw(ErrorCode::INVALID_NUMBER_FORMAT);
		};
		if (tokens.at(0) == "R") {
			try {
				Rectangle(tokens.at(1), stod(tokens.at(2)), stod(tokens.at(3)));
			}
		}
		catch (ErrorCode arg) {

		}
	}
}


int main() {

	readTrianglesAndRectangles();
	return 1;
}