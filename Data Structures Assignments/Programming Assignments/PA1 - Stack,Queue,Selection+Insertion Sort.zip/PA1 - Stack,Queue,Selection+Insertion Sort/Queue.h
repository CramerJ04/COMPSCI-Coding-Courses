#include <iostream>
#include <climits>
using namespace std;

#ifndef QUEUE_H_
#define QUEUE_H_

class Queue {

private:

	int maxQueueSize, front, rear, currentSize;
	int* queue;

public:
	Queue(int maxQueueSize) {
		if (maxQueueSize <= 0)
			cout << "Queue size should be a positive integer.";
		else {
			this->maxQueueSize = maxQueueSize;
			front = rear = 0;
			currentSize = 0;
			queue = new int[maxQueueSize];
		}
	}

	~Queue() {
		delete queue;
	}

	void enqueue(int val) { // similar to a push, but other values are assigned 
		if (currentSize == maxQueueSize) {
			cout << "Cannot enqueue, queue is full." << endl;
		}
		else {
			currentSize++;
			queue[rear] = val;
			rear++;
			if (rear == maxQueueSize) {
				rear = 0;
			}
		}
	}

	int dequeue() { // similar to popping, but other values are assigned 
		if (currentSize == 0) {
			cout << "Cannot dequeue, queue is empty." << endl;
			return -999;
		}
		else {
			int y = queue[front];
			front++;
			if (front == maxQueueSize) {
				front = 0;
			}
			currentSize--;
			return y;
		}
	}

	int size() { 
		return currentSize; // would be zero if empty 
	}

	void print() {
		if (size() == 0)
			cout << "[]";
		else {
			cout << "[";
			if (rear > front) {
				for (long i = front; i < rear - 1; i++)
					cout << queue[i] << ", ";
				cout << queue[rear - 1] << "]";
			}
			else {
				for (long i = front; i < maxQueueSize - 1; i++)
					cout << queue[i] << ", ";
				cout << queue[maxQueueSize - 1];

				for (long i = 0; i < rear; i++)
					cout << ", " << queue[i];
				cout << "]";
			}
		}
	}
};

#endif
