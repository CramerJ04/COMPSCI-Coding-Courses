#include<fstream>
#include<iostream>
using namespace std;

class SortingStringFilesIgnoringCase {

public: 
	static string toUpperCase(string& str)
	{
		string upper = " ";
		for (int i = 0; i < str.length(); i++)
		//char c = str.at(i);
		{
			char c = str.at(i);
			if (c >= 97 && c <= 1222)
			{
				char c = str.at(i) - 32;
				upper += c;
			}
			else
			upper += c;
		}
		return upper;
	}

	static void readSortWrite()
	{
		ifstream reader("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Lab5\\Lab5\\inputStrings.txt", ios::in);
		int len;
		reader >> len;
		string* arr = new string[len];
		for (int i = 0; i < len; i++)
		{
			reader >> arr[i]; 
		}
		for (int i = 1; i < len; i++)
		{
			string temp = arr[i]; 
			int j = i - 1;  
			while (j >= 0 && toUpperCase(temp) < toUpperCase(arr[j]))  
			{
				arr[j + 1] = arr[j];
				j--; 
			}
			arr[j + 1] = temp; 
			/*for (int j = 0; j < len; j++)
				cout << arr[j] << " ";
			cout << endl;*/
		}
		reader.close();
		ofstream writer("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Lab5\\Lab5\\outputStrings.txt", ios::out);
		for (int i = 0; i < len; i++)
		{
			writer << arr[i] << endl;
			cout << arr[i] << endl;
		}
		writer.close(); 
	}
    
};

int main() {
	string str = "aBb_A_#bZAxcz#%!Cce";
	cout << "Upper-case version of " << str << " is " << SortingStringFilesIgnoringCase::toUpperCase(str) << endl;
	SortingStringFilesIgnoringCase::readSortWrite();
}

