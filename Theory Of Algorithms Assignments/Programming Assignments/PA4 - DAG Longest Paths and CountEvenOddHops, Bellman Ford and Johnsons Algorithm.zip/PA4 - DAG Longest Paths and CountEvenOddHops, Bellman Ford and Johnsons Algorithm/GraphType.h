#ifndef GRAPHTYPE_H_
#define GRAPHTYPE_H_

enum GraphType {
	UNWEIGHTED, WEIGHTED
};

#endif /* GRAPHTYPE_H_ */
