#include <climits>
#include <vector>
using namespace std;

#ifndef LIS_H_
#define LIS_H_

class LIS {

public:

	static vector<int> longestIncreasingSubsequence(int *arr, int len) { // find increasing substrings

        // two arrays created with length of len 
        int length[len];
        int pred[len];

        for (int i = 0; i < len; i++) {
            // set length[i] and pred[i] to 1 and -1, following procedure
            length[i] = 1;
            pred[i] = -1;
            for (int j = 0; j < i; j++) {
                if (arr[j] < arr[i] && length[j] + 1 > length[i]) {
                    length[i] = length[j] + 1;
                    pred[i] = j;
                }
            }
        }

        // find the maximum value in the length array (where we start from in solving)
        int maxIndex = 0;
        for (int i = 1; i < len; i++) {
            if (length[i] > length[maxIndex]) {
                maxIndex = i;
            }
        }

		// above way of finding max is costly. I attempted to use this, but it wouldn't work
        // int *lisIndex = max_element(length, length + len); 

        vector<int> LISAnswer;

        // go through the table max-many times
        while (maxIndex >= 0) {
            LISAnswer.push_back(arr[maxIndex]); // take the index
            maxIndex = pred[maxIndex]; // set the next index from the max
        }

        reverse(LISAnswer);
        return LISAnswer; 
    }

private:
    static void reverse(vector<int> &list) {
        for (int i = 0, j = list.size() - 1; i < j; i++, j--) {
            int temp = list.at(j);
            list[j] = list.at(i);
            list[i] = temp;
        }
    }
};

#endif /* LIS_H_ */
