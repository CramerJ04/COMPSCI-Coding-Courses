#include <iostream>
#include <string>
#include <vector>
#include <queue>

#include "PriorityQueuePair.h"
#include "PriorityQueuePairComparator.h"
#include "Student.h"
#include "StudentComparator.h"

using namespace std;

#ifndef PRIORITYQUEUEAPPLICATIONS_H_
#define PRIORITYQUEUEAPPLICATIONS_H_

class PriorityQueueApplications {

public:

	static vector<Student> topK(vector<Student>& students, int k) { // ***
		if (k > students.size())
		{
			k = students.size();
		}
		priority_queue<Student, vector<Student>, StudentComparator> PriorityQueue;
		for (int i = 0; i < k; i++)
		{
			PriorityQueue.push(students[i]);
		}
		StudentComparator obj;
		for (int i = k; i < students.size(); i++)
		{
			Student min = PriorityQueue.top();
			if (!obj(min, students[i]))
			{
				PriorityQueue.pop();
				PriorityQueue.push(students[i]);
			}
		}
		vector<Student> ret;
		while (PriorityQueue.size() > 0)
		{
			Student temp = PriorityQueue.top();
			PriorityQueue.pop();
			ret.push_back(temp);
		}
		return ret;
	};

	static vector<int> kWayMerge(vector<vector<int> >& lists) { // ***
		priority_queue<PriorityQueuePair, vector<PriorityQueuePair>, PriorityQueuePairComparator> pqp; // NEEDS TO BE FIXED 
		vector<int> returnList;
		int *Indexes = new int[lists.size()];
		for (int i = 0; i < lists.size(); i++) {
			//PriorityQueuePair *temp = new PriorityQueuePair(i, lists.at(i).at(0));
			PriorityQueuePair temp = PriorityQueuePair(i, lists.at(i).at(0));
			pqp.push(temp);
			Indexes[i] = 1;
		}
		while (pqp.size() != 0) {
			PriorityQueuePair temp = pqp.top();
			pqp.pop();
			returnList.push_back(temp.priority);
			int minItem = temp.item;
			if (Indexes[minItem] < lists.at(minItem).size()) {
			PriorityQueuePair temp2 = PriorityQueuePair(minItem, lists.at(minItem).at(Indexes[minItem]));
			pqp.push(temp2);
			Indexes[minItem]++;
			}
		}
		return returnList;
	}
};



#endif /* PRIORITYQUEUEAPPLICATIONS_H_ */
