#include <iostream>
#include <string>
using namespace std;

class StringStuff {

public:
    
    static bool isPalindrome(string &str)
    {
        string fr = " ";
        string back = " ";
        double count = 0;
        
        for (int i = 0; i < str.length(); i++)
        {
            fr += str.at(i);
        }
        for (int i = str.length() - 1; i >= 0; i--)
        {
            back += str.at(i);
        }
        if (fr == back) // might not work 
            return true;
        else
            return false;
        /*for (int i = 0; i < str.length(); i++) // check 
        {
            double value = str.length();
            if (str.at(i) = str.at(value - i))
                count++;
        }
        if (count == str.length())
            return true;
        else
            return false;*/
    }

    static string runLengthEncode(string &str)
    {
        string rle = " ";
        int counter = 1;
        for (int i = 0; i < str.length() - 1; i++) 
        {
            if (str.at(i) == str.at(i + 1))
            {
                counter++;
            }
            else
            {
                rle += str.at(i);
                if (counter > 1)
                rle += to_string(counter);
                counter = 1;
            }
        }
        if (counter > 1)
        {
            rle += str.at(str.length() - 1);
            return rle += to_string(counter);
        }
        return rle += str.at(str.length() - 1);
    }

    static bool containsAllDigits(string &str)
    {
        bool arr[10];
        int counter = 0;
        for (int i = 0; i < 10; i++)
        {
            //value = i;
            arr[i] = false;
        }
        for (int i = 0; i < str.length() - 1; i++) 
        {
            char c = str.at(i);
            if (c >= 48 && c <= 57)
            {
                int p = c - 48;
                c = p;
                arr[c] = true;
            }
        }
        for (int i = 0; i < 10; i++) // checking
        {
            if (arr[i] == true) 
            counter++;
        }
        if (counter == 10)
        return true; 
        else
        return false;
    }

    static void replaceAll(string& text, string& key, string& replacement)
    {
        int index = text.find(key);
        while (index >= 0 && index < text.length()) // make sure index is within the string (bounds)
        {
                text.replace(index, key.length(), replacement); // replacement 
                index = text.find(key, index + replacement.length()); // reassigning next target
                // works for last instance. Makes sure the first key isn't taken, and checks after the replacement 
        }
    }

    static string longestPalindromeWithin(string& str)
    {
        string lcs = " ";
        for (int i = 0; i < str.length(); i++)
        {
            for (int j = str.length() - i; j >= 1; j--)
            {
                string substr = str.substr(i, j);
                if (isPalindrome(substr) == true)
                {
                    if (substr.length() > lcs.length())
                    {
                        lcs = substr;
                    }
                    break;
                }
            }
        }
        return lcs;
    }
        
        
};

