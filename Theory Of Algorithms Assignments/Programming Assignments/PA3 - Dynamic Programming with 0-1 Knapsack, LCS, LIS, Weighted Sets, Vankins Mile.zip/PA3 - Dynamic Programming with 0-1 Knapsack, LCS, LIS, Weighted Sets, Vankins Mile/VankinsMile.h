#include <string>
#include <vector>
#include <stdio.h>
using namespace std;

#ifndef VankinsMile_h
#define VankinsMile_h

class VankinsMile {

public:
    
    // x
    static void findBestPath(int **board, int numRows, int numCols, int startRow, int startCol) {

        //create the values matrix
        int** values = new int* [numRows];
        for(int i = 0; i < numRows; i++){
            values[i] = new int[numCols];
        }
        //create the directions matrix
        char** directions = new char* [numRows];
        for(int i = 0; i < numRows; i++){
            directions[i] = new char[numCols];
        }

        // base cases 

        // base case 1: values matrix is filled with -inf and directions matrix filled with '*'
        // reachable cells will be overwritten
        for (int r = 0; r < numRows; r++){
            for(int c = 0; c < numCols; c++){
                values[r][c] = INT_MIN;
                directions[r][c] = '*';
            }
        }

        // base case 2: // moving right: gained/lost by summing up the cells [startRow, startCol], [startRow, startCol + 1], . . . , [startRow, c].
        for (int c = startCol; c < numCols; c++){
            if (values[startRow][startCol] == INT_MIN){             // in the first iteration, no values are placed yet
                values[startRow][c] = board[startRow][startCol];    // thus, values[startRow][c] will be equal to 
                directions[startRow][c] = 'S';                      // the value at board[startRow][startCol]
                                                                    // S is also placed (start)
            }
            else { 
                values[startRow][c] = values[startRow][c-1] + board[startRow][c];   // now, since values[startRow][c] has 
                directions[startRow][c] = 'L';                                      // a value, board[startRow][c] can be added 
            }                                                                       // to values[startRow][c-1]
        }

        // base case 3: // moving down: gained/lost by summing up the cells [startRow, startCol], [startRow + 1, startCol], . . . , [r, startCol].
        for (int r = startRow; r < numRows; r++){
            if (values[r][startCol] == board[startRow][startCol]){      // in the first iteration, if values[r][startCol] 
                values[r][startCol] = board[startRow][startCol];        // is equal to board[startRow][startCol], keep 
            }                                                           // it the same as it will remain this way 
            else {
                values[r][startCol] = values[r-1][startCol] + board[r][startCol]; // now, since values[r][startCol] has a value
                directions[r][startCol] = 'U';                                    // board[r][startCol] can be added with 
            }                                                                     // values[r-1][startCol]
        }

        // recurrence area
        for (int r = startRow + 1; r < numRows; r++){
            for (int c = startCol + 1; c < numCols; c++) { // traverse and update directions and values

                if (values[r-1][c] > values[r][c-1]) {
                    values[r][c] = board[r][c] + values[r-1][c];
                    directions[r][c] = 'U';
                }
                else {
                    values[r][c] = board[r][c] + values[r][c-1];
                    directions[r][c] = 'L';
                }

                // other way of calculating using max
                // values[r][c] = board[r][c] + max(values[r-1][c], values[r][c-1]);
                
            }
        }

        pathFinder(values, directions, numRows, numCols, startRow, startCol);
        
        delete[] values;
        delete[] directions;
    }

    
private:

    static void pathFinder(int **values, char **directions, int numRows, int numCols, int startRow, int startCol) {
        printBoard(values, directions, numRows, numCols);
        int max = INT_MIN;
        int maxR = 0;
        int maxC = 0;
        vector<int*> path;
        for (int i = startRow; i < numRows; i++)
            if (values[i][numCols - 1] > max) {
                max = values[i][numCols - 1];
                maxR = i;
                maxC = numCols - 1;
            }
        for (int j = startCol; j < numCols; j++)
            if (values[numRows - 1][j] > max) {
                max = values[numRows - 1][j];
                maxR = numRows - 1;
                maxC = j;
            }
        cout << "\nMaximum gain is: " << max << endl;
        while (maxR >= startRow && maxC >= startCol) {
            int *node = new int[2];
            node[0] = maxR;
            node[1] = maxC;
            path.push_back(node);
            if (directions[maxR][maxC] == 'L')
                maxC--;
            else
                maxR--;
        }
        reverse(path);
        
        cout << "Path: ";
        if (path.size() == 0)
            return;
        int *node;
        for (int i = 0; i < path.size() - 1; i++) {
            node = path.at(i);
            printf("[%d,%d] --> ", node[0], node[1]);
            delete[] node;
        }
        node = path.at(path.size() - 1);
        printf("[%d,%d]\n", node[0], node[1]);
        delete[] node;
    }

    static void printBoard(int **values, char **directions, int numRows, int numCols) {
        cout << "\nSolution (Value/Direction) Board" << endl;
        if (numRows == 0 || numCols == 0) {
            cout << "[]" << endl;
            return;
        }
        for (int i = 0; i< numRows; i++) {
            string val = values[i][0] == INT_MIN ? "-inf" : to_string(values[i][0]);
            string out = "[" + val + "/" + directions[i][0];
            for (int j = 1; j < numCols; j++) {
                val = values[i][j] == INT_MIN ? "-inf" : to_string(values[i][j]);
                out += ", " + val + "/" + directions[i][j];
            }
            out += "]";
            cout << out << endl;
        }
    }
    
    static void reverse(vector<int *> &list) {
        for (int i = 0, j = list.size() - 1; i < j; i++, j--) {
            int *temp = list.at(j);
            list[j] = list.at(i);
            list[i] = temp;
        }
    }
};

#endif /* VankinsMile_h */
