//#include <iostream>
//#include <queue>
//#include <string>
//#include <vector>
//
//#include "IOHelper.h"
//#include "PriorityQueuePair.h"
//#include "PriorityQueuePairComparator.h"
//#include "StringComparator.h"
//#include "StudentComparator.h"
//using namespace std;
//
//class GenericHeapSort {
//
//public:
//
//	static void sort(int* arr, int len) {
//
//		// creates a priority queue using the PriorityQueueComparator
//		priority_queue<PriorityQueuePair, vector<PriorityQueuePair>,
//			PriorityQueuePairComparator> heap;
//
//		for (int i = 0; i < len; i++)
//			heap.push(PriorityQueuePair(arr[i], arr[i])); // for plain heap sort, item and priority are the same;
//
//		int i = 0;
//		while (heap.size() > 0) { // as long as the heap is not empty
//			PriorityQueuePair ele = heap.top(); // get the topmost item
//			heap.pop(); // remove the topmost item
//			arr[i++] = ele.item; // could also use ele.priority
//		}
//	}
//
//	static void sort(string* arr, int len) {
//
//		// creates a priority queue using the StringComparator
//		priority_queue<string, vector<string>, StringComparator> heap;
//
//		for (int i = 0; i < len; i++)
//			heap.push(arr[i]);
//
//		int i = 0;
//		while (heap.size() > 0) { // as long as the heap is not empty
//			string ele = heap.top(); // get the topmost item
//			heap.pop(); // remove the topmost item
//			arr[i++] = ele;
//		}
//	}
//
//	static void printVector(vector<Student>& students) {
//		int len = students.size();
//		if (0 == len) {
//			cout << "[]";
//			return;
//		}
//		cout << "[";
//		for (int i = 0; i < len - 1; i++) {
//			cout << students.at(i).toString() << ", ";
//		}
//		cout << students.at(len - 1).toString() << "]";
//	}
//
//	static void sortStudents() {
//		cout << "\n\n*** Student Heap Sort ***\n\n";
//		string path = "students.txt";
//		vector<Student> students = IOHelper::readStudents(path);
//		cout << "Original Order: ";
//		printVector(students);
//
//		// creates a priority queue using the StudentComparator
//		priority_queue<Student, vector<Student>, StudentComparator> heap;
//
//		for (int i = 0; i < students.size(); i++)
//			heap.push(students.at(i));
//
//		vector<Student> sortedStudents;
//		while (heap.size() > 0) { // as long as the heap is not empty
//			Student ele = heap.top(); // get the topmost item
//			heap.pop(); // remove the topmost item
//			sortedStudents.push_back(ele);
//		}
//
//		cout << "\nAfter Sorting:  ";
//		printVector(sortedStudents);
//	}
//};
//
//static void printArray(int* A, int len) {
//	if (len == 0) {
//		cout << "[]";
//		return;
//	}
//	cout << "[";
//	for (int i = 0; i < len - 1; i++) {
//		cout << A[i] << ", ";
//	}
//	cout << A[len - 1] << "]";
//}
//
//static void printArray(string* A, int len) {
//	if (len == 0) {
//		cout << "[]";
//		return;
//	}
//	cout << "[";
//	for (int i = 0; i < len - 1; i++) {
//		cout << A[i] << ", ";
//	}
//	cout << A[len - 1] << "]";
//}
//
//void integerSort() {
//	cout << "*** Integer Heap Sort ***\n\n";
//	int n = 10;
//	int arr[] = { 360, 448, 29, 447, 15, 53, 491, 261, 219, 354 };
//	cout << "Original array: ";
//	printArray(arr, n);
//	GenericHeapSort::sort(arr, n);
//	cout << endl << "After sorting:  ";
//	printArray(arr, n);
//}
//
//void stringSort() {
//	cout << "\n\n*** String Heap Sort ***\n\n";
//	string arr[] = { "abc", "def", "abcd", "bce", "abx", "acfe", "bfr", "xyz",
//			"de", "tyu", "ab", "abcd", "xy", "zxy", "abx", "def" };
//	cout << "Original array: ";
//	printArray(arr, 16);
//	GenericHeapSort::sort(arr, 16);
//	cout << endl << "After sorting:  ";
//	printArray(arr, 16);
//}

//int main() {
//	integerSort();
//	stringSort();
//	GenericHeapSort::sortStudents();
//}