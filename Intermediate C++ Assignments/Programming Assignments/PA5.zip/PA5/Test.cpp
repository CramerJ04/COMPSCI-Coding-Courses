#include "StudentSorter.h"
#include <iostream>
using namespace std;

void printStudents(Student **students, int n) {
	cout << "[" << students[0]->toString();
	for (int i = 1; i < n; i++)
		cout << ", " << students[i]->toString();
	cout << "]";
}

void printStudents(Student *students, int n) {
	cout << "[" << students[0].toString();
	for (int i = 1; i < n; i++)
		cout << ", " << students[i].toString();
	cout << "]";
}

void testStudentsSelectionSort() { // fill this function
	Student** classification;
	classification = new Student * [6];
	string names[6] = { "abc", "abx", "aanc", "aaqc", "aaaaaa", "abww" };
	double grades[6] = { 79.58, 56.34, 94.67, 40.39, 80.00, 72.13 };
	for (int i = 0; i < 6; i++)
		{
		classification[i] = new Student(names[i], grades[i]);
		}
	/*name[0] = new Student("abc", 79.58);
	name[1] = new Student("abx", 56.34);
	name[2] = new Student("aanc", 94.67);
	name[3] = new Student("aaqc", 40.39);
	name[4] = new Student("aaaaaa", 80.00);
	name[5] = new Student("abww", 72.13);*/
	cout << "Original Order: ";
	printStudents(classification, 6); 
	cout << endl;
	StudentSorter::StudentNameSelection(classification, 6);
	cout << "Order After Sorting: ";
	printStudents(classification, 6);
}

void testStudentsInsertionSort() {
	Student** classification;
	classification = new Student * [6];
	string names[6] = { "abc", "abx", "aanc", "aaqc", "aaaaaa", "abww" };
	double grades[6] = { 79.58, 56.34, 94.67, 40.39, 80.00, 72.13 };
	for (int i = 0; i < 6; i++)
	{
		classification[i] = new Student(names[i], grades[i]);
	}
	cout << "Original Order: ";
	printStudents(classification, 6);
	cout << endl;
	StudentSorter::StudentGradeInsertion(classification, 6);
	cout << "Order After Sorting: ";
	printStudents(classification, 6);
}

int main() {
	testStudentsSelectionSort();
	cout << endl;
	testStudentsInsertionSort();
	return 1;
}

