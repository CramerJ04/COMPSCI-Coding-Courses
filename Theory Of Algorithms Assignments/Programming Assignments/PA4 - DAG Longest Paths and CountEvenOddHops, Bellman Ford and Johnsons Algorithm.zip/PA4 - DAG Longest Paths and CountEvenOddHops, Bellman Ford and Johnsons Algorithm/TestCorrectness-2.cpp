#include <iostream>
#include "DAG.h"
#include "Johnson.h"
#include "GraphType.h"
#include "DJP.h"
using namespace std;

const static string BASE_FOLDER = "Text Files/";

const static string DAG1_PATH = BASE_FOLDER + "dag1.txt";
const static string DAG2_PATH = BASE_FOLDER + "dag2.txt";

const string BELLMANFORD1_GRAPH_PATH = BASE_FOLDER + "bellmanford1.txt";
const string BELLMANFORD2_GRAPH_PATH = BASE_FOLDER + "bellmanford2.txt";
const string BELLMANFORD3_GRAPH_PATH = BASE_FOLDER + "bellmanford3.txt";

const string DIJKSTRA1_GRAPH_PATH = BASE_FOLDER + "dijkstra1.txt";
const string DIJKSTRA2_GRAPH_PATH = BASE_FOLDER + "dijkstra2.txt";

const string APSP1_GRAPH_PATH = BASE_FOLDER + "apsp1.txt";
const string APSP2_GRAPH_PATH = BASE_FOLDER + "apsp2.txt";
const string APSP3_GRAPH_PATH = BASE_FOLDER + "apsp3.txt";

const string MST_GRAPH_PATH = BASE_FOLDER + "mst_graph.txt";

static void printArray(int *A, int len) {
	if (0 == len)
		cout << "[]";
	else {
		cout << "[";
		for (int i = 0; i < len - 1; i++) {
			if (A[i] == INT_MAX)
				cout << "inf, ";
			else if (A[i] == INT_MIN)
				cout << "-inf, ";
			else
				cout << A[i] << ", ";
		}
		if (A[len - 1] == INT_MAX)
			cout << "inf]";
		else if (A[len - 1] == INT_MIN)
			cout << "-inf]";
		else
			cout << A[len - 1] << "]";
	}
}

static void printVector(vector<int> &vect) {
	if (0 == vect.size())
		cout << "[]";
	else {
		cout << "[";
		for (int i = 0; i < vect.size() - 1; i++) {
			cout << vect.at(i) << ", ";
		}
		cout << vect.at(vect.size() - 1) << "]";
	}
}

static void printVector(vector<Edge> &vect) {
	if (0 == vect.size())
		cout << "[]";
	else {
		cout << "[";
		for (int i = 0; i < vect.size() - 1; i++) {
			cout << vect.at(i).toString() << ", ";
		}
		cout << vect.at(vect.size() - 1).toString() << "]";
	}
}

static void testDAG() {
    string filePaths[] = { DAG1_PATH, DAG2_PATH };
    int numFiles = 2;
    for (int i = 0; i < numFiles; i++) {
        printf("*** Test Longest Path on DAG %d ***\n\n", i + 1);
        Graph *graph = new Graph(filePaths[i], WEIGHTED);
        DAG ag(graph);
        vector<int> topo = ag.topoSort();
        cout << "Topological Order: ";
        printVector(topo);
        for (int j = 0; j < ag.numVertices; j++) {
            int *dist = ag.longestPaths(j);
            cout << endl;
            printf("Longest Path Array (from v%d): ", j);
            printArray(dist, ag.numVertices);
            delete[] dist;
        }
        delete graph;
        cout << endl << endl;
    }
    
    for (int i = 0; i < numFiles; i++) {
        printf("*** Count Number of Odd & Even Edges Path on DAG %d ***\n\n", i + 1);
        Graph *graph = new Graph(filePaths[i], WEIGHTED);
        DAG ag(graph);
        for (int j = 0; j < ag.numVertices; j++) {
            int **count = ag.countOddEvenHops(j);
            printf("Number of even length paths (from v%d): ", j);
            printArray(count[0], ag.numVertices);
            printf("\nNumber of odd length paths (from v%d):  ", j);
            printArray(count[1], ag.numVertices);
            delete[] count[0];
            delete[] count[1];
            delete[] count;
            cout << endl << endl;
        }
        delete graph;
    }
	
}

static void testBellmanFord() {
	printf("*** Graph 1 ***\n\n");
	Graph *graph = new Graph(BELLMANFORD1_GRAPH_PATH, WEIGHTED);
	BellmanFord *bf = new BellmanFord(graph);
	for (int i = 0; i < graph->numVertices; i++) {
		printf("Distances from v%d: ", i);
		printArray(bf->execute(i), graph->numVertices);
		cout << endl;
	}
	delete graph;
	printf("\n*** Graph 2 ***\n");
	graph = new Graph(BELLMANFORD2_GRAPH_PATH, WEIGHTED);
	bf = new BellmanFord(graph);
	if (bf->execute(0) == NULL)
		cout << "\nHas a negative cycle." << endl;
	else
		cout << "\nSomething is wrong." << endl;
	delete graph;
	printf("\n*** Graph 3 ***\n\n");
	graph = new Graph(BELLMANFORD3_GRAPH_PATH, WEIGHTED);
	bf = new BellmanFord(graph);
	for (int i = 0; i < graph->numVertices; i++) {
		printf("Distances from v%d: ", i);
		printArray(bf->execute(i), graph->numVertices);
		cout << endl;
	}
	delete graph;
}

static void testDijkstra() {
	string filePaths[] = { DIJKSTRA1_GRAPH_PATH, DIJKSTRA2_GRAPH_PATH };
	for (int j = 0; j < 2; j++) {
		cout << "*** Graph " << (j + 1) << " ***\n" << endl;
		Graph *graph = new Graph(filePaths[j], WEIGHTED);
		Dijkstra dijk(graph);
		for (int i = 0; i < dijk.numVertices; i++) {
			int *distance = dijk.execute(i);
			cout << "Distance array (from v" << i << "): ";
			printArray(distance, graph->numVertices);
			cout << endl;
			delete[] distance;
		}
		delete graph;
		cout << endl;
	}
}

static void testAPSP() {
	Graph *graph = new Graph(APSP1_GRAPH_PATH, WEIGHTED);
	Johnson johnson(graph);
	int **distArrayJohnson = johnson.execute();
	cout << "*** Graph 1 Distance Matrix (using Johnson) ***\n" << endl;
	for (int i = 0; i < graph->numVertices; i++) {
		printArray(distArrayJohnson[i], graph->numVertices);
		cout << endl;
	}
	cout << endl;
	delete graph;

	graph = new Graph(APSP2_GRAPH_PATH, WEIGHTED);
	johnson = new Johnson(graph);
	distArrayJohnson = johnson.execute();
	cout << "*** Graph 2 Distance Matrix (using Johnson) ***\n" << endl;
	for (int i = 0; i < graph->numVertices; i++) {
		printArray(distArrayJohnson[i], graph->numVertices);
		cout << endl;
	}
	delete graph;

	printf("\n*** Graph 3 ***\n");
	cout << endl;
	graph = new Graph(APSP3_GRAPH_PATH, WEIGHTED);
	johnson = Johnson(graph);
	distArrayJohnson = johnson.execute();
	if (distArrayJohnson != NULL)
		cout << "Something wrong with Johnson's method." << endl;
	else cout << "Has a negative cycle." << endl;
	delete graph;
}

void testDJP() {
	DJP djp(MST_GRAPH_PATH, WEIGHTED);
	vector<Edge> mst = djp.execute();
	int mstWeight = 0;
	for (Edge &edge : mst)
		mstWeight += edge.weight;
	cout << "MST has weight " << mstWeight << endl;
	cout << "The edges are: ";
	printVector(mst);
	cout << endl;
}

int main() {
	cout
			<< "****************** Acyclic Graphs ******************\n"
			<< endl;
	testDAG();
	
	cout << "****************** Bellman-Ford ******************\n" << endl;
	testBellmanFord();
	cout << "\n****************** Dijkstra ******************\n" << endl;
	testDijkstra();
	cout << "****************** APSP algorithms ******************\n" << endl;
	testAPSP();
	cout << "\n****************** DJP ******************\n" << endl;
	testDJP(); 
	return 1;
}

