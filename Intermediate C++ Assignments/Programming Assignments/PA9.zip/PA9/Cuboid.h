#include "Shape.h"
#include "ErrorType.h"

#ifndef CUBOID_H_
#define CUBOID_H_

class Cuboid : public Shape {

private:

	double length, width, height;

public: 

	Cuboid(string nameArg, double lengthArg, double widthArg, double heightArg) : Shape(CUBOID, nameArg) {
		this->length = lengthArg;
		this->width = widthArg;
		this->height = heightArg;

		if (width || length || height < 0) {
			throw(ErrorType::INVALID_LENGTH_ARGUMENT);
		}
	};

	double area() {
		return 2 * (length * width + width * height + length * height);
	}

	double volume() {
		return (length * width * height);
	}

};

#endif /* CUBOID_H_ */
