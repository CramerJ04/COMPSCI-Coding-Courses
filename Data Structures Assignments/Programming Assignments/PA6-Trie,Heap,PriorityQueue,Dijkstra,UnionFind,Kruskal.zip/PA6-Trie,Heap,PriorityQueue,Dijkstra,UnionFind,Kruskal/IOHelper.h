#include "Student.h"
#include "Graph.h"

#ifndef IOHELPER_H_
#define IOHELPER_H_

class IOHelper {

public:

	static vector<Student> readStudents(const string& filePath) { // ***
		ifstream reader(filePath, ios::in);
		vector<Student> ret;
		while (!reader.eof())
		{
			string name;
			int grade;
			reader >> name;
			reader >> grade;
			Student temp(name, grade);
			ret.push_back(temp);
		}
		return ret;
	}

	static Graph readWeightedGraph(string& filePath) { // ***
		ifstream reader(filePath, ios::in);
		Graph graph;
		reader >> graph.numVertices;
		graph.adjList.reserve(graph.numVertices);
		for (int i = 0; i < graph.numVertices; i++)
		{
			graph.adjList.push_back(vector<Edge>());
		}
		while (!reader.eof())
		{
			int src;
			int dest;
			int weight;
			reader >> src;
			reader >> dest;
			reader >> weight;
			Edge e(src, dest, weight);
			graph.adjList[src].push_back(e);
		}
		reader.close();
		return graph;
	}
};

#endif /* FILEREADER_H_ */
