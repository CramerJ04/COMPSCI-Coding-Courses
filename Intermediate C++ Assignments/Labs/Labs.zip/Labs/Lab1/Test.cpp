#include <iostream>
#include "Rectangle.h"
using namespace std;

int main()
{
	Rectangle A(15.7, 10.0, 'A');
	Rectangle B(5.0, 100.2, 'B');
	Rectangle *C = new Rectangle(30.1, 5.2, 'C');
	Rectangle* D = new Rectangle(20.5, 5.6, 'D');
	
	cout << endl << "The area of rectangle A = " << A.area() << endl;
	cout << "The perimeter of rectangle A = " << A.perimeter() << endl;

	cout << endl << "The area of rectangle D = " << D->area() << endl;
	cout << "The perimeter of rectangle D = " << D->perimeter() << endl << endl;

	delete C;
	delete D;

	return 0;
}