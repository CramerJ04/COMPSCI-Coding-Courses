#include <iostream>
#include <climits>
#include <list>
#include "Graph.h"
using namespace std;

#ifndef BFS_H_
#define BFS_H_

class BFS : public Graph {

public:

	int* level;

	BFS(string& fileName) {
		readUnweightedGraph(fileName);
		level = NULL;
	}

	~BFS() {
		delete[] level;
	}

private:

	void initialize() { // complete this method
		level = new int[numVertices]; // allocating numVert cells for level array
		for (int i = 0; i < numVertices; i++) {
			level[i] = INT_MAX;
		}
	}

	void traverse(int s) { // complete this method
		list<int> vertexQ;
		vertexQ.push_back(s);
		level[s] = 0;
		while (vertexQ.size() > 0) {
			int v = vertexQ.front(); // get the first number in the queue 
			vertexQ.pop_front(); // removes said number
			list<Edge>& row = adjList.at(v);
			// row be the linked list corresponding to the row adjList[v]; notice that 
			// row is a linked list of type Edge
			list<Edge>::iterator it = row.begin();
			while (it != row.end()) {
				Edge& adjEdge = *it;
				it++;
				int w = adjEdge.dest;
				if (level[w] == INT_MAX) {
					level[w] = level[v] + 1;
					vertexQ.push_back(w);
				}
			}
		}
	}

public:

	void execute(int s) { // complete this method
		initialize();
		traverse(s);
	}

	int countComponents() { // complete this method
		initialize();
		int counter = 0;
		for (int i = 0; i < numVertices; i++) {
			if (level[i] == INT_MAX) {
				traverse(i);
				counter++;
			}
		}
		return counter;
	}

	bool** computeTransitiveClosure() { // complete this method
		bool** M = new bool* [numVertices];
		for (int i = 0; i < numVertices; i++) {
			M[i] = new bool[numVertices];
			execute(i);
			for (int j = 0; j < numVertices; j++) {
				if (level[j] != INT_MAX) { // there is a path from I to J 
					M[i][j] = true;
				}
				else {
					M[i][j] = false;
				}
			}
		}
		return M;
	}
	
	
};

#endif /* BFS_H_ */
