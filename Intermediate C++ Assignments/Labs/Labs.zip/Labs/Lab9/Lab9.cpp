#include <string>
#include <cmath>
#include <iostream>
using namespace std;

class Shapes {

protected: 

	string name;

	Shapes(string nameArg) {
		name = nameArg;
	}

public: 


	string getName() {
		return name;
	};

	virtual double area() {
		return 0;
	}

	virtual double perimeter() {
		return 0;
	}
};

class Rectangle : public Shapes {

protected:

	double length;
	double width;

public:

	Rectangle(double lengthArg, double widthArg, string nameArg) : Shapes(nameArg) {
		length = lengthArg;
		width = widthArg;
	}

	double perimeter() {
		return (2 * (length + width));
	}

	double area() {
		return (length * width);
	}
};

class Square : public Rectangle {
public: 

	Square(double sideArg, string nameArg) : Rectangle(sideArg, sideArg, nameArg) {
	}
};

class Triangle : public Shapes {

protected: 

	double A, B, C;
	double S = (A + B + C) / 2;

public: 

	Triangle(double AArg, double BArg, double CArg, string nameArg) : Shapes(nameArg) {
		A = AArg;
		B = BArg;
		C = CArg;
	};

	bool isValid() {
		if (A + B > C && A + C > B && B + C > A)
			return true;
		else
			return false;
	}

	double perimeter() {
		return isValid() == true ? (A + B + C) : -1;
	}

	double area() {
		double S = (A + B + C) / 2;
		return isValid() == true ? sqrt(S * (S - A) * (S - B) * (S - C)) : -1;
	}
};

class ShapePrinter {

public:
	static void print(Rectangle* R) {
		cout << "Perimeter of " << R->getName() << "is ";
		cout << R->perimeter() << endl;
		cout << "Area of " << R->getName() << "is ";
		cout << R->area() << endl;
	}

	static void print(Triangle* T) {
		cout << "Perimeter of " << T->getName() << "is ";
		cout << T->perimeter() << endl;
		cout << "Area of " << T->getName() << "is ";
		cout << T->area() << endl;
	}
	static void print(Square* Sq) {
		cout << "Perimeter of " << Sq->getName() << "is ";
		cout << Sq->perimeter() << endl;
		cout << "Area of " << Sq->getName() << "is ";
		cout << Sq->area() << endl;
	}
};

int main() {

	cout << "***\n" << endl;
	string rect_1 = "Rectangle1";
	Rectangle *rect = new Rectangle(5, 12, rect_1);
	ShapePrinter::print(rect);
	cout << "\n***\n" << endl;

	string square_1 = "Square1";
	Square *square = new Square(5, square_1);
	ShapePrinter::print(square);
	cout << "\n***\n" << endl;

	string triangle_1 = "Triangle1";
	Triangle *tri1 = new Triangle(5, 6, 16, triangle_1);
	ShapePrinter::print(tri1);
	cout << "\n***\n" << endl;

	string triangle_2 = "Triangle2";
	Triangle *tri2 = new Triangle(6, 16, 5, triangle_2);
	ShapePrinter::print(tri2);
	cout << "\n***\n" << endl;

	string triangle_3 = "Triangle3";
	Triangle *tri3 = new Triangle(16, 5, 6, triangle_3);
	ShapePrinter::print(tri3);
	cout << "\n***\n" << endl;

	string triangle_4 = "Triangle4";
	Triangle *tri4 = new Triangle(5, 5, 5, triangle_4);
	ShapePrinter::print(tri4);
	cout << "\n***\n" << endl;

	string triangle_5 = "Triangle5";
	Triangle *tri5 = new Triangle(3, 5, 4, triangle_5);
	ShapePrinter::print(tri5);
	cout << "\n***\n" << endl;

	string triangle_6 = "Triangle6";
	Triangle *tri6 = new Triangle(4, 6, 4, triangle_6);
	ShapePrinter::print(tri6);

	delete rect;
	delete square;
	delete tri1;
	delete tri2;
	delete tri3;
	delete tri4;
	delete tri5;
	delete tri6;

	return 1;
}
