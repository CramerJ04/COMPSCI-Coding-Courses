#include <iostream>
#include <string>
using namespace std;

#ifndef RECURSION_H_
#define RECURSION_H_

class Recursion {

public:

	static int sumEvenDigits(int n) {
		cout << n << endl;
		if (n == 0) { // if the number is zero, end the function 
		// prevents the function from running forever 
			return 0;
		} 
		int RightNumber = n % 10; // gives the number on the right of n 
		if (RightNumber % 2 == 1) { // if the number is odd
			return sumEvenDigits(n / 10); // call the function again
		}
		else { // if the number is even 
			cout << "Increment with: " << RightNumber << endl;
			return RightNumber + sumEvenDigits(n / 10); // add the number to the total, and call the function again
		}
	}

	static void allBinaryStringsWithMoreOnes(int n) {
		allBinaryStringsWithMoreOnes("", 0, 0, n);
	}

private:

	static void allBinaryStringsWithMoreOnes(string str, int numZeroes,
		int numOnes, int n) { 
		if (str.length() == n && numZeroes < numOnes) {
			cout << str << endl;
			return; 
		}
		else if (str.length() < n) {
			allBinaryStringsWithMoreOnes(str + "0", numZeroes + 1, numOnes, n);
			allBinaryStringsWithMoreOnes(str + "1", numZeroes, numOnes + 1, n);
		}
	}
};

#endif /* RECURSION_H_ */
