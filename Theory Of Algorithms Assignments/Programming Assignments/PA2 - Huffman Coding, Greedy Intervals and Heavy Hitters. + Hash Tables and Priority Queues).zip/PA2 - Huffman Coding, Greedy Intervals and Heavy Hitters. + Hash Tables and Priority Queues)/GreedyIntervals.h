#include "Interval.h"
#include "IntegerComparator.h"
#include <vector>
#include <algorithm>
using namespace std;

#ifndef GREEDYINTERVALS_H_
#define GREEDYINTERVALS_H_

class GreedyIntervals {

private:

	struct sort_by_start {
		bool operator()(const Interval &arg1, const Interval &arg2) const {
			return arg1.start < arg2.start;
		}
	};

	struct sort_by_end {
		bool operator()(const Interval &arg1, const Interval &arg2) const {
			return arg1.end < arg2.end;
		}
	};

	static void sortIntervalsByStartTime(vector<Interval> &intervals) {
		sort(intervals.begin(), intervals.end(), sort_by_start());
	}

	static void sortIntervalsByEndTime(vector<Interval> &intervals) {
		sort(intervals.begin(), intervals.end(), sort_by_end());
	}

public:

    static vector<Interval> schedule(vector<Interval> &intervals) { // complete this method

	sortIntervalsByEndTime(intervals); // sorts the vector of intervals by end time 
	vector<Interval> optimal; // to be returned as a list of intervals from the program 

	optimal.push_back(intervals[0]); // adding the first interval within sorted intervals 
	// the first interval is always chosen
	for (int i = 1; i < intervals.size(); i++){
		//cout << "current start: " << intervals[i].start << endl;
		//cout << "current end: " << optimal[i].end << endl;
		if (intervals[i].start >= optimal.back().end){ // if the intervals start is at, or after optimal's interval 
			optimal.push_back(intervals[i]); // add the interval into optimal intervals 
		}
		else {
			//nothing 
		}
	}
	return optimal;

	/*
	In C++, to create an integer vector use: vector⟨int⟩ name;
	The size is given by name.size().
	To add a number (say 15) at the end of the vector, the syntax is name.push back(15).
	To remove the last number, the syntax is name.pop back().
	To access the number at a particular index (say 4), the syntax is name[4].
	*/

	/*
	/* 
	To create for BinaryTreeNodes: priority queue<BinaryTreeNode*,
	vector<BinaryTreeNode*>, BinaryTreeNodeComparator> pq;
	To create for integers: priority queue<int, vector<int>, IntegerComparator> pq;
	To obtain the size: pq.size();
	To add an item (integer or BinaryTreeNode*) x: pq.push(x);
	To peek the topmost item: pq.top();
	To remove the topmost item: pq.pop(); note that pop does not return the item removed and
	so you may want to peek and grab the item before popping.
	*/

    }

    static int color(vector<Interval> &intervals) { // 

	sortIntervalsByStartTime(intervals); // sorts the vector of intervals by start time
	priority_queue<int, vector<int>, IntegerComparator> PQ; // priority queue for end time of intervals 
	PQ.push(intervals[0].end); // end time of the first interval stored 

	for (int i = 1; i < intervals.size(); i++){

		//cout << "Current interval: [" << intervals[i].start << ", " << intervals[i].end << "]" << endl;
    	//cout << "PQ top: " << PQ.top() << endl;

		// example: [(a, 0, 6), (b, 1, 4), (c, 3, 5), (d, 3, 8), (e, 4, 7), (f, 5, 9), (g, 6, 10), (h, 8, 11)]

		if (intervals[i].start < PQ.top()){ // new color needed
		// 1 < 6, yes 
		// 2nd iteration: 3 < 4 or 6? yes 
		// 3rd iteration: 3 is not less than 3, 4, or 6
		PQ.push(intervals[i].end); // replace the used number with the new start of the interval colored
		// 4 is added, 6 is still present 
		// 3 is added, 4 and 6 still present 

		//cout << "End of intervals added: " << intervals[i].end << endl;
		//cout << "PQ size is now: " << PQ.size() << endl;

		}
		else {
			PQ.pop(); // removes smallest value 
			// remove 3
			PQ.push(intervals[i].end);
			// add 8 
			// process repeats 
		}
	}
	return PQ.size();

    }
};

#endif /* GREEDYINTERVALS_H_ */
