#include "Shape.h"
#include "ErrorType.h"
#include <cmath>

#ifndef SPHERE_H_
#define SPHERE_H_

class Sphere : public Shape {

private:

	double radius;

public: 

	Sphere(string nameArg, double radiusArg) : Shape(SPHERE, nameArg) {
		radiusArg = radius;

		if (radius < 0) {
			throw(ErrorType::INVALID_LENGTH_ARGUMENT);
		}
	};

	double area() {
		return (4 * 3.14 * (radius * radius));
	}

	double volume() {
		return ((4 / 3) * 3.14 * (radius * radius * radius));
	}

};

#endif /* SPHERE_H_ */
