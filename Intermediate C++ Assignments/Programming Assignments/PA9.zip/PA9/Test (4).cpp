#include "ShapeSorter.h"
#include "ShapeReader.h"
#include <iostream>
#include <vector>
using namespace std;

static void print(vector<Shape*> shapes) {
	for (int i = 0; i < shapes.size(); i++)
		cout << shapes.at(i)->toString() << endl;
}

int main() {
	string FILE_PATH = "C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\PA9\\PA9\\shapes.csv";
	string ERROR_PATH = "C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\PA9\\PA9\\errors.csv";

	vector<Shape*> shapes = ShapeReader::readShapes(FILE_PATH, ERROR_PATH);
	cout << "*** Original Order ***\n" << endl;
	print(shapes);
	cout << "\n*** Sorted By Area ***\n" << endl;
	ShapeSorter::sortByArea(shapes);
	print(shapes);
	cout << "\n*** Grouped By Type and Sorted By Volume ***\n" << endl;
	ShapeSorter::sortByTypeThenVolume(shapes);
	print(shapes);
}

