

#ifndef SHAPETYPE_H_
#define SHAPETYPE_H_

enum ShapeType {
	CUBOID = 0,
	CYLINDER = 1,
	SPHERE = 2
};

#endif /* SHAPETYPE_H_ */
