#include <algorithm>
#include <string>
#include "Graph.h"
#include "UnionFind.h"
#include "IOHelper.h"

#ifndef KRUSKAL_H_
#define KRUSKAL_H_

class SortEdges {

public:

	bool operator()(Edge& arg1, Edge& arg2)
	{
		return arg1.weight < arg2.weight;
	}
};

class Kruskal : public Graph {

public:

	Kruskal(string& filePath) { // ***
		Graph KruskalGraph;
		KruskalGraph = IOHelper::readWeightedGraph(filePath);
		numVertices = KruskalGraph.numVertices;
		adjList = KruskalGraph.adjList;
	}

	vector<Edge> runKruskal() { // ***
		vector<Edge> edgeList;
		for (int i = 0; i < adjList.size(); i++)
		{
			for (int j = 0; j < adjList[i].size(); j++)
			{
				edgeList.push_back(adjList[i][j]);
			}
		}
		sort(edgeList.begin(), edgeList.end(), SortEdges());
		UnionFind objUF(numVertices);
		vector<Edge> Darray;
		int numEdgesAdded = 0;
		for (int i = 0; i < edgeList.size(); i++)
		{
			Edge e = edgeList[i];
			int src = e.src;
			int dest = e.dest;
			if (objUF.find(src) != objUF.find(dest))
			{
				objUF.doUnion(src, dest);
				Darray.push_back(e);
				numEdgesAdded++;
				if (numEdgesAdded == (numVertices - 1))
				{
					break;
				}
			}
		}
		return Darray;
	}
};

#endif /* KRUSKAL_H_ */
