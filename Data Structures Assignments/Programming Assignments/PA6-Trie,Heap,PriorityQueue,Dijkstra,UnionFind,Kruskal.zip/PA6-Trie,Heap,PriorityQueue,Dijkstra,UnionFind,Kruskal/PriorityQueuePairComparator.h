#include "PriorityQueuePair.h"

#ifndef PRIORITYQUEUECOMPARATOR_H_
#define PRIORITYQUEUECOMPARATOR_H_

class PriorityQueuePairComparator {

public:

	bool operator()(const PriorityQueuePair& arg1, const PriorityQueuePair& arg2) const {
		return arg1.priority > arg2.priority;
	}
};



#endif /* PRIORITYQUEUECOMPARATOR_H_ */
