#pragma once
#ifndef HASHINGWITHCHAINING_H_
#define HASHINGWITHCHAINING_H_

#include <list>
#include <iterator>
using namespace std;

class HashingWithChaining {

public:

	int TABLE_SIZE;
	list<int>** hashTable;

	HashingWithChaining(int tableSize) {
		TABLE_SIZE = tableSize;
		hashTable = new list<int>*[TABLE_SIZE]; // clumsy implementation, better to use a vector of lists
		for (int i = 0; i < TABLE_SIZE; i++)
			hashTable[i] = new list<int>();
	}

	~HashingWithChaining() {
		for (int i = 0; i < TABLE_SIZE; i++)
			delete hashTable[i];
		delete[] hashTable;
	}

private:

	int getHashValue(int val) {
		return (37 * val + 61) % TABLE_SIZE;
	}

public:

	list<int>* getList(int index) {
		return hashTable[index];
	}

	bool search(int key) { // complete this method
		int temp = getHashValue(key); // gets the location of the list of numbers 
		list<int>* numbers = getList(temp); // list created, from the numbers at temp's location 
		list<int>::iterator it = numbers->begin(); // declares an iterator. Starts at the first number in the list 
		while (it != numbers->end()) { // ensures the iterator traverses to the end of the list 
			int val = *it; // gets the value at the node which the iterator is pointing
			if (val == key) {
				return true; // list contains key
			}
			else { // not the right number
				++it; // move to the next node (in the list)
			}
		} // if the number is never found, return false
		return false; 
	}

	bool insert(int val) { // complete this method
		bool check = search(val); // only want to insert a number if it doesn't already exist
		if (check == true) {
			return false; // so, check if the list contains it already
		}
		int temp = getHashValue(val); // get the location of the list, using val 
		list<int>* numbers = getList(temp); // gets the list (only if the numbers don't repeat) 
		numbers->push_back(val); // push val onto the end of the list
		return true; 
		// list<int>::iterator it = numbers->end(); // point the iterator to the end of the list
	}

	bool remove(int val) { // similar to search function 
		int temp = getHashValue(val); // gets location of the list 
		list<int>* numbers = getList(temp); // gets the list using temp's location 
		list<int>::iterator it = numbers->begin(); // assigns a iterator to the first number in the list
		while (it != numbers->end()) { // ensures the iterator traverses to the end of the list 
			int listval = *it; // gets the value at the node which the iterator is pointing
			if (listval == val) {
				numbers->erase(it); // deletes the current node (the node at the current index)
				return true; // list contains key
			}
			else { // not the right number
				++it; // move to the next node (in the list)
			}
		} // if the number is never found, return false
		return false;
	}

	void printStatistics() {
		int maxSize = hashTable[0]->size();
		int minSize = maxSize, total = maxSize;
		for (int i = 1; i < TABLE_SIZE; i++) {
			int size = hashTable[i]->size();
			if (size > maxSize)
				maxSize = size;
			else if (size < minSize)
				minSize = size;
			total += size;
		}
		printf(
			"Max length of a chain = %d\nMin length of a chain = %d\nAvg length of chains = %d\n",
			maxSize, minSize, total / TABLE_SIZE);
	}
};

#endif
