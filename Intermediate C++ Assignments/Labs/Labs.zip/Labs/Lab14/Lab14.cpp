#include <unordered_set>
#include <unordered_map>
#include <vector>
#include <string>
#include <iostream>
using namespace std;

// add all the 3 functions here

static string toString(unordered_set<int> &arg) {
	if (arg.size() == 0)
		return "[]";
	unordered_set<int>::iterator it = arg.begin();
	string out = "[" + to_string(*it);
	it++;
	while (it != arg.end()) {
		out += ", " + to_string(*it);
		it++;
	}
	out += "]";
	return out;
}

static string toString(int *arg, int len) {
	if (len == 0)
		return "[]";
	string out = "[" + to_string(arg[0]);
	for (int i = 1; i < len; i++)
		out += ", " + to_string(arg[i]);
	out += "]";
	return out;
}

static unordered_set<int> findDuplicates(int* arr1, int* arr2, int len1, int len2) {

	unordered_set<int> checker;
	unordered_set<int> answer;

	for (int i = 0; i < len1; i++) {
		checker.insert(arr1[i]);
	}

	for (int i = 0; i < len2; i++) {
		if (checker.find(arr2[i]) != checker.end()) { // found 
			answer.insert(arr2[i]);
		}
	}
	return answer;
}

static unordered_map<char, int> computeFrequenciesusingMap(string arg, int len) {
	unordered_map<char, int> charToInt_Map;
	for (int i = 0; i < len; i++) {
		if (charToInt_Map.find(arg[i]) == charToInt_Map.end()) {
			// arr[i] is not in the map
			// so, insert into the map with value (frequency) as 1
			charToInt_Map[arg[i]] = 1;
		}
		else {
			// arr[i] is in the map 
			// so, increase its value (frequency) by 1 
			int currectFrequency = charToInt_Map[arg[i]]; // get the frequency in the map 
			currectFrequency++; // incerase frequency by 1 
			charToInt_Map[arg[i]] = currectFrequency; // place increased frequency back in the map 
		}
	}
	return charToInt_Map;
}

bool areAnagrams(string str1, string str2) {
	if (computeFrequenciesusingMap(str1, str1.length()) == computeFrequenciesusingMap(str2, str2.length())) {
		return true;
	}
	else
		return false;
}

static void testDuplicates() {
	int arr1[] = { 7, 15, 4, 7, 65, 78, 95, 89, 95, 78 };
	int arr2[] = { 95, 4, 78, 7, 9, 7, 4, 76, 9 };
	unordered_set<int> answer1 = findDuplicates(arr1, arr2,
			sizeof(arr1) / sizeof(int), sizeof(arr2) / sizeof(int));
	cout << "Duplicates between " << toString(arr1, sizeof(arr1) / sizeof(int))
			<< " and " << toString(arr2, sizeof(arr2) / sizeof(int)) << ": "
			<< toString(answer1) << endl;

	int arr3[] = { 7, 15, 4, 7, 65, 78, 95, 89, 95, 78 };
	int arr4[] = { 99, 14, 9, 73, 76, 9 };
	answer1 = findDuplicates(arr3, arr4,
			sizeof(arr3) / sizeof(int), sizeof(arr4) / sizeof(int));
	cout << "Duplicates between " << toString(arr3, sizeof(arr3) / sizeof(int))
			<< " and " << toString(arr4, sizeof(arr4) / sizeof(int)) << ": "
			<< toString(answer1) << endl;
}


static void testAnagram() {
	string str1 = "integral";
	string str2 = "triangle";
	printf("\n%s and %s are anagrams of each other? %s\n", str1.c_str(),
			str2.c_str(), areAnagrams(str1, str2) ? "YES" : "NO");

	str1 = "integral";
	str2 = "trianglex";
	printf("%s and %s are anagrams of each other? %s\n", str1.c_str(),
			str2.c_str(), areAnagrams(str1, str2) ? "YES" : "NO");

	str1 = "integral";
	str2 = "triannle";
	printf("%s and %s are anagrams of each other? %s\n", str1.c_str(),
			str2.c_str(), areAnagrams(str1, str2) ? "YES" : "NO");

	str1 = "aabxxb#(cb";
	str2 = "a#xbxa(bcb";
	printf("%s and %s are anagrams of each other? %s\n", str1.c_str(),
			str2.c_str(), areAnagrams(str1, str2) ? "YES" : "NO");

	str1 = "aabxxb#(cb";
	str2 = "zzbxxb#(cb";
	printf("%s and %s are anagrams of each other? %s\n", str1.c_str(),
			str2.c_str(), areAnagrams(str1, str2) ? "YES" : "NO");

	str1 = "aabxxb#(cb";
	str2 = "aabxxb#acb";
	printf("%s and %s are anagrams of each other? %s\n", str1.c_str(),
			str2.c_str(), areAnagrams(str1, str2) ? "YES" : "NO");

	str1 = "aabxxb#(cbfrbt%ybbuuahh##61$$)%";
	str2 = "abbh#abyxbfab%t%bxuu)h(##61c$r$";
	printf("%s and %s are anagrams of each other? %s\n", str1.c_str(),
			str2.c_str(), areAnagrams(str1, str2) ? "YES" : "NO");

	str1 = "aabxxb#(cbfrbt%ybbuuahh##61$$)%";
	str2 = "abbh#abyxbfab%t%bxvu)h(##61c$r$";
	printf("%s and %s are anagrams of each other? %s", str1.c_str(),
			str2.c_str(), areAnagrams(str1, str2) ? "YES" : "NO");
}

int main() {
	testDuplicates();
	testAnagram();
	return 1;
}

