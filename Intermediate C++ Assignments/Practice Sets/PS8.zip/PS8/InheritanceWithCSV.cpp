#include <iostream>
using namespace std;

class Person {

protected: 

	string name;
	string dateOfBirth;

public:

	Person(string nameArg, string dateOfBirthArg) {
		name = nameArg;
		dateOfBirth = dateOfBirthArg;
	};

	string getName() {
		return name;
	}

	string getDOB() {
		return dateOfBirth;
	}

};

class Student : public Person {

protected:
	
	int majorId;

public:

	Student(string nameArg, string dateOfBirthArg, int majorIdArg) : Person(nameArg, dateOfBirthArg) {
		majorId = majorIdArg;
	}

	int getmajorId() {
		return majorId;
	}
};

class Employee : public Person {

protected:

	int deptId;

	Employee(string nameArg, string dateOfBirthArg, int deptIdArg, bool partTimeArg) : Person(nameArg, dateOfBirthArg) {
		deptId = deptIdArg;
	};

public: 

	int getDeptId() {
		return deptId;
	}

	virtual double getBaseSalary() {
		return 1500;
	}
};

class Faculty : public Employee {

protected:

	int numOfCources;

public:

	Faculty(string nameArg, string dateOfBirthArg, int deptIdArg, int numOfCourcesArg) : Employee(nameArg, dateOfBirthArg, deptIdArg, numOfCourcesArg) {
		numOfCources = numOfCourcesArg;
	};

	int getnumOfCources() {
		return numOfCources;
	}

	double getSalary() {
		return Employee::getBaseSalary() + 500 * numOfCources;
	}
};

class Staff : public Employee {

protected:

	bool partTime;

public:

	Staff(string nameArg, string dateOfBirthArg, int deptIdArg, bool partTimeArg) : Employee(nameArg, dateOfBirthArg, deptIdArg, partTimeArg) {
		partTime = partTimeArg;
	};

	bool getpartTime() {
		return partTime;
	}

	double getSalary() {
		return partTime ? 0.5 * Employee::getBaseSalary() : getBaseSalary();
	}
};

class prettyPrint {

public:
	static void printPerson(Person* p) {
		cout << p->getName() << endl;
		cout << p->getDOB() << endl;
	}

	static void printEmployee(Employee* e) {
		cout << e->getDeptId() << endl;;
	}

	static void print(Student* s) {
		printPerson(s);
		cout << s->getmajorId() << endl;
	}

	static void print(Staff* s) {
		printPerson(s);
		printEmployee(s);
		cout << s->getSalary() << endl;
	}

	static void print(Faculty* f) {
		printPerson(f);
		printEmployee(f);
	    cout << f->getnumOfCources() << endl;
		cout << f->getSalary() << endl;
	}
};

int main() {

	Student* s1 = new Student("Jake", "2003", 12345);
	prettyPrint::print(s1);
	cout << endl;

	Staff* st1 = new Staff("DD", "5000", 54321, true);
	prettyPrint::print(st1);
	cout << endl;

	Staff* st2 = new Staff("JJ", "10000", 77777, false);
	prettyPrint::print(st2);
	cout << endl;

	Faculty* f1 = new Faculty("XXX", "87654", 12345, 5);
	prettyPrint::print(f1);
	cout << endl;

	Faculty* f2 = new Faculty("SSSSS", "11111", 999999, 3);
	prettyPrint::print(f2);
	cout << endl;

	delete s1; 
	delete st1;
	delete st2;
	delete f1;
	delete f2;

	return 1; 
}