#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

template<typename T>
static int search(T* arr, int len, T key) { // basic search function 
	for (int i = 0; i < len; i++) {
		if (arr[i] == key) {
			return i;
		}
	}
	return -1;
}

template <typename T>
class GenericGrowableStack {

	vector<T> contents; 

public:

	void push(T arg) { 
		contents.push_back(arg);
	}

	T pop() { 
		T ret = contents.back(); 
		contents.pop_back();
		return ret;
	}

	T peek() { 
		return contents.back();
	}

	int size() {
		return contents.size();
	}
};

template<typename C>
static int minimum(C* arr, int len) {
	C smallest = arr[0];
	for (int i = 0; i < len; i++) {
		if (arr[i] < smallest) {
			smallest = arr[i];
		}
	}
	return smallest;
}


/*static int search(double* arr, int len, double key) { // basic search function 
	for (int i = 0; i < len; i++) {
		if (arr[i] == key) {
			return i;
		}
	}
	return -1;
}

static int search(string* arr, int len, string key) { // basic search function 
	for (int i = 0; i < len; i++) {
		if (arr[i] == key) {
			return i;
		}
	}
	return -1;
}
*/

int main() {

	/*int arr[] = {3,7,5,2,13,4,5,6};
	int key = 13;
	cout << "Index of " << key << " is " << search(arr, sizeof(arr) / sizeof(int), key) << endl;

	double arr_double[] = { 12.34, 6.78, 9.32, 8.91, 5.67, 0.03 };
	double key_double = 9.32;
	cout << "Index of " << key_double << " is " << search(arr_double, sizeof(arr_double) / sizeof(double), key_double) << endl;

	string arr_string[] = { "abc", "tef", "rte", "fgh", "xyz", "xcc" };
	string key_string = "xyz";
	cout << "Index of " << key_string << " is " << search(arr_string, sizeof(arr_string) / sizeof(string), key_string) << endl;
	*/

	/*GenericGrowableStack<int> intStack;
	for (int i = 5; i <= 25; i += 5) { // pushing values onto the stack, then popping them 
		intStack.push(i);
		while (intStack.size() > 0) {
			cout << intStack.pop() << " ";
		}
	}

	cout << endl;
	GenericGrowableStack<string> strStack;
	strStack.push("abc");
	strStack.push("pqr");
	strStack.push("xxx");
	strStack.push("lkj");
	strStack.push("uyte");
	while (strStack.size() > 0) {
		cout << strStack.pop() << " ";
	}
	*/

	int arr[] = { 3,7,5,2,13,4,5,6 };

	int len = sizeof(arr) / sizeof(int);
	/*sort(arr, arr + len, greater<int>()); // Where I want to sort (beginning), how long I want to sort, what type of sorting
	for (int i = 0; i < len; i++) {
		cout << arr[i] << " ";
	}
	*/

	vector<int> numbers;
	for (int i = 0; i < len; i++) { // sorting a vector 
		numbers.push_back(arr[i]);
	}
	for (int i = 0; i < len; i++) { // displaying a vector 
		cout << numbers.at(i) << " ";
	}

	cout << endl;
	sort(numbers.begin(), numbers.end()); // sorting normal 
	for (int i = 0; i < len; i++) { // displaying a vector after sorting normal
		cout << numbers.at(i) << " ";
	}
	cout << endl;

	sort(numbers.begin(), numbers.end(), greater<int>());
	for (int i = 0; i < len; i++) { // displaying a vector after sorting backward
		cout << numbers.at(i) << " ";
	}

	return -1;
}

