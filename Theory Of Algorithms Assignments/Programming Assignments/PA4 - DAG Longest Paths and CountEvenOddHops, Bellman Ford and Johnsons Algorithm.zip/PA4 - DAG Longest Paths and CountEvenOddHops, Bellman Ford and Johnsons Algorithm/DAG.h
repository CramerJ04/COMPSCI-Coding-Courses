#include <iostream>
#include <climits>
#include <vector>
#include <string>
#include <queue>
#include "Graph.h"
using namespace std;

#ifndef DAG_H_
#define DAG_H_

class DAG: public Graph {

public:

    DAG(Graph *graph) : Graph(graph) {
    }

    ~DAG() {
    }
    
    vector<int> topoSort() {
        vector<int> topoOrder;
        int *inDegree = new int[numVertices];
        for (int i = 0; i < numVertices; i++)
            inDegree[i] = 0;
        
        for (int i = 0; i < numVertices; i++)
            for (Edge e : adjList.at(i))
                inDegree[e.dest]++;
        
        queue<int> q;
        for (int i = 0; i < numVertices; i++)
            if (inDegree[i] == 0)
                q.push(i);
        
        while (q.size() > 0) {
            int u = q.front();
            q.pop();
            topoOrder.push_back(u);
            for (Edge e : adjList.at(u)) {
                inDegree[e.dest]--;
                if (inDegree[e.dest] == 0)
                    q.push(e.dest);
            }
        }
        delete[] inDegree;
        return topoOrder;
    }

    int *longestPaths(int s) { 

    vector<int> order = topoSort(); // get the topological sort for each graph
    int* distance = new int[numVertices]; // allocated numVertices cells for distance array
    for(int i = 0; i < numVertices; i++){ // all cells of distance[] are -infinity
        distance[i] = INT_MIN;
    }

    distance[s] = 0; // source is zero
    for(int v: order){ // going through each vertex in the topological order
        for(Edge e : adjList.at(v)) { // looking at the vertex's each outgoing edges
            int adjVertex = e.dest; // destination of the particular edge assigned
            if(distance[v] != INT_MIN) {// if the initial distance isn't -inf...
                int len = distance[v] + e.weight; // current vertex + edge weight
                if (len > distance[adjVertex]) { // if the calculated length is > the destination of the edge
                    distance[adjVertex] = len; // assign accordingly
                }
            }
        }
    }

    return distance;
    delete[] distance;
    }
    
    int **countOddEvenHops(int s) { 

        int** evenOddHop = new int*[2]; // create 2D array to hold even and odd counts for each vertex
        for(int i = 0; i < 2; i++){ // set everything to zero
            evenOddHop[i] = new int[numVertices]; 
            for(int j = 0; j < numVertices; j++){ 
                evenOddHop[i][j] = 0;
            }
        }

        evenOddHop[0][s] = 1; // countEven(s) = 1, vertex to itself (0 length)
        evenOddHop[1][s] = 0; // countOdd(s) = 0, none found so far

        vector<int> order = topoSort(); // get the topological sort for each graph
        for(int v = 0; v < order.size(); v++){ // going through each vertex in the topological order
            for(Edge e : adjList.at(v)) { // looking at the vertex's each outgoing edges
                int adjVertex = e.dest; // destination of the particular edge assigned
                evenOddHop[0][adjVertex] += evenOddHop[1][v]; // update the count of the odd paths from v to the adjVertex
                evenOddHop[1][adjVertex] += evenOddHop[0][v]; // update the count of the even paths from v to the adjVertex
            }
        }

        return evenOddHop;
        delete[] evenOddHop;
    }
};

#endif /* DAG_H_ */
