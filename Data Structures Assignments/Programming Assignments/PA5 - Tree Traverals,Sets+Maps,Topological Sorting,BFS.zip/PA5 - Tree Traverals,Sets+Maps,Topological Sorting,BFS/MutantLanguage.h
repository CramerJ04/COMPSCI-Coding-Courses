#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <string>
#include "Graph.h"
//#include <queue>
using namespace std;

#ifndef MUTANTLANGUAGE_H_
#define MUTANTLANGUAGE_H_

class MutantLanguage : public Graph {

	string* words;
	int numWords;
	int* inDegree;

public:

	MutantLanguage(string& filePath) {
		words = nullptr;
		inDegree = nullptr;
		readLanguage(filePath);
		makeGraph();
	}

	~MutantLanguage() {
		delete[] words;
		delete[] inDegree;
	}

	/*
	file is read as follows: 
	z y y y 
	z y y 
	
	z is the number of vert. coming out of 'edge' x
	y is where the edge z leads to, z times 

	////////////

	list<int> nameOfList; // creation of an interger list 
	nameOfList.size(); // get the size of the list 
	nameOfList.push_back(15); // add a number at the end of the list 
	nameOfList.push_front(15); // add a number at the beginning of the list 
	nameOfList.pop_back(); // removes last number 
	nameOfList.pop_front(); // removes first number 

	static void print(list<int> &numbers) { // printing the content of the list
	list<int>::iterator it = numbers.begin();
	while (it != numbers.end()) {
	cout << *it << " ";
	it++;
	}
	cout << endl;
	}

	list<int>::iterator it = numbers->begin() declares an iterator it on the list numbers
	and the iterator points to the first number on the list.

	it != numbers.end() ensures that the iterator traverses until the end of the list is reached.

	*it retrieves the value of the node at which the iterator is pointing, and thus cout << *it
	prints the value of the node at which the iterator is pointing.

	it++ for list traveral 

	////////////

	implementing queue with a linked list: 
	list<int> name; // creates queue 
	name.size(); // size of queue 
	name.push_back(15); // enqueues a number onto the queue
	name.front(); // get the first number in the queue 
	name.pop_front(); // removes said number 

	*/

private:

	void readLanguage(string& filePath) { 
		ifstream fileReader(filePath, ios::in);
		fileReader >> numVertices; // get number of distinct characters 
		fileReader >> numWords; // how many words 
		words = new string[numWords]; // allocated numWords cells for words 
		for (int i = 0; i < numWords; i++) {
			string y; 
			fileReader >> y; // grab the string from the file 
			words[i] = y; // put into words array 
		}
		fileReader.close(); // end the reading 
	}

	void makeGraph() {
		inDegree = new int[numVertices]; // allocating numVert cells for indegree array 
		adjList.reserve(numVertices); // allocating numVert rows for the list 
		for (int i = 0; i < numVertices; i++) { // each vert has zero after this execution 
			inDegree[i] = 0;
			adjList.push_back(list<Edge>()); 
			// Adding this blank row is necessary so that we have reserved a row for each vertex,
			// which will save us from a null pointer exception if we try to access an empty row
		}
		for (int i = 0; i < numWords - 1; i++) {
			string currentWord = words[i];
			string nextWord = words[i + 1];
			int minLength;
			if (currentWord.length() > nextWord.length()) {
				minLength = nextWord.length();
			}
			else {
				minLength = currentWord.length();
			}
			for (int j = 0; j < minLength; j++) {
				char x = currentWord.at(j);
				char y = nextWord.at(j);
				if (x != y) {
					int src = x - 97;
					int dest = y - 97;
					Edge e(src, dest);
					adjList.at(src).push_back(e);
					inDegree[dest]++;
					break;
				}
			}
		}
	}

public:

		/*
		list<int>::iterator it = numbers->begin() declares an iterator it on the list numbers
		and the iterator points to the first number on the list.

		it != numbers.end() ensures that the iterator traverses until the end of the list is reached.

		* it retrieves the value of the node at which the iterator is pointing, and thus cout << *it
		prints the value of the node at which the iterator is pointing.

		it++ for list traveral
		
		To create a queue: list<int> name;
		To find the size of the queue: name.size();
		To enqueue a number onto the queue: name.push back(15);
		To dequeue a number from the queue: use name.front(); to get the first number. Then use
		name.pop front(); to remove it.

		*/

	char* getOrder() { 
		char* topoOrder = new char[numVertices]; // created a dynamic array with num vert length 
		list<int> vertexQ;
		int topoLevel = 0;
		for (int i = 0; i < numVertices; i++) {
			if (inDegree[i] == 0) {
				vertexQ.push_back(i); // enqueues i 
			}
		}
		while (vertexQ.size() > 0) { 
			int v = vertexQ.front(); // get the first number in the queue 
			vertexQ.pop_front(); // removes said number 
			topoOrder[topoLevel] = (char)(v + 97);
			topoLevel++;
			list<Edge> &row = adjList.at(v);
			// row be the linked list corresponding to the row adjList[v]; notice that 
			// row is a linked list of type Edge
			list<Edge>::iterator it = row.begin();
			while (it != row.end()) {
				Edge &adjEdge = *it;
				it++;
				int w = adjEdge.dest;
				inDegree[w]--;
				if (inDegree[w] == 0) {
					vertexQ.push_back(w);
				}
			}
		}
		if (topoLevel != numVertices) {
			/*At the end we return null when all vertices have not been added to the topological
			order, which implies that the graph has a cycleand an ordering of the characters(and
			hence words) cannot be obtained.*/
			return nullptr;
		}
		return topoOrder;
	}
};

#endif /* MUTANTLANGUAGE_H_ */
