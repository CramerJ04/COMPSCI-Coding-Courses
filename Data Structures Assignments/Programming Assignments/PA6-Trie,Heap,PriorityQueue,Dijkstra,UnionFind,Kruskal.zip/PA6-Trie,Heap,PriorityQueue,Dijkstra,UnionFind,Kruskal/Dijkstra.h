#include <climits>
#include <iostream>
#include <queue>
#include <vector>

#include "Graph.h"
#include "IOHelper.h"
#include "PriorityQueuePair.h"
#include "PriorityQueuePairComparator.h"
using namespace std;

#ifndef DIJKSTRA_H_
#define DIJKSTRA_H_

class Dijkstra : public Graph {

private:

	bool* closed;

public:

	int* distance, * parent;

	~Dijkstra() {
	}

	Dijkstra(string& filePath) { // ***
		Graph DijkstraGraph;
		DijkstraGraph = IOHelper::readWeightedGraph(filePath);
		numVertices = DijkstraGraph.numVertices;
		adjList = DijkstraGraph.adjList;
	}

	void execute(int source) { // ***
		distance = new int[numVertices];
		parent = new int[numVertices];
		closed = new bool[numVertices];
		for (int i = 0; i < numVertices; i++)
		{
			distance[i] = INT_MAX;
			parent[i] = -1;
			closed[i] = false;
		}
		distance[source] = 0;
		priority_queue<PriorityQueuePair, vector<PriorityQueuePair>, PriorityQueuePairComparator> open; // needs to be fixed 
		PriorityQueuePair beginning(source, 0);
		//vector<int> returnList;
		open.push(beginning);
		while (open.size() != 0)
		{
			PriorityQueuePair temp = open.top(); // ???
			open.pop();
			PriorityQueuePair minElement = temp;
			int minVertex = minElement.item;
			if (closed[minVertex] == true) {
				// skip other parts
			}
			else 
			{
				closed[minVertex] = true;
				for (Edge adjEdge : adjList.at(minVertex))
				{
					int adjVertex = adjEdge.dest;
					if (closed[adjVertex] == false)
					{
						int newDist = distance[minVertex] + adjEdge.weight;
						distance[adjVertex] = newDist;
						parent[adjVertex] = minVertex;
						open.push(PriorityQueuePair(adjVertex, newDist)); // ???
						//returnList.push_back(temp.priority);
						//returnList->push_back(temp.priority);
					}
				}
			}
			//open.pop();
		}
	}

	void printDistanceArray() {
		cout << "[";
		for (int i = 0; i < numVertices - 1; i++) {
			if (distance[i] == INT_MAX)
				cout << "infty, ";
			else
				cout << distance[i] << ", ";
		}
		if (distance[numVertices - 1] == INT_MAX)
			cout << "infty]";
		else
			cout << distance[numVertices - 1] << "]";
	}

	void printParentArray() {
		cout << "[";
		for (int i = 0; i < numVertices - 1; i++) {
			cout << parent[i] << ", ";
		}
		cout << parent[numVertices - 1] << "]";
	}
};

#endif
