#include <iostream>
#include <algorithm>
#include <map>
using namespace std;

#ifndef KNAPSACK01_H_
#define KNAPSACK01_H_

class Knapsack01 {

public:

	static int findOptimalProfit(const int profits[], const int weights[], int numElements,
                                 int capacity) { 

        // two int arrays
        int* currentRow = new int[capacity + 1];
        int* prevRow = new int[capacity + 1];

        // setting all cells of prevRow to zero
        for (int i = 0; i < capacity + 1; i++) {
            prevRow[i] = 0;
        }

        // 
        for (int i = 0; i < numElements; i++) { // go through all of the elements
            for (int j = 0; j <= capacity; j++) { // 
                if (weights[i] > j) { // count up to the weight index
                    currentRow[j] = prevRow[j]; // set it to zero
                } else { // begin comparisons
                    int temp1 = prevRow[j]; // previous row value
                    int temp2 = prevRow[j - weights[i]] + profits[i]; // index, - weight value in the previous row
                    currentRow[j] = max(temp1, temp2); // pick the max of the two
                }
            }
                // copying new currentRow to the prevRow
                // we want to move to the next set
                for (int i = 0; i < capacity + 1; i++) {
                    prevRow[i] = currentRow[i]; // new current row onto prev
                }
        }
        return currentRow[capacity];
        delete[] currentRow;
        delete[] prevRow;
    }
};

#endif /* KNAPSACK01_H_ */