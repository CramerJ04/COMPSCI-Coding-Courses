#include <iostream>
#include <string>
using namespace std;

#ifndef MYSTRING_H_
#define MYSTRING_H_

class MyString: public string {

public:

	MyString(string str) {
		clear();
		append(str);
	}

	MyString() {
		clear();
	}

	void replaceChar(int pos, char c) {
		if (pos < 0 || pos >= length())
			throw "Invalid Index Access Exception";
		if (at(pos) == c)
			return;
		string str;
		str += c;
		replace(pos, 1, str);
	}

	void swapChar(int i, int j) {
		if (i < 0 || i >= length() || j < 0 || j >= length())
			throw "Invalid Index Access Exception";
		if (i == j)
			return;
		char f = at(i);
		replaceChar(i, at(j));
		replaceChar(j, f);
	}

	void reverse() { // complete this function
		for (int i = 0; i < length() / 2; i++) {
			swapChar(i,length() - i - 1);
		}
	}

	MyString toUpperCase() { // complete this function
		MyString temp = MyString();
		append(temp);
		for (int i = 0; i < length(); i++) {
			if (at(i) >= 97 && at(i) <= 122) {
				temp += at(i) - 32;
			}
			else {
				temp += at(i);
			}
		}
		return temp;
	}

	int compareIgnoreCase(MyString &arg) { // complete this function
		string temp = MyString(this->toUpperCase());
		string temp2 = MyString(arg.toUpperCase());

		int val = temp.compare(temp2);
		cout << val;
		return val;
	}

	void replaceAll(MyString &key, MyString &replacement) { // complete this function

		int index = find(key);
		while (index >= 0 && index <= length()) {
			replace(index, key.length(), replacement);
			index = find(key, index + replacement.length());
		}
	}
};

#endif /* MYSTRING_H_ */
