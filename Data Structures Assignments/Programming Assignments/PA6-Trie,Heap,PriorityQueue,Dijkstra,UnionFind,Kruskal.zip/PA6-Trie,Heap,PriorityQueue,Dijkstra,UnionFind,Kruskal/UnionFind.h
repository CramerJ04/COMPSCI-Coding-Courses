#include <vector>
using namespace std;

#ifndef UNIONFIND_H_
#define UNIONFIND_H_

class UnionFind {

	vector<vector<int>*> representatives;

public:

	UnionFind(int initialNumSets) { // ***
		representatives.reserve(initialNumSets);
		for (int i = 0; i < initialNumSets; i++)
		{
			representatives.push_back(NULL);
			makeSet(i);
		}
	}

	void makeSet(int x) {  // ***
		vector<int>* da = new vector<int>;
		da->push_back(x);
		representatives[x] = da;
	}

	vector<int>* find(int x) {  
		return representatives[x];
	}

	void append(vector<int>* arg1, vector<int>* arg2) { // ***
		/*while (arg2->size() != 0)
		{
			int x = arg2->at(arg2->size() - 1);
			representative[x] = arg1;
			agr1->push_back(x);
			arg2->pop_back();
		}*/
		while (arg2->size() > 0) {
			int x = arg2->at(arg2->size() - 1);
			arg2->pop_back();
			representatives[x] = arg1;
			arg1->push_back(x);
		}
	}

	void doUnion(int x, int y) {  // ***
		vector<int>* dax = find(x);
		vector<int>* day = find(y);
		if (dax != day)
		{
			if (dax->size() >= day->size())
			{
				append(dax, day);
			}
			else
			{
				append(day, dax);
			}
		}
	}
};

#endif /* UNIONFIND_H_ */
