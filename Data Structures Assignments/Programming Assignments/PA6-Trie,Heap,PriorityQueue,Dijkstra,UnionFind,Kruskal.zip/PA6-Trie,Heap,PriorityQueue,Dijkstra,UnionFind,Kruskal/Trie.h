#include <iostream>
#include <string>
#include "TrieNode.h"
using namespace std;

#ifndef TRIE_H_
#define TRIE_H_

class Trie {

	TrieNode* root;

public:

	Trie() {
		root = new TrieNode(0);
	}

private:

	TrieNode* locus(string& str) { // finding first part of a string 
		TrieNode* temp = root; // pointer on root 
		for (int i = 0; i < str.length(); i++) {
			char c = str.at(i); // element of the string 
			TrieNode* v = temp->edges[c]; // child of temp 
			if (v == nullptr) { // character c cannot be matched in the trie. 
			// This means tmp is the locus
				return temp;
			}
			else {
				temp = v;
			}
		}
		return temp;
	}

public:

	void insert(string& str) { // looking at characters after a locus 
		TrieNode* parent = locus(str); // parent is the locus of str. 
		for (int i = parent->depth; i < str.length(); i++) {
			char c = str.at(i);
			//TrieNode* child; 
			TrieNode* child = new TrieNode(i+1);
			parent->edges[c] = child;
			parent = child;
		}
	}

	bool search(string& str) {
		/*A string is found if the string is entirely matched, which implies that a string is found if the
		locus has the same depth as the length of the string itself, else it is not found.*/
		return 
			locus(str)->depth == str.length();
	}

	static string longestCommonSubstring(string& str1, string& str2) { 
		/*build a trie out of one of the strings, and match the other string in 
		the trie to find the longest common substring.*/
		Trie temp;
		for (int i = 0; i < str1.length(); i++) { // creating multiple nodes of each suffix 
			// suffix is the string after the designated location 
			string sub = str1.substr(i);
			temp.insert(sub);
		}
		string lcs = ""; // will store longest common substring 
		for (int i = 0; i < str2.length(); i++) {
			string sub = str2.substr(i, str2.length() - i);
			TrieNode* v = temp.locus(sub);
			if (v->depth > lcs.length()) { // found a longer common sub string 
				lcs = str2.substr(i, v->depth);
			}
		}
		return lcs;
	}
};

#endif /* TRIE_H_ */
