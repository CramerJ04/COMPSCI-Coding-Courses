#include <string>
#include <iostream>
#include <sstream>
using namespace std;

#ifndef STUDENT_H_
#define STUDENT_H_

class Student {

public:

	string name;
	double grade;

	Student() {
		name = "";
		grade = 0;
	}

	Student(string nameArg, double gradeArg) {
		name = nameArg;
		grade = gradeArg;
	}

	string toString() {
		ostringstream out;
		out.precision(2);
		out << fixed << grade;
		string output = "(" + name + "," + out.str() + ")";
		return output;
	}
};

#endif /* STUDENT_H_ */
