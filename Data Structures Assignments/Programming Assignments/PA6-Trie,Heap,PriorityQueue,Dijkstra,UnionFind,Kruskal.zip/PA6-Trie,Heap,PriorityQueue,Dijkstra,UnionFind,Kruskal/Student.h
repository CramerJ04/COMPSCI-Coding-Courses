#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

#ifndef STUDENT_H_
#define STUDENT_H_

class Student {

public:
	string name;
	int grade;

	Student(string name, int grade) {
		this->name = name;
		this->grade = grade;
	}

	Student() {
		this->name = "";
		this->grade = 0;
	}

	string toString() const {
		string output = "(";
		output.append(name);
		output.append(", ");
		output.append(to_string(grade));
		output.append(")");
		return output;
	}
};

#endif /* STUDENT_H_ */
