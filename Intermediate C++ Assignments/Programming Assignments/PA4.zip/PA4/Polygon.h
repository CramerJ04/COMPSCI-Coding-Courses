#include <iostream>
#include "Point.h"
class Polygon
{
	Point** corners;
	int sides;
public:
	Polygon(double *xs, double* ys, int n)
	{
		sides = n;
		corners = new Point * [n];
		for (int i = 0; i < n; i++) 
		{
			corners[i] = new Point(xs[i], ys[i]);
		}
	}


	double perimeter()
	{
		double perm = 0;
		for (int i = 0; i < sides - 1; i++)
		{
			perm += corners[i]->distance(corners[i + 1]);
		}
		perm + (corners[sides - 1]->distance(corners[0]));
		return perm;
	}


};
