//#include <string>
//#include <vector>
//#include <stdio.h>
//
//#include "IOHelper.h"
//#include "StringComparator.h"
//#include "StudentComparator.h"
//using namespace std;
//
//#ifndef GENERICSELECTIONSORT_CPP_
//#define GENERICSELECTIONSORT_CPP_
//
//template<class T, class F>
//class GenericSelectionSort { // A generic class for selection sorting comparable objects
//
//public:
//
//	F comparator; // This is used to compare the objects of the class
//
//	void sort(vector<T>& content) {
//		for (int i = 0; i < content.size() - 1; i++) {
//			int minIndex = i;
//			for (int j = i + 1; j < content.size(); j++) {
//				T& minValue = content.at(minIndex); // get the reference to the object at minIndex
//				T& currentValue = content.at(j); // get the reference to the object at j
//				if (!comparator(currentValue, minValue)) { // this checks if currentValue is smaller than minValue
//					// comparator(currentValue, minValue) returns
//					// false, if currentValue is smaller than/equals minValue
//					// true, otherwise
//					minIndex = j;
//				}
//			}
//			// swap contents
//			T temp = content.at(minIndex);
//			content.at(minIndex) = content.at(i);
//			content.at(i) = temp;
//		}
//	}
//};
//
//#endif
//
//void stringSort() {
//	cout << "*** String Selection Sort ***\n\n";
//	string arr[] = { "abc", "def", "abcd", "bce", "abx", "acfe", "bfr", "xyz",
//			"de", "tyu", "ab", "abcd", "xy", "zxy", "abx", "def" };
//	vector<string> strings(arr, arr + 16);
//
//	// Create selection sort instance for sorting strings; use the comparator StringComparator
//	GenericSelectionSort<string, StringComparator> stringSelectionSort;
//
//	cout << "Original Order: ";
//	for (string& str : strings)
//		cout << str << " ";
//	stringSelectionSort.sort(strings);
//	cout << "\nAfter Sorting:  ";
//	for (string& str : strings)
//		cout << str << " ";
//	cout << endl << endl;
//}
//
//void studentSort() {
//	cout << "*** Student Selection Sort ***\n\n";
//	string path = "students.txt";
//	vector<Student> students = IOHelper::readStudents(path);
//	cout << "Original Order: ";
//	for (Student& student : students)
//		cout << student.toString() << " ";
//
//	// Create selection sort instance for sorting Students; use the comparator StudentComparator
//	GenericSelectionSort<Student, StudentComparator> studentSelectionSort;
//	studentSelectionSort.sort(students);
//	cout << "\nAfter Sorting:  ";
//	for (Student& student : students)
//		cout << student.toString() << " ";
//}

//int main() {
//	stringSort();
//	studentSort(); // this will work only if the StudentComparator and readStudents methods are complete.
//	return 1;
//}