#include <iostream>
#include <string>
using namespace std;

class StringFunctions
{
public:

	static int countVowels(string& str)
	{
		int count = 0; // number of vowels 
		string vowels = "aeiouAEIOU";
		for (int i = 0; i < str.length(); i++)
		{
			char c = str.at(i);
			// if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' ||
			// c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
			// count ++;
			int index = vowels.find(c); // find returns first index 
			if (index >= 0 && index < vowels.length()) // counting 
				count++;
		}
		return count; // output would be 10
	}

	static string makeAlphaNumeric(string& str)
	{
		string alphaNum = " ";
		for (int i = 0; i < str.length(); i++)
		{
			char c = str.at(i);
			if (c >= 97 && c <= 122) // a-z
				alphaNum += c;
			else if (c >= 65 && c <= 90) // A-Z
				alphaNum += c;
			else if (c >= 48 && c <= 57) // 0-9
				alphaNum += c;
		}
		return alphaNum;
	}

	static int makeDistinctLowercase(string& str)
	{
		string seen = " ";
		int count = 0;
		for (int i = 0; i < str.length(); i++)
		{
			char c = str.at(i);
			if (c >= 97 && c <= 122) // a-z
			{
				int index = seen.find(c); // have I seen c before?
				if (index < 0 || index >= seen.length()) // havent seen c before
				{
					count++; // add this occurance 
					seen += c; // make sure that we don't count it again by adding the chacter to seen 
				}
			}
		}
		return count;
	}

	static void replaceFirst(string& text, string& key, string& replacement)
	{
		// first looks for key in string 
		int index = text.find(key); // gives index where the key STARTS 
		if (index >= 0 && index < text.length()) // make sure index is within the string (bounds)
		{
			text.replace(index, key.length(), replacement); // (start from index, replace key.length characters with replacement)
			// ket rid of key and plug in replacement 
		}
	}

	static void eraseAll(string& text, string& key)
	{
		int index = text.find(key);
		while (index >= 0 && index < text.length()) // make sure index is within the string (bounds)
		{
			text.erase(index, key.length()); // starting from index, erase key.length() characters
			index = text.find(key);
			// goes to This, removes it, goes to the next 'this' and removes it 
		}
	}

	static string longestcommonsubstring(string& str1, string& str2)
	{
		string lcs = " "; // going to be the string 
			for (int i = 0; i < str1.length(); i++) // loop over str1
			{
				for (int j = str1.length() - i; j >= 1; j--)
				{
					string substr = str1.substr(i, j); // extract j characters starting from i 
					int index = str2.find(substr); // search each substr in str2
					if (index >= 0 && index < str2.length()) // newly found common substring is longer 
					{
						if (substr.length() > lcs.length()) // new found common substring is longer than the one which we already have 
						lcs = substr;
					}
					break; // no need to check further as we will only get shorter substrings 
				}
			}
		return lcs;
	}
};

int main()
{
	string str1 = "bc_ea_df_A_E_I_O_U_z_e_t_u_o_q";
	cout << "Number of vowels in " << str1 << "is: " << StringFunctions::countVowels(str1) << endl;
	string str2 = "HaoHSpqn&%#!*sjAKo";
	cout << "Number of ASCII characters in " << str2 << "is: " << StringFunctions::makeAlphaNumeric(str2) << endl;
	string str3 = "abcdeAC_3$hGanA";
	cout << "Number of lowercase distinct letters in " << str3 << "is: " << StringFunctions::makeDistinctLowercase(str3) << endl;
	
	string str1 = "abbcabdb";
	string str2 = "cbccabd";
	printf("Longest Common Substring of %s and %s is %s\n", str1.c_str(), str2.c_str(), StringFunctions::longestcommonsubstring(str1, str2));
	
	/*string str4 = "ReplaceThisButNotThis";
	string key1 = "This";
	string key2 = "_Those_";
	cout << "After replacement of " << key1 << " to " << key2 << " in " << str4 << " looks like : " << endl;
	StringFunctions::replaceFirst(str4, key1, key2);
	cout << str4;*/
	
};