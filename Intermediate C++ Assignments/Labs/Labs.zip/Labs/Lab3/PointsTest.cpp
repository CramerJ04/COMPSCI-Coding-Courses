#include <iostream>
#include "Point.h"
using namespace std;

int main()
{
	Point *A = new Point(5,7);
	Point *B = new Point(5,9);
	Segment L1('A', A, B);
	cout << "Length of segment A is: " << L1.length() << endl;
	Point* C = new Point(8,15);
	Segment L2('B', A, C);
	cout << "Length of segment B is: " << L2.length() << endl;
	Point* D = new Point(5, 9);
	Point* E = new Point(11,25);
	Segment L3('C', D, E);
	cout << "Length of segment C is: " << L3.length() << endl << endl;

	cout << "Slope of segment A is: " << L1.slope() << endl;
	cout << "Slope of segment B is: " << L2.slope() << endl;
	cout << "Slope of segment C is: " << L3.slope() << endl << endl;

	cout << "Segments B and C are: ";
	L2.check(&L3);
	cout << "Segments A and B are: ";
	L1.check(&L2);
	cout << endl;


	return 1;
}