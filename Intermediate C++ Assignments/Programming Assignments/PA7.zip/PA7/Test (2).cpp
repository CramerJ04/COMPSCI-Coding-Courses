#include "MatrixStuff.h"
#include <stdio.h>

static void printArray(int *arr, int n) {
    cout << "[" << arr[0];
    for (int i = 1; i < n; i++)
        cout << ", " << arr[i];
    cout << "]";
}

static void printMatrix(int **matrix, int n) {
    for (int i = 0; i < n; i++) {
        printArray(matrix[i], n);
        cout << endl;
    }
}

static void testDeterminant1() {
    int row0[] = {8};
    int *matrix[1] = {row0};
    cout << "\nDeterminant of the matrix\n";
    printMatrix(matrix, 1);
    cout << endl << "is " << MatrixStuff::determinant(matrix, 1) << endl;
}

static void testDeterminant2() {
    int row0[] = {4, 7};
    int row1[] = {1, 2};
    int *matrix[2] = {row0, row1};
    cout << "\nDeterminant of the matrix\n";
    printMatrix(matrix, 2);
    cout << endl << "is " << MatrixStuff::determinant(matrix, 2) << endl;
}

static void testDeterminant3() {
    int row0[] = {4, 7, 0};
    int row1[] = {1, 2, 3};
    int row2[] = {4, 1, 6};
    int *matrix[3] = {row0, row1, row2};
    cout << "\nDeterminant of the matrix\n";
    printMatrix(matrix, 3);
    cout << endl << "is " << MatrixStuff::determinant(matrix, 3) << endl;
}

static void testDeterminant4() {
    int row0[] = {5, 6, 1, 4};
    int row1[] = {-8, 7, 0, 6};
    int row2[] = {1, -8, -4, 2};
    int row3[] = {6, 0, 3, 1};
    int *matrix[4] = {row0, row1, row2, row3};
    cout << "\nDeterminant of the matrix\n";
    printMatrix(matrix, 4);
    cout << endl << "is " << MatrixStuff::determinant(matrix, 4) << endl;
}

static void testOrthogonal1() {
    int row0[] = { 0, 0, 0, 1 };
    int row1[] = { 0, 0, 1, 0 };
    int row2[] = { 1, 0, 0, 0 };
    int row3[] = { 0, 1, 0, 0 };
    int *square[4] = { row0, row1, row2, row3 };

    printMatrix(square, 4);
    cout << endl;
    if (MatrixStuff::isOrthogonal(square, 4))
        cout << "is orthogonal ";
    else 
        cout << "is not orthogonal";
}

static void testOrthogonal2() {
    int row0[] = { 0, 1, 0, 1 };
    int row1[] = { 0, 0, 1, 0 };
    int row2[] = { 1, 0, 0, 0 };
    int row3[] = { 0, 1, 0, 0 };
    int *square[4] = { row0, row1, row2, row3 };

    printMatrix(square, 4);
    cout << endl;
    if (MatrixStuff::isOrthogonal(square, 4))
        cout << "is orthogonal ";
    else 
        cout << "is not orthogonal";
}

static void testOrthogonal3() {
    int row0[] = { 1, 0 };
    int row1[] = { 0, -1 };
    int *square[2] = { row0, row1 };

    printMatrix(square, 2);
    cout << endl;
    if (MatrixStuff::isOrthogonal(square, 2))
        cout << "is orthogonal ";
    else 
        cout << "is not orthogonal";
}
	
int main() {
    cout << "*** Matrix Orthogonality ***" << endl;
    testOrthogonal1();
    cout << endl << endl;
    testOrthogonal2();
    cout << endl << endl;
    testOrthogonal3();
    cout << "\n\n*** Matrix Determinant ***" << endl;
   testDeterminant1();
   testDeterminant2();
   testDeterminant3();
   testDeterminant4();
    return 1;
}
