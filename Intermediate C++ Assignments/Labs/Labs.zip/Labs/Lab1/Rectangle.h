#include <iostream>
using namespace std;

class Rectangle
{
	private:

	double length;
	double width;
	char name;
	//double area = length * width;
	//double perimeter = 2 * (length * width);

	public:

		Rectangle(double length, double width, char name)
		{
			this->length = length;
			this->width = width;
			this->name = name;
			cout << "Rectangle " << name << " created." << endl;
		}

		~Rectangle()

		{
			cout << "Rectangle " << name << " destroyed." << endl;
		}

		double area()
		{
			double area;
			area = length * width;
			return area;
		}

		double perimeter()
		{
			double perimeter;
			perimeter = (2 * (length + width));
			return perimeter;
		}

};