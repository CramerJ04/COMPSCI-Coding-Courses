#include <string>
#include "ShapeType.h"
using namespace std;

#ifndef SHAPE_H_
#define SHAPE_H_

class Shape {

protected:

	ShapeType shapeType;
	string shapeName;

public: 

	Shape(ShapeType shapeTypeArg, string shapeNameArg) {
		this->shapeType = shapeTypeArg;
		this->shapeName = shapeNameArg; 
	}

	virtual double area() {
		return 0;
	}

	virtual double volume() {
		return 0;
	}

	ShapeType getShape() {
		return shapeType;
	}
	string getShapeName() {
		return shapeName;
	}

	string name() {
		return shapeName;
	}

	ShapeType type() {
		return shapeType;
	}

	string toString() {
		return shapeName + ", AREA: " + to_string(area()) + ", VOLUME: "
			+ to_string(volume());
	}
};

#endif /* SHAPE_H_ */
