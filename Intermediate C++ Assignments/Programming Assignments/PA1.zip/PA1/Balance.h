 
#include<iostream>
#include "Stack.h"


using namespace std;

class BalancedParenthesis {

	char* expression;
	int length;

public:
	BalancedParenthesis(char* exp, int len) {
		expression = exp;
		length = len;
		printString();
	}

	void printString() {
		for (int i = 0; i < length; i++)
			cout << expression[i];
	}

	bool isBalanced() {
		Stack stack(length);
		char c = 'A';
		char f;
		for (int i = 0; i < length; i++)
		{
			if (expression[i] == '(' || expression[i] == '{')
			{
				char c = expression[i];
				stack.push(c); // make an object, do we need class name here?
			}
			else if (expression[i] == ')' || expression[i] == '}')
			{
				if (stack.size() == 0)
				{
					return false;
				}
				char g = stack.pop();
				if (g == '(' && c == '}')
				{
					return false;
				}
				if (g == '{' && c == ')')
				{
					return false;
				}
			};
		};
		if (stack.size() == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
		for (int i = 0; i < length; i++)
		{
			cout << expression[i];
		}
	}
};