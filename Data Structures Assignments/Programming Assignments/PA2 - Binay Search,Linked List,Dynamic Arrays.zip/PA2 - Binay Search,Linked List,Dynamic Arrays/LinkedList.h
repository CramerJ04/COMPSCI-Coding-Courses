#pragma once
#include "ListNode.h"

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_

class LinkedList {

public:

	ListNode* head, * tail;
	int size;

	LinkedList() {
		head = tail = NULL;
		size = 0;
	}

	void insertAfter(ListNode* argNode, int value) { // complete this method
		if (argNode == NULL) {
			cout << "argNode cannot be invalid" << endl;
		}
		ListNode* newNode = new ListNode(value);
		newNode->next = argNode->next;
		argNode->next = newNode;
		if (argNode == tail) {
			tail = newNode;
		}
		size++;
	}

	void deleteAfter(ListNode* argNode) { // complete this method
		if (argNode == NULL) {
			cout << "argNode cannot be invalid" << endl;
		}
		if (argNode == tail) {
			cout << "Nothing To Delete!" << endl;
		}
		else if (argNode->next == tail) {
			delete tail;
			tail = argNode;
			size--;
			//argNode = tail;
			
		}
		else {
			ListNode* temp = argNode->next;
			argNode->next = temp->next;
			delete temp;
			size--;
		}
	}

	void selectionSort() { // complete this method
		ListNode* iNode; // head of the linked list 
		ListNode* minNode; // minumum value node 
		ListNode* jNode; // next node, after inode 
		iNode = head; // head here 
		for (int i = 0; i < size; i++) // looking through the entire list...
		{
			minNode = iNode; // set "minimum value" to the head 
			jNode = iNode->next; // node after iNode (head)
			for (int j = i + 1; j < size; j++) {
				if (minNode->value > jNode->value) { // if the "minNode" value is more than the next nodes value
					minNode = jNode; // 
				}
				jNode = jNode->next;
			}
			int temp = minNode->value; // grab minnodes value
			minNode->value = iNode->value; 
			iNode->value = temp; 
			iNode = iNode->next;
		}
	}

	bool removeDuplicatesSorted() { // complete this method
		ListNode* temp = head;
		ListNode* jNode;
		for (int i = 0; i < size - 1; i++) { // list should be sorted coming out of this 
			jNode = temp->next;
			if (temp->value > jNode->value) {
				return false;
			}
			else {
				temp = temp->next;
			}
		}
		//cout << "XXXXXXXX" << endl;
		ListNode* temp2 = head;
		ListNode* jNode2;
		while (temp2 != tail) {
			jNode2 = temp2->next;
			if (temp2->value == jNode2->value) {
				deleteAfter(temp2);
			}
			else {
				temp2 = temp2->next;
			}
		}
	}

	void pushOddIndexesToTheBack() { // complete this method
		ListNode* temp = head;
		ListNode* jNode;
		ListNode* temptail = tail;
		for (int i = 0; i < size / 2; i++) {
			jNode = temp->next;
			insertAtEnd(jNode->value);
			deleteAfter(temp);
			temp = temp->next; // next node 
		}
	}

	void reverse() { // complete this method
		ListNode* prev;
		ListNode* curr;
		ListNode* temp;
		prev = head;
		curr = head->next;
		if (size <= 1) {
			return;
		}
		while (curr != NULL) {
			temp = curr->next;
			curr->next = prev;
			prev = curr;
			curr = temp;
		}
		swap(head, tail);
		tail->next = NULL;
	}

	ListNode* insertAtFront(int value) {
		ListNode* newNode = new ListNode(value);
		if (size == 0) {
			head = tail = newNode;
		}
		else {
			newNode->next = head;
			head = newNode;
		}
		size++;
		return newNode;
	}

	ListNode* insertAtEnd(int value) {
		ListNode* newNode = new ListNode(value);
		if (size == 0) {
			head = tail = newNode;
		}
		else {
			tail->next = newNode;
			tail = newNode;
		}
		size++;
		return newNode;
	}

	void deleteHead() {
		if (0 == size) {
			cout << "Cannot delete from an empty list" << endl;
		}
		else if (1 == size) {
			size--;
			delete head;
		}
		else {
			size--;
			ListNode* tmp = head;
			head = head->next;
			delete tmp;
		}
	}

	ListNode* getNodeAt(int pos) {
		if (pos < 0 || pos >= size) {
			cout << "No such position exists" << endl;
			return NULL;
		}
		else {
			ListNode* tmp = head;
			for (int i = 0; i < pos; i++)
				tmp = tmp->next;
			return tmp;
		}
	}

	void printList() {
		if (size == 0)
			cout << "[]" << endl;
		else {
			ListNode* tmp = head;
			cout << "[";
			for (int i = 0; i < size - 1; i++) {
				cout << tmp->value << " -> ";
				tmp = tmp->next;
			}
			cout << tail->value << "]" << endl;
		}
	}

	int getSize() {
		return size;
	}
};

#endif /* LINKEDLIST_H_ */
