#include <string>
#include <iostream>
using namespace std;

#ifndef TICTACTOE_H_
#define TICTACTOE_H_

class TicTacToe {
public:

	char** M;
	int dim;
	char turn;

	TicTacToe(int d)
	{
		dim = d;
		turn = 'X';
		M = new char* [dim]; // states how many rows (pointers to each)
		//char* col = new char[dim]; // columns
		for (int i = 0; i < dim; i++) // each cell = 0
		{
			M[i] = new char[dim];
			for (int j = 0; j < dim; j++)
			{
				M[i][j] = '\0';
			}
		}
	}
	~TicTacToe()
	{
		for (int i = 0; i < dim; i++)
		{
			delete[]M[i];
			delete[]M;
		}
	}

	void printBoard()
	{
		for (int i = 0; i < dim; i++)
		{
			cout << "[";
			for (int j = 0; j < dim; j++)
			{
				if (M[i][j] == '\0')
				{
					cout << i * dim + j;
				}
				if (j == dim - 1)
				{
					cout << M[i][j];
				}
				else
					cout << M[i][j] << ", ";
			}
			cout << "]";
			cout << endl;
		}
	}

	bool checkWin(int r, int c)
	{
		int count = 0;
		int Finalcount = 0;
		for (int i = 0; i < dim; i++) // rows 
		{
			if (M[r][i] == turn)
			{
				count++;
			}
		}
		if (count == dim)
		{
			return true;
		}
		else count = 0;
		for (int i = 0; i < dim; i++) // columns
		{
			if (M[i][c] == turn)
			{
				count++;
			}
		}
		if (count == dim)
		{
			return true;
		}
		else count = 0;

		for (int i = 0; i < dim; i++) // minor diagonal bottom left to top right 
		{
			if (M[(dim - 1) - i][i] == turn) //M[(r - 1) - i][i] == 'X'
			{
				count++;
			}
		}
		if (count == dim)
		{
			return true;
		}
			else count = 0;
		for (int i = 0; i < dim; i++) // minor diagonal top left to bottom right 
		{
			if (M[i][i] == turn)
				{
					count++;
				}
		}
		if (count == dim)
		{
			return true;
		}
		else count = 0;
		return false;
	}

	void play(int* choiceSequence, int numChoices) {
		printBoard();
		for (int i = 0; i < numChoices; i++) {
			int r, c;
			cout << " Turn for " << turn << ": chooses " << choiceSequence[i] << " " << endl;
			if (choiceSequence[i] < 0 || choiceSequence[i] > (dim * dim - 1)) {
				cout << "Invalid Choice. Must choose a number between 0 to " << (dim * dim - 1) << endl;
			}
			else {
				r = choiceSequence[i] / dim;
				c = choiceSequence[i] % dim;
				if (M[r][c] != '\0') {
					cout << "Invalid Choice. Slot is already taken!!" << endl;
				}
				else {
					M[r][c] = turn;
					printBoard();
					if (checkWin(r, c) == true) {
						cout << turn << " Has won!!!";
						break;
					}
					if ((i + 1) == numChoices) {

						cout << "The Game is a Draw";
						break;

					}
					if (turn == 'X') {
						turn = 'Y';
					}
					else
						turn = 'X';

				}
			}
		}
	}
};

#endif /* TICTACTOE_H_ */
