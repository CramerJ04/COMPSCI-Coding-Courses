#include "Shape.h"
#include "ErrorType.h"

#include <cmath>

#ifndef CYLINDER_H_
#define CYLINDER_H_

class Cylinder : public Shape {

private:

	double radius, height;

public: 

	Cylinder(string nameArg, double radiusArg, double heightArg) : Shape(CYLINDER, nameArg) {
		this->radius = radiusArg;
		this->height = heightArg;

		if (radius || height < 0) {
			throw(ErrorType::INVALID_LENGTH_ARGUMENT);
		}
	}

	double area() {
		return (2 * 3.14 * radius * height + 2 * 3.14 * (radius * radius));
	}

	double volume() {
		return (3.14 * (radius * radius) * height);
	}

};

#endif /* CYLINDER_H_ */
