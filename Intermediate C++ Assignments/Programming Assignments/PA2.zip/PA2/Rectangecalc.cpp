#include <iostream>
#include "Rectangle.h"
#include "CountKeysInArray.h"
using namespace std;

void testRectangles()
{
	Rectangle rect1('A', 15, 10);
	Rectangle rect2('B', 5, 100);
	Rectangle rect3('C', 30, 5);
	Rectangle rect4('D', 20, 5);
	Rectangle rect5('E', 10, 5);
	cout << "Number of rectangles created: " << Rectangle::Creations() << endl;
	cout << "******************" << endl;
	cout << "Area of rectange A is: " << rect1.area() << endl;
	cout << "Perimeter of rectangle B is: " << rect2.perimeter() << endl;
	cout << "******************" << endl;
	rect1.compareArea(rect2);
	rect1.compareArea(rect3);
	rect1.compareArea(rect4);
	cout << "******************" << endl;
	rect1.comparePerimeter(&rect2); // & here for pointer 
	rect1.comparePerimeter(&rect4);
	rect1.comparePerimeter(&rect5);
	cout << "******************" << endl;
	cout << "******************" << endl;
	cout << "******************" << endl;

};

void testKeys()
{
	int arr[] = { -13,47,-13,21,51,-13,77,-13,1,-13 };
	int length = 10;
	cout << endl <<  "Array is: [";
	for (int i = 0; i < length; i++)
	{
		if (i == length - 1)
		{
			cout << arr[i] << "]" << endl;
		}
		else
			cout << arr[i] << ", ";
	};
	cout << "The number of occurences of 14 in the array is: " << CountKeysInArray::countKey(arr, length, 14) << endl;
	cout << "The number of occurences of 1 in the array is: " << CountKeysInArray::countKey(arr, length, 1) << endl;
	cout << "The number of occurences of -13 in the array is: " << CountKeysInArray::countKey(arr, length, -13) << endl;
	cout << "The number of occurences of -13 in the array [-1, 5]: " << CountKeysInArray::countKey(arr, length, -1, 5, -13) << endl;
	cout << "The number of occurences of -13 in the array [1, 10]: " << CountKeysInArray::countKey(arr, length, 1, 10, -13) << endl;
	cout << "The number of occurences of -13 in the array [6, 5]: " << CountKeysInArray::countKey(arr, length, 6, 5, -13) << endl;
	cout << "The number of occurences of -13 in the array [1, 5]: " << CountKeysInArray::countKey(arr, length, 1, 5, -13) << endl;
	cout << "The number of occurences of -13 in the array [2, 2]: " << CountKeysInArray::countKey(arr, length, 2, 2, -13) << endl;
}


	/*if (CountKeysInArray::countKey(arr, 10, 14) == -1) // counting number of 14's 
	{
		cout << "Number of occurences of 14 in the array is: 0" << endl;
	}
	else
		cout << "The number of occurences of 14 in the array is: " << CountKeysInArray::countKey(arr, 10, 14) << endl;

	if (CountKeysInArray::countKey(arr, 10, 1) == -1) // counting number of 14's 
	{
		cout << "Number of occurences of 1 in the array is: 0" << endl;
	}
	else
		cout << "The number of occurences of 14 in the array is: " << CountKeysInArray::countKey(arr, 10, 1) << endl;

	if (CountKeysInArray::countKey(arr, 10, -13) == -1) // counting number of 14's 
	{
		cout << "Number of occurences of -13 in the array is: 0" << endl;
	}
	else
		cout << "The number of occurences of 14 in the array is: " << CountKeysInArray::countKey(arr, 10, -13) << endl;*/



int Rectangle::numInstancesCreated = 0;

int main()
{
	testRectangles();
	testKeys();
	return 0;
}