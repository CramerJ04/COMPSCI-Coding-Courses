//#include <string>
//#include <algorithm>
//#include <iostream>
//#include <vector>
//#include "Student.h"
//using namespace std;
//
//class SortStudentsByName {
//
//public:
//
//	bool operator()(const Student& arg1, const Student& arg2) const {
//		return arg1.name < arg2.name;
//	}
//};
//
//class SortStudentsByGrade {
//
//public:
//
//	bool operator()(const Student& arg1, const Student& arg2) const {
//		return arg1.grade < arg2.grade;
//	}
//};
//
//static string names[] = { "E", "A", "Z", "F", "R", "T", "A", "C", "P" };
//static int grades[] = { 97, 45, 83, 77, 88, 76, 89, 91, 20, };
//
//static void print(vector<Student>& students) {
//	cout << "[" << students.at(0).toString();
//	for (int i = 1; i < students.size(); i++)
//		cout << ", " << students.at(i).toString();
//	cout << "]";
//	cout << endl;
//}

//int main() {
//	vector<Student> students;
//	for (int i = 0; i < sizeof(grades) / sizeof(int); i++) {
//		Student s(names[i], grades[i]);
//		students.push_back(s);
//	}
//
//	cout << "Original:        ";
//	print(students);
//
//	sort(students.begin(), students.end(), SortStudentsByName());
//	cout << "Sorted by name:  ";
//	print(students);
//
//	sort(students.begin(), students.end(), SortStudentsByGrade());
//	cout << "Sorted by grade: ";
//	print(students);
//
//}