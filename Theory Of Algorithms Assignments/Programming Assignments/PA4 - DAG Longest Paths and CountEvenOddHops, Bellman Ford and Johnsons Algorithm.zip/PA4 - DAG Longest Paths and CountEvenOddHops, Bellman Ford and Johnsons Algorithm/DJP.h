#include <climits>
#include "Graph.h"

#ifndef DJP_H_
#define DJP_H_

typedef pair<int, int> element;

class DJP: public Graph {

public:

	DJP(const string &filePath, const GraphType &type) :
			Graph(filePath, type) {
	}

	vector<Edge> execute() { // complete this function
        int* label = new int[numVertices];
        int* closed = new int[numVertices];
        vector<Edge> parent(numVertices);
        
        for (int i = 0; i < numVertices; i++) {
            label[i] = INT_MAX;
            closed[i] = false;
        }
        priority_queue<element, vector<element>, greater<element> > open;
        open.push(make_pair(0, numVertices - 1));
        label[numVertices - 1] = 0;

        while (open.size() > 0) {
            int minVertex = open.top().second;
            open.pop();
            closed[minVertex] = true;
            for (Edge adjEdge : adjList.at(minVertex)) {
                int adjVertex = adjEdge.dest;
                if (!closed[adjVertex]) {
                    if (adjEdge.weight < label[adjVertex]){
                        label[adjVertex] = adjEdge.weight;
                        parent[adjVertex] = adjEdge;
                        open.push(make_pair(adjEdge.weight, adjVertex));
                    }
                }
            }
        }
        delete[] label;
        delete[] closed;
        parent.pop_back();
        return parent;
	}
};

#endif /* DJP_H_ */
