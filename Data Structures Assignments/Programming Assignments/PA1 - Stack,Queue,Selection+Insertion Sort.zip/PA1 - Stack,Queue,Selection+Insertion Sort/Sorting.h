#include <iostream>
using namespace std;

#ifndef SORTING_H_
#define SORTING_H_

class Sorting {

public:

	void selectionSort(int array[], int arrayLen) { 
		// selection sort looks for the smallest (or other) value in the array, 
		// and swaps it from the index being looked at 
		// one by one the array is solved 
		int i;
		int j;
		int value;
        for (i = 0; i < arrayLen - 1; i++) // looking through the entire array...
        {
            value = i;
			for (j = i + 1; j < arrayLen; j++) // looking at all numbers passed value, such as the first number 
			{
				if (array[j] < array[value]) { // if the value found is less than the value being evaluated, assign value to be this value (lowest)
					value = j; 
					printArray(array, arrayLen);
					cout << endl;
				}

				if (value != i) { // if the index isn't the same (a value that is smaller has been found) swap the places 
					swap(array[value], array[i]);
					printArray(array, arrayLen);
					cout << endl;
				} // if not go to the next values and evaluate them - values increasing 
			}
			cout << endl;
			cout << "Sorted " << i << " times: ";
			printArray(array, arrayLen);
			cout << endl;
        }
	}

	void insertionSort(int array[], int arrayLen) { 
		// insertion sort looks through the array piece by piece, and when a value smaller 
		// than the last is found, the array's
		// entire structure switches from that point
		// onto the next
		int i;
		int key;
		int j;
		for (i = 1; i < arrayLen; i++) // looking through the entire array...
		{
			key = array[i]; // key is assigned 
			j = i - 1; // j is one space behind i 

			while (j >= 0 && array[j] > key) // going through each index behind i, and seeing if the value is less than i 
			{
				array[j + 1] = array[j]; // if it is, swap the values
				j = j - 1; // and get a new value 
			}
			array[j + 1] = key; // make the next number the new key for evaluation 
			// if no evalution was made, go to the next key to be evaluated 
			cout << endl;
			cout << "Sorted " << i << " times: ";
			printArray(array, arrayLen);
			cout << endl;
		}
	}

	void printArray(int A[], int length) {
		cout << "[";
		for (int i = 0; i < length - 1; i++)
			cout << A[i] << ", ";
		cout << A[length - 1] << "]";
	}
};

#endif
