#include <iostream>

using namespace std;

int main() {

	int A[8] = { 1,3,9,13,17,19,21,27 };
	binarySearch(A, 0, 7, 17);
	return 1;
};

int binarySearch(A, left, right, key) {

	if (left > right) {
		return -1;
	}
	int mid = (left + right) / 2;
		if (A[mid] == key) {
			return mid;
		}
	if (key > A[mid]) {
		return binarySearch(A, mid + 1, right, key);
	}
	return binarySeach(A, left, mid - 1, key);

};
