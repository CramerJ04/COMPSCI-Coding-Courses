#include <iostream>
using namespace std;

class Recursion
{
public:

	static void killComputer()
	{
		killComputer();
	}

	static int factorial(int n)
	{
		cout << "Now Computing Factorial of " << n << endl;
		if (1 == n)
			return 1; // base-case
		return n * factorial(n - 1);
	}

	static int fibonacci(int n)
	{
		cout << "Now Computing fibonacci of " << n << endl;
		if (n <= 1)
			return 1;
		return fibonacci(n - 1) + fibonacci(n - 2);
	}

	static int sumDigits(int n)
	{
		if (n < 10)
			return n;
		int last = n % 10;
		int rem = n / 10;
		return last + sumDigits(rem);
	}

	static int sumPosIntDiv3(int n)
	{
		if (n < 3) return 0;
		if (n == 0) return 3; // not needed but good to have

		if (n % 3 == 0) // a 3 number 
			return n + sumPosIntDiv3(n - 3);
		else
			return sumPosIntDiv3(n - n % 3); // remainder 
	}

	static int sumArrayHelper(int* arr, int k) // sum of the first k numbers in the array 
	{
		if (k == 1)
			return arr[0];
		return 
			arr[k - 1] // the kth number 
			+ sumArrayHelper(arr, k - 1); // the sum of first (k - 1) numbers 
	}
	static int sumArrayHelperFull(int* arr, int len) // adds up entire function
	{
		return sumArrayHelper(arr, len);
	}

};

int main()
{
	//Recursion::killComputer();
	//cout << Recursion::factorial(6);
	//cout << Recursion::fibonacci(8);
	//cout << Recursion::sumDigits(461719);
	//cout << Recursion::sumPosIntDiv3(16);
	int A[] = { 5,1,45,5,4,10 };
	cout << Recursion::sumArrayHelper(A, sizeof(A) / sizeof(int));
	cout << Recursion::sumArrayHelperFull(A, sizeof(A) / sizeof(int));
	return 1;
}