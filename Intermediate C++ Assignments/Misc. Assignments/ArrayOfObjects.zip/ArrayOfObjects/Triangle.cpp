#include <cmath>
#include <iostream>
using namespace std;

class Point
{
public:
	double x, y;
	Point(double x, double y) // captures points and makes then into arguments 
	{
		this->x = x;
		this->y = y;
	}

	double distance(Point* arg) // computes distance between points 
	{
		double xdiff = x - arg->x;
		double ydiff = y - arg->y;
		return sqrt(xdiff * xdiff + ydiff * ydiff);
	}
	double area(Point* arg1, Point* arg2)
	{
		return abs(x * (arg1->y - arg2->y) + arg1->x * (arg2->y - y) + arg2->x * (y - arg1->y))/2.0;
	}

	//Point() // basic constructor 
		// constructor overloading meaning two constructors within the same class 
	//{
		//x = 0;
		//y = 0;
	//}
};

class Triangle
{
	Point *cornerA, *cornerB, *cornerC; // pointers that point to objcts  
	// elements are already made, so reuse them 
	// passing without parameters - add constructor 
public:

	Triangle(double xA, double xB, double xC, double yA, double yB, double yC) // now need to create points 
	{
		cornerA = new Point(xA, yA); // allocating memory 
		cornerB = new Point(xB, yB); 
		cornerC = new Point(xC, yC);
	} 

	double perimeter()
	{
		double a = cornerA->distance(cornerB); // side 1 
		double b = cornerB->distance(cornerC);
		double c = cornerC->distance(cornerA);

		return a + b + c;

	}

	double area()
	{
		return cornerA->area(cornerB, cornerC); // method is already made 
	}
};

int main()
{
	Triangle t(5, 13, 19, 7, 14, 26);
	cout << t.perimeter() << endl;
	cout << t.area();
	return 1;
}