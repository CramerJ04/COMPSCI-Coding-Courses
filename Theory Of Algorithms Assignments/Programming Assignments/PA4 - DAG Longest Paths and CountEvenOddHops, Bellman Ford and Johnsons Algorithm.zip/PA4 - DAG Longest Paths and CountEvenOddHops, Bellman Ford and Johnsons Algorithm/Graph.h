#include <iostream>
#include <fstream>
#include <vector>
#include "GraphType.h"
#include "Edge.h"
using namespace std;

#ifndef GRAPH_H_
#define GRAPH_H_

class Graph {

public:

	int numVertices;
	int numEdges;
	vector<vector<Edge> > adjList;

	Graph(const Graph *graph) {
		this->numVertices = graph->numVertices;
		this->numEdges = graph->numEdges;
		this->adjList = graph->adjList;
	}

	Graph(const string filePath, const GraphType &type) {
		createGraphFromFile(filePath, type);
	}

private:

	void createGraphFromFile(const string &filePath, const GraphType &type) {
		numVertices = 0;
		numEdges = 0;
		ifstream fileReader(filePath, ios::in);

		fileReader >> numVertices;
		fileReader >> numEdges;

		adjList.reserve(numVertices);
		for (int i = 0; i < numVertices; i++)
			adjList.push_back(vector<Edge>());

		for (int i = 0; i < numEdges; i++) {
			int src, dest, weight;

			fileReader >> src;
			fileReader >> dest;
			if (type == WEIGHTED) {
				fileReader >> weight;
				Edge edge(src, dest, weight);
				adjList.at(src).push_back(edge);
			} else {
				Edge edge(src, dest);
				adjList.at(src).push_back(edge);
			}
		}
		fileReader.close();
	}
};

#endif /* GRAPH_H_ */
