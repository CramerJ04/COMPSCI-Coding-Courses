#include <iostream>
#include <fstream>
using namespace std;

class Lab6 {

public:

	static void shiftColumnsRight(int **M, int row, int col)
	{
		cout << "Before Shifting: " << endl;
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < col; j++)
			{
				cout << M[i][j] << " ";
			}
			cout << endl;
		}
		cout << "After Shifting: "<< endl;
		for (int i = 0; i < row; i++)
		{
			for (int j = 4; j < col; j++)
			{
				cout << M[i][j] << " ";
			}
			for (int j = 0; j < col - 1; j++)
			{
				cout << M[i][j] << " ";
			}
			cout << endl;
		}
	}

	static int sumDiagonals(int** M, int row)
	{
		int sum = 0;
		cout << "Matrix is: " << endl;
		for (int i = 0; i < row; i++)
		{
			for (int j = 0; j < row; j++)
			{
				cout << M[i][j] << " ";
			}
			cout << endl;
		}
		for (int i = 0; i < row; i++)
		{
			sum += M[i][i];
		}
		for (int j = 0; j < row; j++)
		{
			sum += M[(row - 1) - j][j];
		}
		if (row % 2 == 0) // even 
			return sum;
		if (row % 2 != 0) // odd 
			return sum - M[row/2][row/2];
	}

	static int findMinimumInJaggedArray()
	{
		ifstream reader("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\Lab6\\Lab6 Stuff\\jagged.txt", ios::in);
		int len;
		reader >> len;

		int* numC = new int[len]; // allocating
		int** arr = new int*[len]; // creates array of pointer // number of rows 
		for (int r = 0; r < len; r++)
		{
			reader >> numC[r];
			arr[r] = new int[numC[r]]; // creates columns for specific pointer 
			for (int c = 0; c < numC[r]; c++)
			{
				reader >> arr[r][c];
			}
		}
		for (int r = 0; r < len; r++) // display 
		{
			for (int c = 0; c < numC[r]; c++) // must fix numC, rows have different values 
			{
				cout << arr[r][c] << " ";
			}
			cout << endl;
		}
		int min = arr[0][0];
		for (int i = 0; i < len; i++)
		{
			for (int j = 0; j < numC[i]; j++)
			{
				if (arr[i][j] < min)
				min = arr[i][j];
			}
		}
		return min;
		for (int r = 0; r < len; r++) // deallocating 
		{
			delete[]arr[r]; // deletes the array at row r (entire rows)
			delete[]arr; // deletes pointers 
		}
	}
};

int main() {
	int shiftMatrix_row0[] = { 1, 2, 3, 4, 5 };
	int shiftMatrix_row1[] = { 6, 7, 8, 9, 10 };
	int shiftMatrix_row2[] = { 11, 12, 13, 14, 15 };
	int shiftMatrix_row3[] = { 16, 17, 18, 19, 20 };
	int *shiftMatrix[] = { shiftMatrix_row0, shiftMatrix_row1, shiftMatrix_row2,
			shiftMatrix_row3 };
	Lab6::shiftColumnsRight(shiftMatrix, 4, 5);

	cout << endl << "**********************" << endl << endl;

	int diag5_row0[] = {1, 2, 3, 4, 5};
	int diag5_row1[] = { 6, 7, 8, 9, 10 };
	int diag5_row2[] = { 11, 12, 13, 14, 15 };
	int diag5_row3[] = { 16, 17, 18, 19, 20 };
	int diag5_row4[] = { 21, 22, 23, 24, 25 };

	int *diagonal5[] = { diag5_row0, diag5_row1, diag5_row2, diag5_row3,
			diag5_row4 };

	int sum = Lab6::sumDiagonals(diagonal5, 5);
	cout << "The sum is : " << sum << endl << endl;

	int diag4_row0[] = {1, 2, 3, 4};
	int diag4_row1[] = { 5, 6, 7, 8 };
	int diag4_row2[] = { 9, 10, 11, 12 };
	int diag4_row3[] = { 13, 14, 15, 16 };

	int *diagonal4[] = { diag4_row0, diag4_row1, diag4_row2, diag4_row3 };
	sum = Lab6::sumDiagonals(diagonal4, 4);
	cout << "The sum is : " << sum << endl;

	cout << endl << "**********************" << endl << endl;

	int min = Lab6::findMinimumInJaggedArray();
	cout << endl << "The minimum is " << min;
}

