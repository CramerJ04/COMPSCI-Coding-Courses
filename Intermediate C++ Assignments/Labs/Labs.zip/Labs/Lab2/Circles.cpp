#include "Circle.h"
using namespace std;

int main()
{
	Circle A(5, 7, 10, 'A');
	Circle B(18, 17, 24, 'B');
	Circle C(25, 30, 5, 'C');
	cout << "*****************" << endl;
	A.compare(&B);
	A.compare(&C);
	cout << "*****************" << endl;
	cout << "A and B intersect? ";
	double x = A.intersects(B);
	cout << x << endl;
	cout << "A and C intersect? ";
	double y = A.intersects(C);
	cout << y << endl;
	cout << "*****************" << endl;
	cout << "Number of cirles created: " << Circle::Creations() << endl;

}

int Circle::numInstancesCreated = 0;