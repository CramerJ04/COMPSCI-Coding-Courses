#include <iostream>
#include "BinaryTreeNode.h"
#include "TreeTraversals.h"
#include "SetsAndMaps.h"
#include "BFS.h"
#include "MutantLanguage.h"
using namespace std;

const static string DIRECTED_GRAPH1_PATH = "directed1.txt";
const static string DIRECTED_GRAPH2_PATH = "directed2.txt";
const static string UNDIRECTED_GRAPH1_PATH = "undirected1.txt";
const static string UNDIRECTED_GRAPH2_PATH = "undirected2.txt";
const static string MUTANT1_PATH = "mutant1.txt";
const static string MUTANT2_PATH = "mutant2.txt";
const static string MUTANT3_PATH = "mutant3.txt";

void printArray(int* A, int len) {
	if (0 == len)
		cout << "[]";
	else {
		cout << "[";
		for (int i = 0; i < len - 1; i++) {
			if (A[i] == INT_MIN)
				cout << "-infty, ";
			else if (A[i] == INT_MAX)
				cout << "infty, ";
			else
				cout << A[i] << ", ";
		}
		if (A[len - 1] == INT_MIN)
			cout << "-infty]";
		else if (A[len - 1] == INT_MAX)
			cout << "infty]";
		else
			cout << A[len - 1] << "]";
	}
}

void printArray(char* A, int len) {
	if (0 == len)
		cout << "[]";
	else {
		cout << "[";
		for (int i = 0; i < len - 1; i++) {
			cout << A[i] << ", ";
		}
		cout << A[len - 1] << "]";
	}
}

void printArray(bool* A, int len) {
	if (0 == len)
		cout << "[]";
	else {
		cout << "[";
		for (int i = 0; i < len - 1; i++) {
			if (A[i])
				cout << "true" << ", ";
			else
				cout << "false" << ", ";
		}
		if (A[len - 1])
			cout << "true]";
		else
			cout << "false]";
		cout << endl;
	}
}

static void printVector(vector<int>& vect) {
	if (vect.size() == 0) {
		cout << "[]";
		return;
	}
	cout << "[";
	for (int i = 0; i < vect.size() - 1; i++) {
		cout << vect.at(i) << ", ";
	}
	cout << vect.at(vect.size() - 1) << "]";
}

static void printVector(vector<char>& vect) {
	if (vect.size() == 0) {
		cout << "[]";
		return;
	}
	cout << "[";
	for (int i = 0; i < vect.size() - 1; i++) {
		cout << vect.at(i) << ", ";
	}
	cout << vect.at(vect.size() - 1) << "]";
}

static BinaryTreeNode* binaryTree() {
	BinaryTreeNode* node_22 = new BinaryTreeNode(22);
	BinaryTreeNode* node_8 = new BinaryTreeNode(8);
	BinaryTreeNode* node_16 = new BinaryTreeNode(16);
	BinaryTreeNode* node_14 = new BinaryTreeNode(14);
	BinaryTreeNode* node_20 = new BinaryTreeNode(20);
	BinaryTreeNode* node_24 = new BinaryTreeNode(24);
	BinaryTreeNode* node_8_2 = new BinaryTreeNode(8);
	BinaryTreeNode* node_0 = new BinaryTreeNode(0);
	BinaryTreeNode* node_6 = new BinaryTreeNode(6);
	BinaryTreeNode* node_11 = new BinaryTreeNode(11);
	BinaryTreeNode* node_20_2 = new BinaryTreeNode(20);
	BinaryTreeNode* node_5 = new BinaryTreeNode(5);
	BinaryTreeNode* node_70 = new BinaryTreeNode(70);

	node_22->left = node_8;
	node_22->right = node_16;
	node_8->left = node_14;
	node_8->right = node_20;
	node_16->left = node_24;
	node_16->right = node_8_2;
	node_14->left = node_0;
	node_14->right = node_6;
	node_20->right = node_11;
	node_8_2->right = node_20_2;
	node_6->left = node_5;
	node_6->right = node_70;

	return node_22;
}

static void testTreeTraversal() {
	cout << "*** Test Tree Traversals ***\n" << endl;
	cout << "Pre-order Traversal: ";
	TreeTraversals::preOrder(binaryTree());
	cout << "\nIn-order Traversal: ";
	TreeTraversals::inOrder(binaryTree());
	cout << "\nPost-order Traversal: ";
	TreeTraversals::postOrder(binaryTree());
	cout << endl << endl;
}

static void testOrdered() {
	cout << "*** Using Ordered Set & Map ***\n" << endl;
	char str[] = { 'a', 'b', 'r', 'a', 'c', 'a', 'd', 'a', 'b', 'r', 'a', '$' };
	int len = sizeof(str) / sizeof(char);
	cout << "Alphabet of ";
	printArray(str, len);
	vector<char> alphabet = SetsAndMaps::sortedAlphabet(str, len);
	cout << " is ";
	printVector(alphabet);

	cout << endl << "Sorted order of ";
	printArray(str, len);
	SetsAndMaps::sortedAlphabet(str, len);
	cout << " is ";
	SetsAndMaps::bstSort(str, len);
	printArray(str, len);
}

static void testZeroSumHelper(int* arr, int len) {
	bool isZero = SetsAndMaps::zeroSumSubArray(arr, len);
	printArray(arr, len);
	if (!isZero)
		printf(" has no subarray whose sum is zero.");
	else
		printf(" has a subarray whose sum is zero.");
	cout << endl;
}

static void testZeroSum() {
	cout << endl << endl << "*** Using Unordered Set & Map ***" << endl << endl;
	int arr1[] = { 12, -26, 1, 8, 9, -6, 4, -12, -3, 12 };
	testZeroSumHelper(arr1, sizeof(arr1) / sizeof(int));
	int arr2[] = { 1, 7, 19, -14, 1, -14, 12 };
	testZeroSumHelper(arr2, sizeof(arr2) / sizeof(int));
	int arr3[] = { 1, 7, 19, -14, 1, -14, 8, 9, -6, 4, -12, -3, 12 };
	testZeroSumHelper(arr3, sizeof(arr3) / sizeof(int));
	int arr4[] = { -6, 4, -12, -3, 12 };
	testZeroSumHelper(arr4, sizeof(arr4) / sizeof(int));
	int arr5[] = { -6, 4, -12, 0, -3, 12 };
	testZeroSumHelper(arr5, sizeof(arr5) / sizeof(int));
	int arr6[] = { 0, -6, 4, -12, -3, 12 };
	testZeroSumHelper(arr6, sizeof(arr6) / sizeof(int));
	int arr7[] = { 1, 8, 9, -6, 4, -12, -3 };
	testZeroSumHelper(arr7, sizeof(arr7) / sizeof(int));
	int arr8[] = { 1, 8, 9, 0 };
	testZeroSumHelper(arr8, sizeof(arr8) / sizeof(int));
}

void testHeavyHitters() {
	cout << endl;
	int arr[] = { 5, 3, 4, 5, 1, 3, 5, 3, 9, 4, 9, 2, 3, 8, 3, 0, 9, 3, 9 };
	cout << "Array is: ";
	printArray(arr, sizeof(arr) / sizeof(int));
	cout << endl;
	for (int i = 2; i <= 9; i++) {
		printf("%d-heavy hitters are: ", i);
		vector<int> heavy = SetsAndMaps::kHeavyHitters(arr,
			sizeof(arr) / sizeof(int), i);
		printVector(heavy);
		cout << endl;
	}

}


void testBFS() {
	cout << endl;
	string filePaths[] = { DIRECTED_GRAPH1_PATH, DIRECTED_GRAPH2_PATH };
	int numFiles = 2;
	for (int i = 0; i < numFiles; i++) {
		printf("*** Test BFS on Directed Graph %d ***\n\n", i + 1);
		BFS bfs(filePaths[i]);
		for (int j = 0; j < bfs.numVertices; j++) {
			bfs.execute(j);
			cout << "Level array (from v" << j << "):   ";
			printArray(bfs.level, bfs.numVertices);
			cout << endl;
		}
		cout << endl;
	}
}

void testComponent() {

	string filePaths[] = { UNDIRECTED_GRAPH1_PATH, UNDIRECTED_GRAPH2_PATH };
	int numFiles = 2;
	for (int i = 0; i < numFiles; i++) {
		printf("*** Test Component Counter on Undirected Graph %d ***\n\n",
			i + 1);
		BFS bfs(filePaths[i]);
		cout << "Number of components is " << bfs.countComponents() << endl
			<< endl;
	}
}

void testTransitiveClosure() {

	string filePaths[] = { DIRECTED_GRAPH1_PATH, DIRECTED_GRAPH2_PATH,
			UNDIRECTED_GRAPH1_PATH, UNDIRECTED_GRAPH2_PATH };
	int numFiles = 2;
	for (int i = 0; i < numFiles; i++) {
		printf("*** Test Transitive Closure on Directed Graph %d ***\n\n",
			i + 1);
		BFS bfs(filePaths[i]);
		bool** tc = bfs.computeTransitiveClosure();
		for (int j = 0; j < bfs.numVertices; j++)
			printArray(tc[j], bfs.numVertices);
		cout << endl;
	}
	for (int i = 0; i < numFiles; i++) {
		printf("*** Test Transitive Closure on Undirected Graph %d ***\n\n",
			i + 1);
		BFS dfs(filePaths[i + 2]);
		bool** tc = dfs.computeTransitiveClosure();
		for (int j = 0; j < dfs.numVertices; j++)
			printArray(tc[j], dfs.numVertices);
		cout << endl;
	}
}


void testMutantLanguage() {
	string filePaths[] = { MUTANT1_PATH, MUTANT2_PATH, MUTANT3_PATH };
	int numFiles = 3;
	for (int i = 0; i < numFiles; i++) {
		printf("*** Test Mutant Language %d ***\n\n", i + 1);
		MutantLanguage mutant(filePaths[i]);
		char* topoOrder = mutant.getOrder();
		if (topoOrder != nullptr) {
			cout << "Alphabet order: ";
			printArray(topoOrder, mutant.numVertices);
			cout << endl;
		}
		else
			cout << "Unfortunately, this language has circular dependency."
			<< endl;
		cout << endl;
	}
	
}


int main() {
	testTreeTraversal();
	testOrdered();
	testZeroSum();
	testHeavyHitters();
	testBFS();
	testComponent();
	testTransitiveClosure();
	testMutantLanguage();
	return 1;
}