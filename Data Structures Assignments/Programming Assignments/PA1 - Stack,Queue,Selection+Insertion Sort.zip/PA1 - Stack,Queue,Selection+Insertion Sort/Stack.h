#include <iostream>
#include <climits>
using namespace std;

#ifndef STACK_H_
#define STACK_H_

class Stack {

private:
	int maxStackSize, topOfStack;
	int* stack;

public:

	Stack(int maxStackSize) {
		if (maxStackSize <= 0)
			cout << "Stack size should be a positive integer.";
		else {
			this->maxStackSize = maxStackSize;
			topOfStack = -1;
			stack = new int[maxStackSize];
		}
	}

	~Stack() {
		delete stack;
	}

	void push(int val) { 
		if (topOfStack == maxStackSize - 1) {
			cout << "Cannot push, stack is full." << endl;
		}
		else
		{
			topOfStack++;
			stack[topOfStack] = val; // value being pushed is assigned to the stack 
		}
	}

	int pop() { 
		if (topOfStack == -1) {
			cout << "Cannot pop, stack is empty." << endl;
			return -999;
		}
		else
		{
			int y = stack[topOfStack]; // assigns a variable, and returns it
			topOfStack--; // top of stack moved because the element was removed 
			return y;
		}
	}

	int size() { 
		return topOfStack + 1; // size value returned no element changes 
	}
};

#endif
