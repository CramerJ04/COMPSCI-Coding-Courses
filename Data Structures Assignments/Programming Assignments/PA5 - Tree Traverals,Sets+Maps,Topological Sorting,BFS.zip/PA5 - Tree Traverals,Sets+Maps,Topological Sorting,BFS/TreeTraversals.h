#include <iostream>
#include "BinaryTreeNode.h"
using namespace std;

#ifndef TREETRAVERSALS_H_
#define TREETRAVERSALS_H_

class TreeTraversals {

public:

	static void preOrder(BinaryTreeNode* node) { 
		cout << node->value << " " ;
		if (node->left != nullptr) {
			preOrder(node->left);
		}
		if (node->right != nullptr) {
			preOrder(node->right);
		}
	}

	static void inOrder(BinaryTreeNode* node) { 
		if (node->left != nullptr) {
			inOrder(node->left);
		}
		cout << node->value << " ";
		if (node->right != nullptr) {
			inOrder(node->right);
		}

	}

	static void postOrder(BinaryTreeNode* node) { 
		if (node->left != nullptr) {
			postOrder(node->left);
		}
		if (node->right != nullptr) {
			postOrder(node->right);
		}
		cout << node->value << " ";
	}

};

#endif /* TREETRAVERSALS_H_ */
