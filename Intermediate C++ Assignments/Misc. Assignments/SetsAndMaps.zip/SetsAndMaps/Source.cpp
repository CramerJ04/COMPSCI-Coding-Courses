#include <iostream>
#include <unordered_set>
#include <unordered_map>
using namespace std;

bool containsDuplicates(int* arr, int len) {
	for (int i = 0; i < len; i++) {
		for (int j = i + 1; j < len; j++) {
			if (arr[i] == arr[j]) {
				return true;
			}
		}
	}
	return false;
}

bool containsDuplicatesUsingSets(int* arr, int len) {
	unordered_set<int> mySet;
	for (int i = 0; i < len; i++) {
		mySet.insert(arr[i]);
	}
	return len != mySet.size(); // if size of set is different, theres a duplicate. Returns 1 
}

void computeFrequencies(char* arr, int len) {
	for (int i = 0; i < len; i++) {
		int Frequency = 0;
		for (int j = 0; j < len; j++) { // entire array 
			if (arr[i] == arr[j]) {
				Frequency++;
			}
		}
		cout << arr[i] << ":" << Frequency << endl;
	}
}

void computeFrequenciesusingMap(char* arr, int len) {
	unordered_map<char, int> charToInt_Map;
	for (int i = 0; i < len; i++) {
		if (charToInt_Map.find(arr[i]) == charToInt_Map.end()) {
			// arr[i] is not in the map
			// so, insert into the map with value (frequency) as 1
			charToInt_Map[arr[i]] = 1;
		}
		else {
			// arr[i] is in the map 
			// so, increase its value (frequency) by 1 
			int currectFrequency = charToInt_Map[arr[i]]; // get the frequency in the map 
			currectFrequency++; // incerase frequency by 1 
			charToInt_Map[arr[i]] = currectFrequency; // place increased frequency back in the map 
		}
	}
}

int main() {

	unordered_set<int> intSet;
	intSet.insert(3);
	intSet.insert(7);
	intSet.insert(10);
	intSet.insert(15);
	intSet.insert(12);

	if (intSet.find(7) != intSet.end())  // if find finds 7, then the find returns a pointer to the position of 7 
		cout << "Found 7" << endl;
	else
		cout << "Did not find 7" << endl;

	if (intSet.find(17) != intSet.end())  // if it isn't there, find returns a pointer to the end of the set
		cout << "Found 17" << endl;
	else
		cout << "Did not find 17" << endl;

	unordered_set<int>::iterator int_it = intSet.begin(); // iterator is similar to a loop. Currectly it is pointed at the beginning of the set 
	while (int_it != intSet.end()) { // while not at the end 
		cout << *int_it << " "; // use pointers to de reference 
		int_it++; // move to next item 
	}

	int arr[] = { 3,9,13,7,1,13,8 };
	cout << containsDuplicates(arr, sizeof(arr) / sizeof(int)); // displays 1 if true, 0 if false (bool)
	cout << containsDuplicatesUsingSets(arr, sizeof(arr) / sizeof(int)); // displays 1 if true, 0 if false (bool)

	unordered_map<char, int> charToInt_Map;
	charToInt_Map['a'] = 37; // mapping the key 'a' to the integer 37 
	charToInt_Map['z'] = 45; 
	charToInt_Map['y'] = 93; 
	charToInt_Map['c'] = 37; 
	charToInt_Map['e'] = 12; 
	charToInt_Map['r'] = 99; 
	//charToInt_Map['z'] = -9999;

	unordered_map<char, int>::iterator it = charToInt_Map.begin();
	cout << endl;
	while (it != charToInt_Map.end()) {
		cout << it->first << " " << it->second << endl; // prints key, spcae, value
		it++; // moves key to the next spot 
	}

	char Carr[] = { 'a', 'b', 'c', 'a', 'a', 'c', 'a', 'x', 'y' }; // computing frequencies
	computeFrequencies(Carr, sizeof(arr) / sizeof(char));

	unordered_map<char, int>::iterator it2 = charToInt_Map.begin(); // printing map 
	cout << endl;
	while (it != charToInt_Map.end()) {
		cout << it2->first << " " << it2->second << endl;
		it2++;
	}

	computeFrequenciesusingMap(Carr, sizeof(arr) / sizeof(char));
	
	return 1;
}

