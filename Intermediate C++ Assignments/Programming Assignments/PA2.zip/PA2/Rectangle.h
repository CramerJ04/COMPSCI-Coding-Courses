#include <iostream>
using namespace std;

class Rectangle
{
private: 

	double length;
	double width; 
	char name;
	static int numInstancesCreated;

public:

	void prettyLength()
	{
		cout << "Rectangle (" << name << ", " << length << ", " << width << ")";
	}

	Rectangle(char name, double length, double width)
	{
		this->length = length;
		this->width = width;
		this->name = name;
		prettyLength();
		cout << "created." << endl;
		numInstancesCreated++;
	};

	int compareArea(Rectangle& rectArg) // pass by reference (rectArg = 2nd, this->rectArg is the first)
	// . for reference 
	{
		if (this->area() > rectArg.area())
		{
			cout << "Area of " << this->name << " is more than " << rectArg.name << endl;
			return 1; 
		}
		if (this->area() == rectArg.area())
		{
			cout << "Area of " << this->name << " equals " << rectArg.name << endl;
			return 0;
		}
		if (this->area() < rectArg.area())
		{
			cout << "Area of " << this->name << " is less than " << rectArg.name << endl;
			return -1;
		}
	}
	int comparePerimeter(Rectangle* rectArg) // this->rectArg first, rectArg->perimeter() second 
	{
		if (this->perimeter() > rectArg->perimeter())
		{
			cout << "Perimeter of " << this->name << " is more than " << rectArg->name << endl;
			return 1;
		}
		if (this->perimeter() == rectArg->perimeter())
		{
			cout << "Perimeter of " << this->name << " equals " << rectArg->name << endl;
			return 0;
		}
		if (this->perimeter() < rectArg->perimeter())
		{
			cout << "Perimeter of " << this->name << " is less than " << rectArg->name << endl;
			return -1;
		}
	}

	~Rectangle()
	{
		prettyLength();
		cout << "destroyed." << endl;
	};

	double area()
	{
		return length * width;
	}

	double perimeter()
	{
		return (2 * (length + width));
	}

	static int Creations()
	{
		return numInstancesCreated;
	}
};