#include "Graph.h"
#include <climits>

#ifndef DIJKSTRA_H_
#define DIJKSTRA_H_

typedef pair<int, int> element;

class Dijkstra: public Graph {

public:

	Dijkstra(const Graph *graph) :
			Graph(graph) {
	}

	int *execute(int source) {
		int* dist = new int[numVertices];
		int* closed = new int[numVertices];
		for (int i = 0; i < numVertices; i++) {
			dist[i] = INT_MAX;
			closed[i] = false;
		}
		priority_queue<element, vector<element>, greater_equal<element> > open;
		open.push(make_pair(0, source));
		dist[source] = 0;

		while (open.size() > 0) {
			int minVertex = open.top().second;
            open.pop();
			closed[minVertex] = true;
			for (int i = 0; i < adjList[minVertex].size(); i++) {
				int adjVertex = adjList[minVertex][i].dest;
				if (!closed[adjVertex]) {
					int newDist = dist[minVertex] + adjList[minVertex][i].weight;
					if (newDist < dist[adjVertex]){
						dist[adjVertex] = newDist;
						open.push(make_pair(newDist, adjVertex));
					}
				}
			}
		}
		delete[] closed;
		return dist;
	}
};

#endif /* DIJKSTRA_H_ */
