#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

class Person {

protected:

	string name;
	string dateOfBirth;

public:

	Person(string nameArg, string dateOfBirthArg) {
		name = nameArg;
		dateOfBirth = dateOfBirthArg;
	};

	string getName() {
		return name;
	}

	string getDOB() {
		return dateOfBirth;
	}

};

class Student : public Person {

protected:

	int major;

public:

	Student(string nameArg, string dateOfBirthArg, int majorIdArg) : Person(nameArg, dateOfBirthArg) {
		major = majorIdArg;
	}

	int getmajorId() {
		return major;
	}
};

class Employee : public Person {

protected:

	int dept;

	Employee(string nameArg, string dateOfBirthArg, int deptIdArg, bool partTimeArg) : Person(nameArg, dateOfBirthArg) {
		dept = deptIdArg;
	};

public:

	int getDeptId() {
		return dept;
	}

	virtual double getBaseSalary() {
		return 1500;
	}
};

class Faculty : public Employee {

protected:

	int numOfCources;

public:

	Faculty(string nameArg, string dateOfBirthArg, int deptIdArg, int numOfCourcesArg) : Employee(nameArg, dateOfBirthArg, deptIdArg, numOfCourcesArg) {
		numOfCources = numOfCourcesArg;
	};

	int getnumOfCources() {
		return numOfCources;
	}

	double getSalary() {
		return Employee::getBaseSalary() + 500 * numOfCources;
	}
};

class Staff : public Employee {

protected:

	bool partTime;

public:

	Staff(string nameArg, string dateOfBirthArg, int deptIdArg, bool partTimeArg) : Employee(nameArg, dateOfBirthArg, deptIdArg, partTimeArg) {
		partTime = partTimeArg;
	};

	bool getpartTime() {
		return partTime;
	}

	double getSalary() {
		return partTime ? 0.5 * Employee::getBaseSalary() : getBaseSalary();
	}
};

class prettyPrint {

public:
	static void printPerson(Person* p) {
		cout << p->getName() << endl;
		cout << p->getDOB() << endl;
	}

	static void printEmployee(Employee* e) {
		cout << e->getDeptId() << endl;;
	}

	static void print(Student* s) {
		printPerson(s);
		cout << s->getmajorId() << endl;
	}

	static void print(Staff* s) {
		printPerson(s);
		printEmployee(s);
		cout << s->getSalary() << endl;
	}

	static void print(Faculty* f) {
		printPerson(f);
		printEmployee(f);
		cout << f->getnumOfCources() << endl;
		cout << f->getSalary() << endl;
	}
};

static vector<string> split(string& str, string delimiter) {

	vector<string> tokens;
	string token; // individual tokens 
	// we want to extract strings before each "," and push it back into the array 
	int startIndex = 0; 
	int endIndex = str.find(delimiter); // ","
	
	while (endIndex >= 0 && endIndex < str.length()) {
		token = str.substr(startIndex, endIndex - startIndex); // where do we start, how long 
		tokens.push_back(token);
		startIndex = endIndex + 1; // new starting position, next character after endIndex 
		endIndex = str.find(delimiter, startIndex); // what are we looking for, where do we start 
	}
	token = str.substr(startIndex);
	tokens.push_back(token);
	return tokens;
}

void readFromCSV() {
	ifstream reader("C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\CSV\\CSV\\hr.csv", ios::in);
	string line;
	while (getline(reader, line)) { // get line returns true or false 
		cout << line << endl;
		vector<string> tokens = split(line, ",");
		// now we want to create blocks which determine which objects are created 
		if (tokens.at(0) == "S") { // create student object 
			Student s(tokens.at(1), tokens.at(2), stoi(tokens.at(3))); // name, DOB, major 
			prettyPrint::print(&s);
			cout << endl;
		}
		else if (tokens.at(0) == "F") { // create faculty object 
			Faculty f(tokens.at(1), (tokens.at(2)), stoi(tokens.at(3)), stoi(tokens.at(4)));
			prettyPrint::print(&f);
			cout << endl;
		}
		else { // create staff object 
			bool flag = tokens.at(4) == "true";
			Staff s(tokens.at(1), (tokens.at(2)), stoi(tokens.at(3)), flag);
			prettyPrint::print(&s);
			cout << endl;
		}
	}

	reader.close();
}

class Growablestack {

	vector<int> contents;

public: 

	void push(int arg) {
		contents.push_back(arg);
	}

	int pop() {
		int ret = contents.back(); // or contents.at(contents.size() - 1);
		contents.pop_back(); // gets rid of the number 
		return ret;
	}

	int peek() {
		return contents.back(); 
	}

	int size() {
		return contents.size();
	}
};

int main() {

	//string path = "C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\CSV\\CSV";
	//ofstream writer("out.txt", ios::out);

	//string str = "abc,123,def,false";
	//vector<string> tokens = split(str, ","); // spliting the string with the delimiter as the ","
	//for (int i = 0; i < tokens.size(); i++) {
	//	cout << tokens.at(i) << " "; 
	//}

	readFromCSV();

	/*Growablestack stack;
	for (int i = 0; i < 100; i++) { // this can change to see what kind of numbers you add
		stack.push(i);
	}

	// numbers return in reverse order due to popping

	while (stack.size() > 0) {
		cout << stack.pop() << " "; 
	}
	return 1;*/
}