#pragma once
#include <iostream>
#include "BSTNode.h"
using namespace std;

#ifndef BST_H_
#define BST_H_

class BST {

public:

	BSTNode* root;
	int size;

	BST() {
		root = NULL;
		size = 0;
	}

	BST(int* A, int length) {
		root = NULL;
		size = 0;
		for (int i = 0; i < length; i++)
			insert(A[i]);
	}

	/*~BST() {
		if (root != NULL)
			 deepClean(root);
	} */

	BSTNode* search(int key) {
		BSTNode* tmp = root;
		while (tmp != NULL) { // as long as the node isn't null
			if (tmp->value == key) // if the key is found at the node
				return tmp; // return its value
			else if (tmp->value > key) // of the value is greater than the key
				tmp = tmp->left; // this means the value must be to the left of the node 
			else
				tmp = tmp->right; // else the value must be to the right of the node 
		}
		return NULL;
	}

	BSTNode* insert(int val) { // complete this method
		if (size == 0) { // if there is no tree to be evaluated - create one 
			root = new BSTNode(val); // constructor call to the BSTnode class, allocates memory 
			size++; // amount of elements in the tree increases 
			return root; // value is returned 
		}
		else {
			BSTNode* temp = root;
			BSTNode* parent = NULL;
			while (temp != NULL) { // as long as the root has a value 
				if (temp->value == val) { // here, no node was created 
					return NULL;
				}
				else if (temp->value < val) { // if the value of temp is less than the value being inserted 
					parent = temp; // new parent assigned 
					temp = temp->right; // temp becomes the right child - it's larger than val 
				}
				else {
					parent = temp; // new parent assigned 
					temp = temp->left; // temp becomes the left child - it's smaller than val 
				}
			}
			BSTNode* newNode = new BSTNode(val); // BST node class 
			newNode->parent = parent; // 
			if (parent->value > val) { // if newNode goes on the left or right of parent 
				parent->left = newNode;
			}
			else {
				parent->right = newNode;
			}
			size++;
			return newNode;
		}
	}

	bool remove(int val) { // complete this method
		BSTNode* nodeToBeDeleted = search(val);
		if (nodeToBeDeleted == NULL) {
			return false;
		}
		if (nodeToBeDeleted->left != NULL && nodeToBeDeleted->right != NULL) {
			BSTNode* temp = nodeToBeDeleted->left;
			temp = findMax(nodeToBeDeleted->left);
			nodeToBeDeleted->value = temp->value; // value assigned 
			nodeToBeDeleted = temp; // setting to the max 
		}
		if (nodeToBeDeleted->left == NULL && nodeToBeDeleted->right == NULL) { // leaf
			removeLeaf(nodeToBeDeleted);
		}
		else {
			removeNodeWithOneChild(nodeToBeDeleted);
		}
		size--;
		return true;
	}

private:

	void removeLeaf(BSTNode* leaf) { // complete this method
		if (leaf == root) { // only one thing in tree
			delete root;
			root = NULL;
		}
		else {
			BSTNode* parent = leaf->parent;
			if (leaf == parent->left) { // is a left child 
				parent->left = NULL; // delete left child 
			}
			else {
				parent->right = NULL; // delete right child 
			}
			leaf->parent = NULL; // removing temporary parent variable 
			delete leaf; // delete the leaf 
		}

	}

	void removeNodeWithOneChild(BSTNode* node) { // complete this method
		BSTNode* child; 
		if (node->left != NULL) { // if the node has a left child 
			child = node->left; 
			node->left = NULL; // dereference 
		}
		else {
			child = node->right;
			node->right = NULL; // dereference 
		}
		if (node == root) {
			root = child; 
			child->parent = NULL;
			delete node;
		}
		else {
			//BSTNode* parent = node->parent;
			if (node->value <= node->parent->value) { // is a left child // <= 
				node->parent->left = child; 
			}
			else {
				node->parent->right = child; 
			}
			child->parent = node->parent;
			node->parent = NULL; // removing temporary parent variable 
			delete node; // delete the leaf 
		}
	}

public:

	int getPredecessor(int key) { // complete this method
		BSTNode* temp = root;
		int pred = INT_MIN;
		while (temp != NULL) {
			if (temp->value == key) { // found right away 
				return key;
			}
			else if (temp->value < key) { // node will be to the left 
				pred = temp->value; // possible answer 
				temp = temp->right; // keeps moving right until the value is as close to key as possible
			}
			else { // if the right node is larger than key 
				temp = temp->left;
			}
		}
		return pred;
	}

	int getSuccessor(int key) { // complete this method
		BSTNode* temp = root;
		int pred = INT_MAX;
		while (temp != NULL) {
			if (temp->value == key) { // found right away 
				return key;
			}
			else if (temp->value > key) { // node will be to the left 
				pred = temp->value; // possible answer 
				temp = temp->left; // keeps moving left until the value is as close to key as possible
			}
			else { // if the left node is smller than key 
				temp = temp->right;
			}
		}
		return pred;
	}

	int nearestNeighbour(int key) { // complete this method
		int temp1 = getPredecessor(key);
		int temp2 = getSuccessor(key);

		if (temp1 == INT_MIN) {
			return temp2;
		}
		if (temp2 == INT_MAX) {
			return temp1;
		}
		else {
			int temp3 = key - temp1; // Predecessor
			int temp4 = (key - temp2) * -1 ; // Successor
			if (temp3 < temp4) {
				return temp1;
			}
			else
				return temp2;
		}
	}

	static BSTNode* findMin(BSTNode* node) {
		if (NULL == node)
			return NULL;
		while (node->left != NULL) {
			node = node->left;
		}
		return node;
	}

	static BSTNode* findMax(BSTNode* node) {
		if (NULL == node)
			return NULL;
		while (node->right != NULL) {
			node = node->right;
		}
		return node;
	}

	void print(BSTNode* node) {
		if (NULL != node) {
			node->toString();
			cout << " ";
			print(node->left);
			print(node->right);
		}
	}

	static int getHeight(BSTNode* node) {
		if (node == NULL)
			return 0;
		else
			return 1 + max(getHeight(node->left), getHeight(node->right));
	}

	static void deepClean(BSTNode* node) {
		if (node->left != NULL)
			deepClean(node->left);
		if (node->right != NULL)
			deepClean(node->right);
		delete node;
	}

public:

	int getTreeHeight() {
		return getHeight(root);
	}

	void print() {
		print(root);
	}

	int getSize() {
		return size;
	}
	
};
#endif

