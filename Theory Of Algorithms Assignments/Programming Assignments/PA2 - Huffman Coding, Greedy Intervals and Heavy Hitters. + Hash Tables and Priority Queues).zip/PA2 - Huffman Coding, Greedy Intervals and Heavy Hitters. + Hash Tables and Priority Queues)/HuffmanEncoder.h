#include <unordered_map>
#include <string>
#include <queue>
#include "BinaryTreeNode.h"
#include "BinaryTreeNodeComparator.h"

#ifndef HUFFMANENCODER_H_
#define HUFFMANENCODER_H_

class HuffmanEncoder {
    
	int encodingLength;
	int tableSize;
	unordered_map<char, string> charToEncodingMapping;
    unordered_map<char, int> frequencyMap;

public:

	HuffmanEncoder(unordered_map<char, int> freqMap) {
		frequencyMap = freqMap;
		encodingLength = tableSize = 0;
	}
    
    ~HuffmanEncoder() {
        
    }

    void encode() { // complete this method
	// frequencymap contains the mapping of each character and its frequency (occurances)
	BinaryTreeNode* root = buildTree();
	createTable(root, "");
	for (auto it = frequencyMap.begin(); it != frequencyMap.end(); ++it) {
        char c = it->first; // value of the character at the current iteration (key)
        int f = it->second; // value of the frequency at the current iteration 
		// (x, x)

        //cout << "c is: " << c << endl;
        //cout << "f is: " << f << endl;

        string code = getEncoding(c); 
        encodingLength += (f * code.length());
        tableSize += (code.length() + 8);
    }
    }
    
private:

    BinaryTreeNode *buildTree() { // complete this method

	// creation of a minimum Priority Queue pq 
	priority_queue<BinaryTreeNode*,vector<BinaryTreeNode*>, BinaryTreeNodeComparator> PQ;
	for (auto it = frequencyMap.begin(); it != frequencyMap.end(); ++it) {
        char c = it->first; // value of the character at the current iteration (key)
        int f = it->second; // value of the frequency at the current iteration 
		// (character, value)
		BinaryTreeNode* z = new BinaryTreeNode(c,f);
		PQ.push(z); 
		// all values are pushed to the priority queue
	}
	while (PQ.size() > 1){
		BinaryTreeNode* min = PQ.top(); // grab the minimum value (top)
		PQ.pop(); // remove the value from the PQ
		BinaryTreeNode* secondMin = PQ.top(); // grab the now second minimum value (top)
		PQ.pop(); // remove the value from the PQ
		BinaryTreeNode* z = new BinaryTreeNode('\0',(min->value + secondMin->value));
		// character, and value changed for z 
		z->left = min, z->right = secondMin;
		PQ.push(z);
	}
	return PQ.top();

	/* 
	To create for BinaryTreeNodes: priority queue<BinaryTreeNode*,
	vector<BinaryTreeNode*>, BinaryTreeNodeComparator> pq;
	To create for integers: priority queue<int, vector<int>, IntegerComparator> pq;
	To obtain the size: pq.size();
	To add an item (integer or BinaryTreeNode*) x: pq.push(x);
	To peek the topmost item: pq.top();
	To remove the topmost item: pq.pop(); note that pop does not return the item removed and
	so you may want to peek and grab the item before popping.
	*/

    }

    void createTable(BinaryTreeNode *node, string encoding) { // complete this method

	if (node->left == NULL && node->right == NULL){ // if the node doesn't have any children 
		char nodeChar = node->character; // grab node's character 
		charToEncodingMapping[nodeChar] = encoding;
	}
	else {
		if(node->left != NULL) {
			createTable(node->left, encoding + '0'); // traversal steps 
		}
		if(node->right != NULL) {
			createTable(node->right, encoding + '1');
		}
	}

    }

public:

	string getEncoding(char c) {
		return charToEncodingMapping[c];
	}

	int getTableSize() {
		return tableSize;
	}

	int getEncodingLength() {
		return encodingLength;
	}
};

#endif /* HUFFMANENCODER_H_ */
