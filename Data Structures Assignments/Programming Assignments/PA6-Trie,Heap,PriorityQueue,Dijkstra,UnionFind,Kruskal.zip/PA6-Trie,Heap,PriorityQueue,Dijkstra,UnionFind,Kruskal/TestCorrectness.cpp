#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <time.h>
#include <vector>
#include <string>
#include <algorithm>
#include "Trie.h"
#include "StringHeap.h"
#include "PriorityQueueApplications.h"
#include "Dijkstra.h"
#include "UnionFind.h"
#include "Kruskal.h"
using namespace std;

string STUDENT_PATH = "students.txt";
string DIJKSTRA1 = "dijkstra1.txt";
string DIJKSTRA2 = "dijkstra2.txt";
string MST_GRAPH_PATH = "mst_graph.txt";

void printArray(int array[], int len) {
	if (0 == len) {
		cout << "[]";
		return;
	}
	cout << "[";
	for (int i = 0; i < len - 1; i++) {
		cout << array[i] << ", ";
	}
	cout << array[len - 1] << "]";
}

void printArray(char array[], int len) {
	if (0 == len) {
		cout << "[]";
		return;
	}
	cout << "[";
	for (int i = 0; i < len - 1; i++) {
		cout << array[i] << ", ";
	}
	cout << array[len - 1] << "]";
}

void printArray(string array[], int len) {
	if (0 == len) {
		cout << "[]";
		return;
	}
	cout << "[";
	for (int i = 0; i < len - 1; i++) {
		cout << array[i] << ", ";
	}
	cout << array[len - 1] << "]";
}

static void printVector(vector<int>& vect) {
	if (vect.size() == 0) {
		cout << "[]";
		return;
	}
	cout << "[";
	for (int i = 0; i < vect.size() - 1; i++) {
		cout << vect.at(i) << ", ";
	}
	cout << vect.at(vect.size() - 1) << "]";
}

void printVector(vector<Student>& students) {
	int len = students.size();
	if (0 == len) {
		cout << "[]";
		return;
	}
	cout << "[";
	for (int i = 0; i < len - 1; i++) {
		cout << students.at(i).toString() << ", ";
	}
	cout << students.at(len - 1).toString() << "]";
}

static vector<vector<int> > arraysToLists(int** arrays, int* arrayLengths,
	int n) {
	vector<vector<int> > lists;
	lists.reserve(n);
	for (int i = 0; i < n; i++) {
		vector<int> list;
		list.reserve(arrayLengths[i]);
		for (int j = 0; j < arrayLengths[i]; j++)
			list.push_back(arrays[i][j]);
		lists.push_back(list);
	}
	return lists;
}

static void printVector(vector<Edge>& vect) {
	if (0 == vect.size())
		cout << "[]";
	else {
		cout << "[";
		for (int i = 0; i < vect.size() - 1; i++) {
			cout << vect.at(i).toString() << ", ";
		}
		cout << vect.at(vect.size() - 1).toString() << "]";
	}
}

static void printList(vector<int>* vect) {
	if (0 == vect->size())
		cout << "[]";
	else {
		cout << "[";
		for (int i = 0; i < vect->size() - 1; i++) {
			cout << vect->at(i) << ", ";
		}
		cout << vect->at(vect->size() - 1) << "]";
	}
}

void testTrie() {
	Trie trie;
	cout << "*** Test Trie (Spell Checker) ***" << endl << endl;
	string dictionary[] = { "abc$", "abcd$", "bce$", "abx$", "acfe$", "bfr$",
			"de$" };
	int numWordsInDict = 7;
	for (int i = 0; i < numWordsInDict; i++) {
		trie.insert(dictionary[i]);
	}

	string document[] = { "abc", "def", "abcd", "bce", "abx", "acfe", "bfr",
			"xyz", "de", "tyu", "ab" };
	int numWordsInDoc = 11;
	bool* spellCheck = new bool[numWordsInDoc];

	for (int i = 0; i < numWordsInDoc; i++) {
		string word = document[i] + "$";
		spellCheck[i] = trie.search(word);
	}

	cout << "Dictionary: ";
	printArray(dictionary, numWordsInDict);
	cout << endl;

	cout << "Document:   ";
	printArray(document, numWordsInDoc);
	cout << endl;

	cout << endl << "Incorrect spellings: ";
	for (int i = 0; i < numWordsInDoc; i++) {
		if (!spellCheck[i])
			cout << document[i] << " ";
	}
	delete[] spellCheck;
}

static void testLCS() {
	cout << "\n*** Test Trie (Longest Common Substring) ***\n" << endl;
	string str1 = "abbcabdb";
	string str2 = "cbccabd";
	string lcs = Trie::longestCommonSubstring(str1, str2);
	cout << "Longest Common Substring of " << str1 << " and " << str2 << " is "
		<< lcs << endl;

	str1 = "abbcabdb";
	str2 = "abbcabdb";
	lcs = Trie::longestCommonSubstring(str1, str2);
	cout << "Longest Common Substring of " << str1 << " and " << str2 << " is "
		<< lcs << endl;

	str1 = "abbcabdb";
	str2 = "xyyzex";
	lcs = Trie::longestCommonSubstring(str1, str2);
	cout << "Longest Common Substring of " << str1 << " and " << str2 << " is "
		<< lcs << endl;

	str1 = "zxabcdezy";
	str2 = "yzabcdezx";
	lcs = Trie::longestCommonSubstring(str1, str2);
	cout << "Longest Common Substring of " << str1 << " and " << str2 << " is "
		<< lcs << endl;

	str1 = "Hello World!";
	str2 = "Hi World!";
	lcs = Trie::longestCommonSubstring(str1, str2);
	cout << "Longest Common Substring of " << str1 << " and " << str2 << " is "
		<< lcs;
}

void testHeap() {
	cout << "\n*** Test Heap Sort ***" << endl << endl;
	string array[] = { "abc", "def", "abcd", "bce", "abx", "acfe", "bfr", "xyz",
			"de", "tyu", "ab", "abcd", "xy", "zxy", "abx", "def" };
	int length = 16;
	cout << "Before Sorting: ";
	printArray(array, length);
	cout << endl;
	StringHeap ha;
	ha.heapSort(array, length);
	cout << "After Sorting:  ";
	printArray(array, length);
	cout << endl;
}

void testTopKElements() {
	cout << "*** Test Top-k ***\n" << endl;
	vector<Student> students = IOHelper::readStudents(STUDENT_PATH);
	cout << "Original Array:     ";
	printVector(students);
	cout << endl;
	vector<Student> top3 = PriorityQueueApplications::topK(students, 3);
	vector<Student> top7 = PriorityQueueApplications::topK(students, 7);
	vector<Student> all = PriorityQueueApplications::topK(students,
		students.size());
	cout << "Highest 3 students: ";
	printVector(top3);
	cout << endl;
	cout << "Highest 7 students: ";
	printVector(top7);
	cout << endl;
	cout << "All students:       ";
	printVector(all);
}

static void testKSortedMerge() {
	cout << "\n\n*** Test Merging k Sorted Arrays ***\n" << endl;
	int list0[] = { 1, 5, 9, 18 };
	int list1[] = { -10, 5, 18, 67, 100 };
	int list2[] = { -12, -9, -6, 0, 1, };
	int list3[] = { -65, -32, 10, };
	int list4[] = { 1, 19, 45, 67 };
	int* lists[] = { list0, list1, list2, list3, list4 };
	int k;

	k = 5;
	int eachListLength1[] = { 4, 5, 5, 3, 4 };
	cout << "Original sorted arrays" << endl;
	for (int i = 0; i < k; i++) {
		printArray(lists[i], eachListLength1[i]);
		cout << endl;
	}
	vector<vector<int> > list = arraysToLists(lists, eachListLength1, k);
	vector<int> mergedList = PriorityQueueApplications::kWayMerge(list);
	cout << endl << "Final merged array: ";
	printVector(mergedList);

	k = 4;
	int eachListLength2[] = { 4, 5, 5, 3 };
	cout << endl << endl << "Original sorted arrays" << endl;
	for (int i = 0; i < k; i++) {
		printArray(lists[i], eachListLength2[i]);
		cout << endl;
	}
	list = arraysToLists(lists, eachListLength2, k);
	mergedList = PriorityQueueApplications::kWayMerge(list);
	cout << "\nFinal merged array: ";
	printVector(mergedList);

	k = 2;
	int eachListLength3[] = { 4, 5 };
	list = arraysToLists(lists, eachListLength3, k);
	mergedList = PriorityQueueApplications::kWayMerge(list);
	cout << endl << endl << "Original sorted arrays" << endl;
	for (int i = 0; i < k; i++) {
		printArray(lists[i], eachListLength2[i]);
		cout << endl;
	}
	cout << "\nFinal merged array: ";
	printVector(mergedList);

	k = 1;
	int eachListLength4[] = { 4 };
	list = arraysToLists(lists, eachListLength4, k);
	mergedList = PriorityQueueApplications::kWayMerge(list);
	cout << endl << endl << "Original sorted arrays" << endl;
	for (int i = 0; i < k; i++) {
		printArray(lists[i], eachListLength2[i]);
		cout << endl;
	}
	cout << "\nFinal merged array: ";
	printVector(mergedList);
}

void testDijkstra() {
	cout << endl;
	string filePaths[] = { DIJKSTRA1, DIJKSTRA2 };
	for (int j = 0; j < 2; j++) {
		cout << "\n*** Test Dijkstra (" << filePaths[j] << ") ***" << endl;
		Dijkstra dijk(filePaths[j]);
		for (int i = 0; i < dijk.numVertices; i++) {
			dijk.execute(i);
			cout << "\nDistance array (from v" << i << "): ";
			dijk.printDistanceArray();
			cout << endl;
			cout << "Parent array (from v" << i << "):   ";
			dijk.printParentArray();
			cout << endl;
		}
	}
}

void testUnionFind() {
	UnionFind uf(16);
	cout << "Initial sets are 0-15\n" << endl;
	for (int i = 0; i < 15; i += 4) {
		cout << "UNION(" << i << "," << i + 1 << ")" << endl;
		uf.doUnion(i, i + 1);
	}
	cout << endl;
	for (int i = 0; i < 16; i++) {
		printf("List containing %2d: ", i);
		vector<int>* ll = uf.find(i);
		printList(ll);
		cout << endl;
	}
	cout << "\nUNION(0,5)" << endl;
	cout << "UNION(10,12)" << endl;
	cout << "UNION(0,10)\n" << endl;
	uf.doUnion(0, 5);
	uf.doUnion(10, 12);
	uf.doUnion(0, 10);
	for (int i = 0; i < 16; i++) {
		printf("List containing %2d: ", i);
		vector<int>* ll = uf.find(i);
		printList(ll);
		cout << endl;
	}

	cout << "\nUNION(6,8)" << endl;
	cout << "UNION(8,5)\n" << endl;
	uf.doUnion(6, 8);
	uf.doUnion(8, 5);
	for (int i = 0; i < 16; i++) {
		printf("List containing %2d: ", i);
		vector<int>* ll = uf.find(i);
		printList(ll);
		cout << endl;
	}
}

void testKruskal() {
	Kruskal kruskal(MST_GRAPH_PATH);
	vector<Edge> mst = kruskal.runKruskal();
	int mstWeight = 0;
	for (Edge& edge : mst)
		mstWeight += edge.weight;
	cout << "MST has weight " << mstWeight << endl;
	cout << "The edges are: ";
	printVector(mst);
}

int main() {
	testTrie();
	cout << endl;
	testLCS();
	cout << endl;
	testHeap();
	cout << endl;
	testTopKElements();
	testKSortedMerge();
	testDijkstra();
	cout << "\n*** Union-Find ***\n" << endl;
	testUnionFind();
	cout << "\n*** Kruskal ***\n" << endl;
	testKruskal();
	return 1;
}