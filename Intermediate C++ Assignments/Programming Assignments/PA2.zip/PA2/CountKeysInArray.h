#include <iostream>
using namespace std;

class CountKeysInArray
{
private: 

public: 

	static int countKey(int* arr, int arrayLength, int left, int right, int key) // checks key in bounds  
	{
		int x = 0;
		if (left < 0 || right >= arrayLength || right < left)
		{
			return -1;
		}
		for (int i = left; i <= right; i++)
		{
			if (arr[i] == key)
			{
				x++; // key is found here 
			}
		}
		if (x == 0) {
			return 0;
		}
		else {
			return x;
		}
	}

	static int countKey(int* arr, int arrayLength, int key)
	{
		return countKey(arr, arrayLength, 0, arrayLength - 1, key);
	}






};