#include <iostream>
#include <string>
using namespace std;

#ifndef LCS_H_
#define LCS_H_

class LCS {

public:

	// two strings of input
	string longestCommonSubsequence(const string &x, const string &y) { // LCS without storing directions

	// grab the length of the strings
	int lenx = x.length();
	int leny = y.length();

	// create a 2d array with the values
	int **length = new int*[lenx + 1]; // rows
	for (int i = 0; i < lenx + 1; i++) {
		length[i] = new int[leny + 1]; // columns
	}

	// setting the values of the array
	for (int i = 0; i < lenx + 1; i++) {
		length[i][0] = 0; // fill the top row with zero
	}
	for (int j = 0; j < leny + 1; j++) {
		length[0][j] = 0; // fill the left column with zero
	}

	// nested for loops, for traversing the table
	for (int i = 1; i <= lenx; i++) { // start at the row
		for (int j = 1; j <= leny; j++) { // traverse the strings
			if (x.at(i - 1) == y.at(j - 1)) { // if the characters are equal 
				length[i][j] = length[i - 1][j - 1] + 1; // take the value from the diagonal
			}
			else if (length[i - 1][j] > length[i][j - 1]) { // if the value in the row is less than the left value, strictly
				length[i][j] = length[i - 1][j]; // take the vaue from the left
			}
			else {
				length[i][j] = length[i][j - 1]; // take the value from the top (preferred in this case)
			}
		}
	}

	// now create the answer 
	string answer = "";
	while (lenx > 0 && leny > 0) { // as long as we have space to move (bounds)
		if (x.at(lenx - 1) == y.at(leny - 1)) { // we should pick this character, and move diagonally
			answer += x.at(lenx - 1); // we grab, as we moved diagonally
			// move diagonally
			lenx--; 
			leny--;
		}
		else if (length[lenx - 1][leny] > length[lenx][leny - 1]) { // we should move a cell up 
			lenx--;
		}
		else { // we should move left
			leny--;
		}
	}

	return reverse(answer);

	}

private:

	static string reverse(const string &str) {
		string rev = "";
		for (int i = str.length() - 1; i >= 0; i--) {
			rev += str.at(i);
		}
		return rev;
	}
};

#endif /* LCS_H_ */
