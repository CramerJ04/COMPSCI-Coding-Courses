#ifndef PRIORITYQUEUEPAIR_H_
#define PRIORITYQUEUEPAIR_H_

class PriorityQueuePair {

public:

	int item;
	int priority;

	PriorityQueuePair(int item, int priority) {
		this->item = item;
		this->priority = priority;
	}
};

#endif /* PRIORITYQUEUEPAIR_H_ */
