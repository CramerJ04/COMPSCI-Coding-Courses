#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include "Shape.h"
#include "Cylinder.h"
#include "Cuboid.h"
#include "Sphere.h"
using namespace std;

#ifndef SHAPEREADER_H_
#define SHAPEREADER_H_

class ShapeReader {

private:

	static vector<string> split(string &str, string delimeter) { // this function will help you split the line based on the delimeter
		vector<string> tokens;
		string token;
		int startIndex = 0;
		int endIndex = str.find(delimeter);
		while (endIndex >= 0 && endIndex < str.length()) {
			token = str.substr(startIndex, endIndex - startIndex);
			tokens.push_back(token);
			startIndex = endIndex + delimeter.length();
			endIndex = str.find(delimeter, startIndex);
		}
		token = str.substr(startIndex);
		tokens.push_back(token);
		return tokens;
	}

	static bool isNumber(string &str) { // this function can be used to check if a string is a number
		string digits = "0123456789";
		int countDots = 0;
		int countNeg = 0;
		for (int i = 0; i < str.length(); i++) {
			if (str[i] == '.')
				countDots++;
			else if (str[i] == '-')
				countNeg++;
			else {
				int index = digits.find(str[i]);
				if (index < 0 || index >= digits.length())
					return false;
			}
		}
		if (countNeg > 1)
			return false;
		if (countNeg == 1 && str.at(0) != '-')
			return false;
		return countDots <= 1;
	}

public:

	static vector<Shape*> readShapes(string fileName, string errorPath) { 

		//string filePath = "C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\PA9\\PA9
		ifstream reader(fileName, ios::in);
		ofstream writer(errorPath, ios::out);
		string line; 
		vector<Shape*> shapes;
		while (getline(reader, line)) {
			vector<string> tokens = split(line, ","); // reads lines 
			try {
				char name = tokens.at(0).at(0);
				if (tokens.at(0) != "0" && tokens.at(0) != "1" && tokens.at(0) != "2") {
					throw(ErrorType::INVALID_SHAPE_TYPE);
				}
				else if (tokens.at(0) == "0") { // cuboid check 
					if (tokens.size() < 5) { // low dimensions 
						throw(ErrorType::CUBOID_LOW_DIMENSIONS);
					}
					else if (isNumber(tokens.at(2)) == false || isNumber(tokens.at(3)) == false || isNumber(tokens.at(4)) == false) { // not a number 
						throw(ErrorType::CUBOID_NOT_A_NUMBER);
					}
					else if (stoi(tokens.at(2)) < 0 || stoi(tokens.at(3)) < 0 || stoi(tokens.at(4)) < 0) { // negative dimensions 
						throw(ErrorType::CUBOID_NEGATIVE_DIMENSIONS); 
					}
					else {
						Cuboid* C = new Cuboid(tokens.at(1), stod(tokens.at(2)), stod(tokens.at(3)), stod(tokens.at(4)));
						shapes.push_back(C); 
					}
				}
				else if (tokens.at(0) == "1") { // cylinder 
					if (tokens.size() < 4) { // low dimensions 
						throw(ErrorType::CYLINDER_LOW_DIMENSIONS);
					}
					else if (isNumber(tokens.at(2)) == false || isNumber(tokens.at(3)) == false) { // not a number 
						throw(ErrorType::CYLINDER_NOT_A_NUMBER);
					}
					else if (stoi(tokens.at(2)) < 0 || stoi(tokens.at(3)) < 0) { // negative dimensions 
						throw(ErrorType::CYLINDER_NEGATIVE_DIMENSIONS);
					}
					else {
						Cylinder* CYL = new Cylinder(tokens.at(1), stod(tokens.at(2)), stod(tokens.at(3)));
						shapes.push_back(CYL); 
					}
				}
				else if (tokens.at(0) == "2") { // Sphere 
					if (tokens.size() < 3) { // low dimensions 
						throw(ErrorType::SPHERE_LOW_DIMENSIONS);
					}
					else if (isNumber(tokens.at(2)) == false) { // not a number 
						throw(ErrorType::SPHERE_NOT_A_NUMBER);
					}
					else if (stoi(tokens.at(2)) < 0) { // negative dimensions 
						throw(ErrorType::SPHERE_NEGATIVE_DIMENSIONS);
					}
					else {
						Sphere* S = new Sphere(tokens.at(1), stod(tokens.at(2)));
						shapes.push_back(S);
					}
				}
			}
			catch (ErrorType arg) { // error messages  
				if (arg == ErrorType::INVALID_SHAPE_TYPE) {
					writer << "ERROR: INVALID SHAPE TYPE" << endl;
				}
				else if (arg == ErrorType::SPHERE_LOW_DIMENSIONS) {
					writer << "SPHERE ERROR: LOW DIMENSION ERROR" << endl;
				}
				else if (arg == ErrorType::SPHERE_NOT_A_NUMBER) {
					writer << "SPHERE ERROR: NOT A NUMBER ERROR" << endl;
				}
				else if (arg == ErrorType::SPHERE_NEGATIVE_DIMENSIONS) {
					writer << "SPHERE ERROR: NEGATIVE DIMENSIONS" << endl;
				}
				else if (arg == ErrorType::CUBOID_LOW_DIMENSIONS) {
					writer << "CUBOID ERROR: LOW DIMENSION ERROR" << endl;
				}
				else if (arg == ErrorType::CUBOID_NOT_A_NUMBER) {
					writer << "CUBOID ERROR: NOT A NUMBER ERROR" << endl;
				}
				else if (arg == ErrorType::CUBOID_NEGATIVE_DIMENSIONS) {
					writer << "CUBOID ERROR: NEGATIVE DIMENSIONS" << endl;
				}
				else if (arg == ErrorType::CYLINDER_LOW_DIMENSIONS) {
					writer << "CYLINDER ERROR: LOW DIMENSION ERROR" << endl;
				}
				else if (arg == ErrorType::CYLINDER_NOT_A_NUMBER) {
					writer << "CYLINDER ERROR: NOT A NUMBER ERROR" << endl;
				}
				else if (arg == ErrorType::CYLINDER_NEGATIVE_DIMENSIONS) {
					writer << "CYLINDER ERROR: NEGATIVE DIMENSIONS" << endl;
				}
			}
			
		}
		reader.close();
		writer.close();
		return shapes;
	}
};

#endif /* SHAPEREADER_H_ */
