#include <string>
#include <iostream>
using namespace std;

// Write StringStuff class and all its methods here. You can also use a separate .h file if you want, but make sure to include it above.

class StringStuff
{
public:
	static void tokenize(string& str)
	{
		for (int i = 0; i < str.length(); i++)
		{
			char c = str.at(i);
			if (c >= 97 && c <= 122) // a-z
				cout << str.at(i);
			else if (c >= 65 && c <= 90) // A-Z
				cout << str.at(i);
			else if (c == ' ')
			cout << endl;
		}
	}

	static bool isValidEmail(string& str)
	{
		int counter = 0;
		string cor = "@compsci222@uww.edu";
		for (int i = 0; i < str.length(); i++)
		{
			char c = str.at(i);
			if (c == '@')
			counter++;
		}
		/*if (counter != 1)
		{
			return false;
		}
		else if (counter == 1)
			if (str.find(cor) + 19 == str.length())
				return true;
			else
				return false;*/
		if (str.find(cor) + 19 != str.length() || counter > 1)
			return false;
		else
			return true;
	}

	static bool isValidPassword(string& str)
	{
		int upper = 0;
		int lower = 0;
		int digit = 0;
		int special = 0;
		int len = 0;
		for (int i = 0; i < str.length(); i++)
		{
			char c = str.at(i);
			if (c >= 97 && c <= 122) // a-z
				lower++;
			if (c >= 65 && c <= 91) // A-Z
				upper++;
			if (c >= 48 && c <= 57) // 0-9
				digit++;
			if (c == '!' || c == '@' || c == '#' || c == '$' || c == '%' || 
				c == '^' || c == '&' || c == '*' || c == '(' || c == ')' || 
				c == '+' || c == '=' || c == '~' || c == '`') // special
				special++;
		}

		if (lower >= 1 && upper >= 1 && digit >= 1 && special >= 1 && str.length() >= 12)
			return true;
		else 
			return false;
	}

};
int main() {
	string str = "This is an English sentence, which serves no purpose.";
	cout << "Sentence: " << str << endl;
	cout << "The words are: " << endl << endl;
	StringStuff::tokenize(str);
	cout << endl;

	string emails[] = {"nobody@compsci222.uww.edu",
			"nob@ody@compsci222.uww.edu", "nobody@compsci222.uww.eduroam", "nobody@compsci999.uww.edu" };
	for (int i = 0; i < 4; i++) {
		bool b = StringStuff::isValidEmail(emails[i]);
		cout << emails[i] << " is ";
		if (b)
			cout << "a valid email." << endl;
		else
			cout << "not a valid email." << endl;
	}

	cout << endl;

	string passwords[] = {"Pas$word123",
				"Password@123", "Password@123#456", "password@123456", "PASSWORD@123456", "PASSword123456" };
	for (int i = 0; i < 6; i++) {
		bool b = StringStuff::isValidPassword(passwords[i]);
		cout << passwords[i] << " is ";
		if (b)
			cout << "a valid password." << endl;
		else
			cout << "not a valid password." << endl;
	}
};



