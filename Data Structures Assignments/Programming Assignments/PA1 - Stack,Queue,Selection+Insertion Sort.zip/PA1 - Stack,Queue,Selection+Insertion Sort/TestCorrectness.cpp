#include "OddEvenStack.h"
#include "Queue.h"
#include "QueueUsingStack.h"
#include "Sorting.h"

void testCorrectness() {
    int queueSize = 7; 
    QueueUsingStack qViaStack(queueSize); 
    Queue queue(queueSize);
    cout << "**** Enqueue Test ****";
    cout << endl;
    for (int i = 1; i <= 4; i++) {
        int x = i * 5;
        qViaStack.enqueue(x);
        queue.enqueue(x);
        cout << endl << "Enqueue " << x;
        cout << endl << "Stack implementation: ";
        qViaStack.print();
        cout << endl << "Standard implementation: ";
        queue.print();
        cout << endl;
    }
    cout << endl << "**** Dequeue Test ****";
    cout << endl;
    for (int i = 1; i <= 2; i++) {
        cout << endl << "Stack implementation: (Dequeued "
            << qViaStack.dequeue() << ") ";
        qViaStack.print();
        cout << endl << "Standard implementation: (Dequeued " << queue.dequeue()
            << ") ";
        queue.print();
        cout << endl;
    }
    cout << endl << "**** Enqueue Test ****";
    cout << endl;
    for (int i = 1; i <= 5; i++) {
        int x = i * 7;
        qViaStack.enqueue(x);
        queue.enqueue(x);
        cout << endl << "Enqueue " << x;
        cout << endl << "Stack implementation: ";
        qViaStack.print();
        cout << endl << "Standard implementation: ";
        queue.print();
        cout << endl;
    }
    cout << endl << "**** Dequeue Test ****";
    cout << endl;
    for (int i = 1; i <= 7; i++) {
        cout << endl << "Stack implementation: (Dequeued "
            << qViaStack.dequeue() << ") ";
        qViaStack.print();
        cout << endl << "Standard implementation: (Dequeued " << queue.dequeue()
            << ") ";
        queue.print();
        cout << endl;
    }

    cout << "\n**** Odd/Even Stack ****\n" << endl; 
    OddEvenStack os_stack(8);
    cout << "object made" << endl;
    int contents[] = { 2, 3, 12, 24, 33, 11, 21, 93, 6, 43 };
    for (int i = 0; i < sizeof(contents) / sizeof(int); i++) {
        printf("Pushing %2d...", contents[i]);
        os_stack.push(contents[i]);
        cout << " Stack content: " << os_stack.toString() << endl;
    }
    cout << endl;
    cout << "Popping  odd: " << os_stack.popOdd() << endl;
    printf("Pushing %2d...", 100);
    os_stack.push(100);
    cout << " Stack content: " << os_stack.toString() << endl;
    cout << "Popping  odd: " << os_stack.popOdd() << endl;
    cout << "Popping  odd: " << os_stack.popOdd() << endl;
    cout << "Popping  odd: " << os_stack.popOdd() << endl;
    cout << "Popping  odd: " << os_stack.popOdd() << endl;
    cout << "Popping even: " << os_stack.popEven() << endl;
    cout << "Popping even: " << os_stack.popEven() << endl;
    cout << "Popping even: " << os_stack.popEven() << endl;
    cout << "Popping even: " << os_stack.popEven() << endl;
    cout << "Popping  odd: ";
    os_stack.popOdd();
    cout << "\nPopping even: ";
    os_stack.popEven();
}

void testSorting() {
    cout << endl << "\n**** Sorting ****" << endl << endl;
    Sorting sortObj;
    int A[] = { 13, 17, 8, 14, 1 };
    int lenA = sizeof(A) / sizeof(int);
    cout << "Original Selection Array: ";
    sortObj.printArray(A, lenA);
    cout << endl;
    sortObj.selectionSort(A, lenA);
    cout << endl << "Selection Sorted Array: ";
    sortObj.printArray(A, lenA);

    cout << endl << endl;

    int B[] = { -13, -17, -8, -14, -1, -20 };
    int lenB = sizeof(B) / sizeof(int);
    cout << "Original Insertion Array: ";
    sortObj.printArray(B, lenB);
    cout << endl;
    sortObj.insertionSort(B, lenB);
    cout << endl << "Insertion Sorted Array: ";
    sortObj.printArray(B, lenB);
    cout << endl;
}

int main() {
    testCorrectness();
    testSorting();
    return 1;
}