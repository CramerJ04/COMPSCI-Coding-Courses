#include "BellmanFord.h"
#include "Dijkstra.h"
#include <climits>

#ifndef JOHNSON_H_
#define JOHNSON_H_

class Johnson: public Graph {

public:

	Johnson(const Graph *graph) :
			Graph(graph) {
	}

	int **execute() { 

		adjList.push_back(vector<Edge>()); // add a dummy vertex 
		for(int i = 0; i < numVertices; i++){ // go through each vert 
			Edge e; // create a new edge
			e.src = numVertices; // dummy vertex 
			e.dest = i; // vertex in the graph connection 
			e.weight = 0; // make the weight 0 (dummy)
			adjList[numVertices].push_back(e); // pushed to the last row

		}

		numEdges += numVertices; 
		numVertices++;

		BellmanFord newBellmanFordObject(this); // bellman ford object created 
		// passing "this" merges the graph part of the Johnson object is embedded into the BellmanFord object

		int *potentials = newBellmanFordObject.execute(numVertices - 1); // potentials array grabbed by running bellman from the dummy

		numVertices--;
		numEdges -= numVertices;
		adjList.pop_back(); // last row removed

		if(potentials == NULL){
			return NULL;
		}

		// modify edge weights
		for(int j = 0; j < adjList.size(); j++) { // iterate over each vertex
    		for (int k = 0; k < adjList[j].size(); k++) { // iterate over each edge of the particular j vertex
        		Edge &e = adjList[j][k]; // get the particular k edge of the particular j vertex
				e.weight = e.weight + potentials[e.src] - potentials[e.dest]; // edge weights modified using potentials (calculation)
			}
		}

		int** allPairMatrix = new int*[numVertices]; // 2D array, numVertices rows

		Dijkstra newDijkstraObject(this); // same as before, instead with Dijkstra

		for(int i = 0; i < numVertices; i++) {
			allPairMatrix[i] = newDijkstraObject.execute(i); // set the matrix accroding to the Dijkstra execution 
		}

		for(int i = 0; i < numVertices; i++) { // set the new potentials using the pair matrix
			for(int j = 0; j < numVertices; j++) {
				if(i != j && allPairMatrix[i][j] != INT_MAX) {
					allPairMatrix[i][j] = allPairMatrix[i][j] - potentials[i] + potentials[j];
				}
			}
		}

		for(int j = 0; j < adjList.size(); j++) { // iterate over each vertex
    		for (int k = 0; k < adjList[j].size(); k++) { // iterate over each edge of the particular j vertex
        		Edge &e = adjList[j][k]; // get the particular k edge of the particular j vertex
				e.weight = e.weight - potentials[e.src] + potentials[e.dest]; // revert back to the original values
			}
		}
		delete[] potentials;
		return allPairMatrix;
	}
};

#endif /* JOHNSON_H_ */
