#include <fstream>
#include <iostream>
#include "TicTacToe (1).h"
using namespace std;

void test(string filePath) { // complete this function
	ifstream reader(filePath, ios::in);
	int dim;
	int choices;
	reader >> dim;
	reader >> choices;
	int* nums;
	nums = new int[choices];
	for (int i = 0; i < choices; i++)
	{
		reader >> nums[i];
	}
	TicTacToe obj = TicTacToe(dim);
	obj.play(nums, choices);
	
}

int main() {
	string FOLDER_PATH = "C:\\Users\\randomuser\\source\\repos\\Intermediate C++\\Intermediate C++\\PA6\\PA6 Stuff\\PA6\\"; // you may need to change this to the folder containing the files

	test(FOLDER_PATH + "3by3_XWins.txt");
	cout << endl;
	test(FOLDER_PATH + "3by3_XWins2.txt");
	cout << endl;
	test(FOLDER_PATH + "3by3_YWins.txt");
	cout << endl;
	test(FOLDER_PATH + "3by3_Draw.txt");
	cout << endl;
	test(FOLDER_PATH + "4by4_XWins.txt");
	cout << endl;
	test(FOLDER_PATH + "4by4_YWins.txt");
	cout << endl;
	test(FOLDER_PATH + "4by4_Draw.txt");
	return 1;
}

