#include "Student.h"

#ifndef STUDENTSORTER_H_
#define STUDENTSORTER_H_

class StudentSorter {

public:

    static void StudentNameSelection(Student *arr[], int n) // array here 
    {
		for (int i = 0; i < n - 1; i++) { // goes over the array, except the last index 
			int minIndex = i; // initial guess of minimum
			for (int j = i + 1; j < n; j++) { // finding minimum index (searching through array)
				if (arr[j]->name.compare(arr[i]->name)<0) // name comparison arr[i]->name.compare(arr[j]->name
				{
					minIndex = j;
				}
			}
			if (minIndex != i) {
				Student temp = *arr[i]; // swapping pointers here 
				*arr[i] = *arr[minIndex];
				*arr[minIndex] = temp;
			}
		}
    }

	static void StudentGradeInsertion(Student* arr[], int n)
	{
		for (int i = 1; i < n; i++)
		{
			double temp = arr[i]->grade; // value of index, not an index (number or string)
			string temp2 = arr[i]->name;
			int j = i - 1; // j is the number before 
			while (j >= 0 && temp < arr[j]->grade)  
			{
				*arr[j + 1] = *arr[j];
				j--; 
			}
			arr[j + 1]->grade = temp;
			arr[j + 1]->name = temp2;
		}
	}
    
    
};

#endif /* STUDENTSORTER_H_ */
