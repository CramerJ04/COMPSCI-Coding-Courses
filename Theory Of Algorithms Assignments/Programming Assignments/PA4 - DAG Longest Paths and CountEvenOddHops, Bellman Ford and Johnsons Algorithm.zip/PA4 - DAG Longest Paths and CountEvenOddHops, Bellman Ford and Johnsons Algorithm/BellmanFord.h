#include "Graph.h"
#include <climits>

#ifndef BELLMANFORD_H_
#define BELLMANFORD_H_

class BellmanFord: public Graph {

public:

	BellmanFord(const Graph *graph) :
			Graph(graph) {
	}

	int *execute(int source) { 

		int* dist = new int[numVertices]; // creating a dist[] numVert size
		for(int i = 0; i < numVertices; i++){ // set all of the cells to infinity
			dist[i] = INT_MAX;
		}

		bool didDistChange; // creation of a bool for checks as table is created
		dist[source] = 0; // zero for the source

		// begin the process
		for(int i = 1; i < numVertices; i++) {

			didDistChange = false; // set checker to false initially. Will change if any change occurs

			for (int j = 0; j < adjList.size(); j++) { // iterate over each vertex
    			for (int k = 0; k < adjList[j].size(); k++) { // iterate over each edge of the j-th vertex
        			Edge &e = adjList[j][k]; // get the particular k edge of the particular j vertex
					if(dist[e.src] == INT_MAX) // if the vertex's soucre is infinity, do the following
						continue; 
					int newDist = dist[e.src] + e.weight; // calculate the new distance
					if(newDist < dist[e.dest]) { // if the new distance is less than the previous, update
						dist[e.dest] = newDist;
						didDistChange = true; // checker for a value change
					}
				}
			}
			if(!didDistChange) { // no change was reported, so end the process
					return dist;
			}
    	}

		//
		for(int j = 0; j < adjList.size(); j++) { // iterate over each vertex
    		for (int k = 0; k < adjList[j].size(); k++) { // iterate over each edge of the particular j vertex
        		Edge &e = adjList[j][k]; // get the particular k edge of the particular j vertex
				if(dist[e.src] == INT_MAX) 
					continue; 
				if((dist[e.src] + e.weight) < dist[e.dest]) // if a negative cycle is detected
                	return NULL; 
				}
			}

		return dist;
		delete[] dist;

	}
		
};

#endif /* BELLMANFORD_H_ */
