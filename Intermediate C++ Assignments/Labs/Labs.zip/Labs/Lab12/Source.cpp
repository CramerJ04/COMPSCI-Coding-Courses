#include <iostream>
#include <vector>
#include <string>

using namespace std;

template <typename T>
class GenericQueue {

	vector<T> Queue;

public: 

	void enquete(T arg) {
		Queue.push_back(arg);
	}

	T dequeue() {
		T val = Queue.front();
		Queue.erase(Queue.begin());
		return val;
	}

	T peek() {
		return Queue.front();
	}

	int size() {
		return Queue.size();
	}

};

int main() {

	GenericQueue<int> intStack;
	for (int i = 0; i <= 25; i++) {
		intStack.enquete(i);
		while (intStack.size() > 0) {
			cout << intStack.dequeue() << " ";
		}
	};
	string strStack[] = {"abc", "def", "xxx", "yyy", "zzz"};
	GenericQueue<string> stringStack;
	cout << endl;
	for (int i = 0; i < 5; i++) {
		stringStack.enquete(strStack[i]);
		while (stringStack.size() > 0) {
			cout << stringStack.dequeue() << " ";
		}
	}; // stacks are empty

	cout << endl << endl;

	GenericQueue<int> intStack2;
	int val = 1;
	for (int i = 0; i <= 25; i += 5) {
		intStack2.enquete(i);
		while (intStack2.size() > 1) {
			cout << intStack2.dequeue() << " ";
		}
	};

	cout << endl <<  "Peeking Int Queue: " << intStack2.peek() << endl;

	string strStack2[] = { "abc", "def", "xxx", "yyy", "zzz" };
	GenericQueue<string> stringStack2;
	cout << endl;
	for (int i = 0; i < 5; i++) {
		stringStack2.enquete(strStack2[i]);
		while (stringStack2.size() > 1) {
			cout << stringStack2.dequeue() << " ";
		}
	}; 

	cout << endl;

	cout << "Peeking String Queue: " << stringStack2.peek() << endl;



	return 1;
}