#include <iostream>
#include <vector>
using namespace std;

#ifndef MERGESORTANDFRIENDS_H_
#define MERGESORTANDFRIENDS_H_

class MergeSortAndFriends {

private:

	static int* binaryMerge(int* A, int* B, int lenA, int lenB) { // complete this function
		int* C = new int[lenA + lenB];
		int a = 0;
		int b = 0;
		int c = 0;
		while (a < lenA && b < lenB) {
			if (A[a] <= B[b]) {
				int temp = A[a];
				C[c] = temp;
				a++;
				c++;
			}
			else {
				int temp = B[b];
				C[c] = temp;
				b++;
				c++;
			}
		}
		while (a < lenA) {
			int temp = A[a];
			C[c] = temp;
			a++;
			c++;
		}
		while (b < lenB) {
			int temp = B[b];
			C[c] = temp;
			b++;
			c++;
		}
		return C;
	}

public:

	static vector<int> commonElements(int* A, int* B, int lenA, int lenB) { // complete this function
		vector<int> vect;
		int a = 0;
		int b = 0;
		int c = 0;
		while (a < lenA && b < lenB) {
			if (A[a] < B[b]) {
				a++;
			}
			else if (A[a] > B[b]) {
				b++;
			}
			else {
				int temp = A[a];
				vect.push_back(temp);
				a++;
				c++;
				while (a < lenA && A[a] == B[b]) {
					a++;
				}
			}
		}
		return vect;
	}

	static int* kWayMerge(int** lists, int* listLengths, int k) { // complete this function
		if (k == 1) { // one row in the jagged array 
			return lists[0];
		}
		if (k == 2) { // two merged lists, call the function 
			return binaryMerge(lists[0], lists[1], listLengths[0], listLengths[1]);
		}
		int newK = (k + 1) / 2; // new number of sorted lists after pairwise merging
		int** mergedLists = new int*[newK]; // stores pairwise merged lists 
		int* mergedListLengths = new int[newK]; // stores lengths of the pairwise merged lists 
		for (int i = 0; i <= (k / 2) - 1; i++) { // lists are to be merged pairwise
			// lists0 merges with lists1 to create mergelists[0], lists2 and lists3 to create mergelists[1]
			mergedListLengths[i] = listLengths[2*i] + listLengths[(2*i) + 1];
			mergedLists[i] = binaryMerge(lists[2 * i], lists[(2 * i) + 1], listLengths[2 * i], listLengths[(2 * i) + 1]);
		}
		if (k % 2 != 0) { // if the number of lists left is odd
			// lists[k-1] gets copied to mergedlists[k-1] so it has a pair to be merged with 
			mergedLists[newK - 1] = lists[k - 1];
			mergedListLengths[newK - 1] = listLengths[k - 1];
		}
		return kWayMerge(mergedLists, mergedListLengths, newK);
	}

	static void mergesort(int* array, int left, int right) {
		if (left < right) {
			int mid = (left + right) / 2;
			mergesort(array, left, mid);
			mergesort(array, mid + 1, right);
			int* mergedArray = binaryMerge(&array[left], &array[mid + 1],
				mid - left + 1, right - mid);
			int i = left;
			int j = 0;
			while (j <= right - left)
				array[i++] = mergedArray[j++];
			delete[] mergedArray;
		}
	}
};

#endif /* MERGESORTANDFRIENDS_H_ */

	
